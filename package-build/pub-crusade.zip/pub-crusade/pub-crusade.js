function Kd(e, t) {
  for (var n = 0; n < t.length; n++) {
    const r = t[n];
    if (typeof r != "string" && !Array.isArray(r)) {
      for (const o in r)
        if (o !== "default" && !(o in e)) {
          const l = Object.getOwnPropertyDescriptor(r, o);
          l && Object.defineProperty(e, o, l.get ? l : {
            enumerable: !0,
            get: () => r[o]
          });
        }
    }
  }
  return Object.freeze(Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }));
}
const Nr = "pub-crusade", Xd = "system", Zd = `${Xd}s/${Nr}`, Jd = `${Zd}/templates`, qd = `${Jd}/react-application.hbs`, ja = "character", ep = 500;
function Ar(e) {
  return e.bind(null, `%c[${Nr}]`, "color: white; background: #1d5d5d; padding: 2px 4px; border-radius: 2px");
}
const Ko = {
  log: Ar(console.log),
  info: Ar(console.info),
  warn: Ar(console.warn),
  error: Ar(console.error)
};
function tp(e, t) {
  let n = 0, r = null;
  return (...o) => {
    const l = Date.now();
    l - n > t && (n = l);
    const i = n + t - l;
    r && clearTimeout(r), r = setTimeout(() => {
      e(...o), r = null, n = Date.now();
    }, i);
  };
}
function np(e) {
  return e instanceof Game;
}
function Co(e) {
  if (!np(e))
    throw new Error("game used before init hook");
}
async function rp(e) {
  return new Promise((t) => setTimeout(t, e));
}
function op(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
var Ba = { exports: {} }, Xo = {}, ba = { exports: {} }, M = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Tr = Symbol.for("react.element"), lp = Symbol.for("react.portal"), ip = Symbol.for("react.fragment"), sp = Symbol.for("react.strict_mode"), up = Symbol.for("react.profiler"), ap = Symbol.for("react.provider"), cp = Symbol.for("react.context"), fp = Symbol.for("react.forward_ref"), dp = Symbol.for("react.suspense"), pp = Symbol.for("react.memo"), hp = Symbol.for("react.lazy"), su = Symbol.iterator;
function mp(e) {
  return e === null || typeof e != "object" ? null : (e = su && e[su] || e["@@iterator"], typeof e == "function" ? e : null);
}
var Ua = { isMounted: function() {
  return !1;
}, enqueueForceUpdate: function() {
}, enqueueReplaceState: function() {
}, enqueueSetState: function() {
} }, Wa = Object.assign, Ha = {};
function Rn(e, t, n) {
  this.props = e, this.context = t, this.refs = Ha, this.updater = n || Ua;
}
Rn.prototype.isReactComponent = {};
Rn.prototype.setState = function(e, t) {
  if (typeof e != "object" && typeof e != "function" && e != null) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
  this.updater.enqueueSetState(this, e, t, "setState");
};
Rn.prototype.forceUpdate = function(e) {
  this.updater.enqueueForceUpdate(this, e, "forceUpdate");
};
function Va() {
}
Va.prototype = Rn.prototype;
function ns(e, t, n) {
  this.props = e, this.context = t, this.refs = Ha, this.updater = n || Ua;
}
var rs = ns.prototype = new Va();
rs.constructor = ns;
Wa(rs, Rn.prototype);
rs.isPureReactComponent = !0;
var uu = Array.isArray, Qa = Object.prototype.hasOwnProperty, os = { current: null }, Ga = { key: !0, ref: !0, __self: !0, __source: !0 };
function Ya(e, t, n) {
  var r, o = {}, l = null, i = null;
  if (t != null) for (r in t.ref !== void 0 && (i = t.ref), t.key !== void 0 && (l = "" + t.key), t) Qa.call(t, r) && !Ga.hasOwnProperty(r) && (o[r] = t[r]);
  var s = arguments.length - 2;
  if (s === 1) o.children = n;
  else if (1 < s) {
    for (var u = Array(s), a = 0; a < s; a++) u[a] = arguments[a + 2];
    o.children = u;
  }
  if (e && e.defaultProps) for (r in s = e.defaultProps, s) o[r] === void 0 && (o[r] = s[r]);
  return { $$typeof: Tr, type: e, key: l, ref: i, props: o, _owner: os.current };
}
function gp(e, t) {
  return { $$typeof: Tr, type: e.type, key: t, ref: e.ref, props: e.props, _owner: e._owner };
}
function ls(e) {
  return typeof e == "object" && e !== null && e.$$typeof === Tr;
}
function yp(e) {
  var t = { "=": "=0", ":": "=2" };
  return "$" + e.replace(/[=:]/g, function(n) {
    return t[n];
  });
}
var au = /\/+/g;
function Rl(e, t) {
  return typeof e == "object" && e !== null && e.key != null ? yp("" + e.key) : t.toString(36);
}
function io(e, t, n, r, o) {
  var l = typeof e;
  (l === "undefined" || l === "boolean") && (e = null);
  var i = !1;
  if (e === null) i = !0;
  else switch (l) {
    case "string":
    case "number":
      i = !0;
      break;
    case "object":
      switch (e.$$typeof) {
        case Tr:
        case lp:
          i = !0;
      }
  }
  if (i) return i = e, o = o(i), e = r === "" ? "." + Rl(i, 0) : r, uu(o) ? (n = "", e != null && (n = e.replace(au, "$&/") + "/"), io(o, t, n, "", function(a) {
    return a;
  })) : o != null && (ls(o) && (o = gp(o, n + (!o.key || i && i.key === o.key ? "" : ("" + o.key).replace(au, "$&/") + "/") + e)), t.push(o)), 1;
  if (i = 0, r = r === "" ? "." : r + ":", uu(e)) for (var s = 0; s < e.length; s++) {
    l = e[s];
    var u = r + Rl(l, s);
    i += io(l, t, n, u, o);
  }
  else if (u = mp(e), typeof u == "function") for (e = u.call(e), s = 0; !(l = e.next()).done; ) l = l.value, u = r + Rl(l, s++), i += io(l, t, n, u, o);
  else if (l === "object") throw t = String(e), Error("Objects are not valid as a React child (found: " + (t === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : t) + "). If you meant to render a collection of children, use an array instead.");
  return i;
}
function jr(e, t, n) {
  if (e == null) return e;
  var r = [], o = 0;
  return io(e, r, "", "", function(l) {
    return t.call(n, l, o++);
  }), r;
}
function vp(e) {
  if (e._status === -1) {
    var t = e._result;
    t = t(), t.then(function(n) {
      (e._status === 0 || e._status === -1) && (e._status = 1, e._result = n);
    }, function(n) {
      (e._status === 0 || e._status === -1) && (e._status = 2, e._result = n);
    }), e._status === -1 && (e._status = 0, e._result = t);
  }
  if (e._status === 1) return e._result.default;
  throw e._result;
}
var ke = { current: null }, so = { transition: null }, wp = { ReactCurrentDispatcher: ke, ReactCurrentBatchConfig: so, ReactCurrentOwner: os };
function Ka() {
  throw Error("act(...) is not supported in production builds of React.");
}
M.Children = { map: jr, forEach: function(e, t, n) {
  jr(e, function() {
    t.apply(this, arguments);
  }, n);
}, count: function(e) {
  var t = 0;
  return jr(e, function() {
    t++;
  }), t;
}, toArray: function(e) {
  return jr(e, function(t) {
    return t;
  }) || [];
}, only: function(e) {
  if (!ls(e)) throw Error("React.Children.only expected to receive a single React element child.");
  return e;
} };
M.Component = Rn;
M.Fragment = ip;
M.Profiler = up;
M.PureComponent = ns;
M.StrictMode = sp;
M.Suspense = dp;
M.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = wp;
M.act = Ka;
M.cloneElement = function(e, t, n) {
  if (e == null) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + e + ".");
  var r = Wa({}, e.props), o = e.key, l = e.ref, i = e._owner;
  if (t != null) {
    if (t.ref !== void 0 && (l = t.ref, i = os.current), t.key !== void 0 && (o = "" + t.key), e.type && e.type.defaultProps) var s = e.type.defaultProps;
    for (u in t) Qa.call(t, u) && !Ga.hasOwnProperty(u) && (r[u] = t[u] === void 0 && s !== void 0 ? s[u] : t[u]);
  }
  var u = arguments.length - 2;
  if (u === 1) r.children = n;
  else if (1 < u) {
    s = Array(u);
    for (var a = 0; a < u; a++) s[a] = arguments[a + 2];
    r.children = s;
  }
  return { $$typeof: Tr, type: e.type, key: o, ref: l, props: r, _owner: i };
};
M.createContext = function(e) {
  return e = { $$typeof: cp, _currentValue: e, _currentValue2: e, _threadCount: 0, Provider: null, Consumer: null, _defaultValue: null, _globalName: null }, e.Provider = { $$typeof: ap, _context: e }, e.Consumer = e;
};
M.createElement = Ya;
M.createFactory = function(e) {
  var t = Ya.bind(null, e);
  return t.type = e, t;
};
M.createRef = function() {
  return { current: null };
};
M.forwardRef = function(e) {
  return { $$typeof: fp, render: e };
};
M.isValidElement = ls;
M.lazy = function(e) {
  return { $$typeof: hp, _payload: { _status: -1, _result: e }, _init: vp };
};
M.memo = function(e, t) {
  return { $$typeof: pp, type: e, compare: t === void 0 ? null : t };
};
M.startTransition = function(e) {
  var t = so.transition;
  so.transition = {};
  try {
    e();
  } finally {
    so.transition = t;
  }
};
M.unstable_act = Ka;
M.useCallback = function(e, t) {
  return ke.current.useCallback(e, t);
};
M.useContext = function(e) {
  return ke.current.useContext(e);
};
M.useDebugValue = function() {
};
M.useDeferredValue = function(e) {
  return ke.current.useDeferredValue(e);
};
M.useEffect = function(e, t) {
  return ke.current.useEffect(e, t);
};
M.useId = function() {
  return ke.current.useId();
};
M.useImperativeHandle = function(e, t, n) {
  return ke.current.useImperativeHandle(e, t, n);
};
M.useInsertionEffect = function(e, t) {
  return ke.current.useInsertionEffect(e, t);
};
M.useLayoutEffect = function(e, t) {
  return ke.current.useLayoutEffect(e, t);
};
M.useMemo = function(e, t) {
  return ke.current.useMemo(e, t);
};
M.useReducer = function(e, t, n) {
  return ke.current.useReducer(e, t, n);
};
M.useRef = function(e) {
  return ke.current.useRef(e);
};
M.useState = function(e) {
  return ke.current.useState(e);
};
M.useSyncExternalStore = function(e, t, n) {
  return ke.current.useSyncExternalStore(e, t, n);
};
M.useTransition = function() {
  return ke.current.useTransition();
};
M.version = "18.3.1";
ba.exports = M;
var y = ba.exports;
const ut = /* @__PURE__ */ op(y), cu = /* @__PURE__ */ Kd({
  __proto__: null,
  default: ut
}, [y]);
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var kp = y, Sp = Symbol.for("react.element"), Cp = Symbol.for("react.fragment"), xp = Object.prototype.hasOwnProperty, Ep = kp.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, Pp = { key: !0, ref: !0, __self: !0, __source: !0 };
function Xa(e, t, n) {
  var r, o = {}, l = null, i = null;
  n !== void 0 && (l = "" + n), t.key !== void 0 && (l = "" + t.key), t.ref !== void 0 && (i = t.ref);
  for (r in t) xp.call(t, r) && !Pp.hasOwnProperty(r) && (o[r] = t[r]);
  if (e && e.defaultProps) for (r in t = e.defaultProps, t) o[r] === void 0 && (o[r] = t[r]);
  return { $$typeof: Sp, type: e, key: l, ref: i, props: o, _owner: Ep.current };
}
Xo.Fragment = Cp;
Xo.jsx = Xa;
Xo.jsxs = Xa;
Ba.exports = Xo;
var ge = Ba.exports, _p = !1;
function Np(e) {
  if (e.sheet)
    return e.sheet;
  for (var t = 0; t < document.styleSheets.length; t++)
    if (document.styleSheets[t].ownerNode === e)
      return document.styleSheets[t];
}
function Tp(e) {
  var t = document.createElement("style");
  return t.setAttribute("data-emotion", e.key), e.nonce !== void 0 && t.setAttribute("nonce", e.nonce), t.appendChild(document.createTextNode("")), t.setAttribute("data-s", ""), t;
}
var Rp = /* @__PURE__ */ function() {
  function e(n) {
    var r = this;
    this._insertTag = function(o) {
      var l;
      r.tags.length === 0 ? r.insertionPoint ? l = r.insertionPoint.nextSibling : r.prepend ? l = r.container.firstChild : l = r.before : l = r.tags[r.tags.length - 1].nextSibling, r.container.insertBefore(o, l), r.tags.push(o);
    }, this.isSpeedy = n.speedy === void 0 ? !_p : n.speedy, this.tags = [], this.ctr = 0, this.nonce = n.nonce, this.key = n.key, this.container = n.container, this.prepend = n.prepend, this.insertionPoint = n.insertionPoint, this.before = null;
  }
  var t = e.prototype;
  return t.hydrate = function(r) {
    r.forEach(this._insertTag);
  }, t.insert = function(r) {
    this.ctr % (this.isSpeedy ? 65e3 : 1) === 0 && this._insertTag(Tp(this));
    var o = this.tags[this.tags.length - 1];
    if (this.isSpeedy) {
      var l = Np(o);
      try {
        l.insertRule(r, l.cssRules.length);
      } catch {
      }
    } else
      o.appendChild(document.createTextNode(r));
    this.ctr++;
  }, t.flush = function() {
    this.tags.forEach(function(r) {
      var o;
      return (o = r.parentNode) == null ? void 0 : o.removeChild(r);
    }), this.tags = [], this.ctr = 0;
  }, e;
}(), he = "-ms-", xo = "-moz-", F = "-webkit-", Za = "comm", is = "rule", ss = "decl", zp = "@import", Ja = "@keyframes", Lp = "@layer", Mp = Math.abs, Zo = String.fromCharCode, Op = Object.assign;
function $p(e, t) {
  return ae(e, 0) ^ 45 ? (((t << 2 ^ ae(e, 0)) << 2 ^ ae(e, 1)) << 2 ^ ae(e, 2)) << 2 ^ ae(e, 3) : 0;
}
function qa(e) {
  return e.trim();
}
function Dp(e, t) {
  return (e = t.exec(e)) ? e[0] : e;
}
function A(e, t, n) {
  return e.replace(t, n);
}
function oi(e, t) {
  return e.indexOf(t);
}
function ae(e, t) {
  return e.charCodeAt(t) | 0;
}
function sr(e, t, n) {
  return e.slice(t, n);
}
function qe(e) {
  return e.length;
}
function us(e) {
  return e.length;
}
function Br(e, t) {
  return t.push(e), e;
}
function Ip(e, t) {
  return e.map(t).join("");
}
var Jo = 1, Sn = 1, ec = 0, Ne = 0, q = 0, zn = "";
function qo(e, t, n, r, o, l, i) {
  return { value: e, root: t, parent: n, type: r, props: o, children: l, line: Jo, column: Sn, length: i, return: "" };
}
function Fn(e, t) {
  return Op(qo("", null, null, "", null, null, 0), e, { length: -e.length }, t);
}
function Fp() {
  return q;
}
function Ap() {
  return q = Ne > 0 ? ae(zn, --Ne) : 0, Sn--, q === 10 && (Sn = 1, Jo--), q;
}
function ze() {
  return q = Ne < ec ? ae(zn, Ne++) : 0, Sn++, q === 10 && (Sn = 1, Jo++), q;
}
function nt() {
  return ae(zn, Ne);
}
function uo() {
  return Ne;
}
function Rr(e, t) {
  return sr(zn, e, t);
}
function ur(e) {
  switch (e) {
    case 0:
    case 9:
    case 10:
    case 13:
    case 32:
      return 5;
    case 33:
    case 43:
    case 44:
    case 47:
    case 62:
    case 64:
    case 126:
    case 59:
    case 123:
    case 125:
      return 4;
    case 58:
      return 3;
    case 34:
    case 39:
    case 40:
    case 91:
      return 2;
    case 41:
    case 93:
      return 1;
  }
  return 0;
}
function tc(e) {
  return Jo = Sn = 1, ec = qe(zn = e), Ne = 0, [];
}
function nc(e) {
  return zn = "", e;
}
function ao(e) {
  return qa(Rr(Ne - 1, li(e === 91 ? e + 2 : e === 40 ? e + 1 : e)));
}
function jp(e) {
  for (; (q = nt()) && q < 33; )
    ze();
  return ur(e) > 2 || ur(q) > 3 ? "" : " ";
}
function Bp(e, t) {
  for (; --t && ze() && !(q < 48 || q > 102 || q > 57 && q < 65 || q > 70 && q < 97); )
    ;
  return Rr(e, uo() + (t < 6 && nt() == 32 && ze() == 32));
}
function li(e) {
  for (; ze(); )
    switch (q) {
      case e:
        return Ne;
      case 34:
      case 39:
        e !== 34 && e !== 39 && li(q);
        break;
      case 40:
        e === 41 && li(e);
        break;
      case 92:
        ze();
        break;
    }
  return Ne;
}
function bp(e, t) {
  for (; ze() && e + q !== 57; )
    if (e + q === 84 && nt() === 47)
      break;
  return "/*" + Rr(t, Ne - 1) + "*" + Zo(e === 47 ? e : ze());
}
function Up(e) {
  for (; !ur(nt()); )
    ze();
  return Rr(e, Ne);
}
function Wp(e) {
  return nc(co("", null, null, null, [""], e = tc(e), 0, [0], e));
}
function co(e, t, n, r, o, l, i, s, u) {
  for (var a = 0, d = 0, p = i, h = 0, g = 0, v = 0, w = 1, R = 1, f = 1, c = 0, m = "", S = o, E = l, P = r, x = m; R; )
    switch (v = c, c = ze()) {
      case 40:
        if (v != 108 && ae(x, p - 1) == 58) {
          oi(x += A(ao(c), "&", "&\f"), "&\f") != -1 && (f = -1);
          break;
        }
      case 34:
      case 39:
      case 91:
        x += ao(c);
        break;
      case 9:
      case 10:
      case 13:
      case 32:
        x += jp(v);
        break;
      case 92:
        x += Bp(uo() - 1, 7);
        continue;
      case 47:
        switch (nt()) {
          case 42:
          case 47:
            Br(Hp(bp(ze(), uo()), t, n), u);
            break;
          default:
            x += "/";
        }
        break;
      case 123 * w:
        s[a++] = qe(x) * f;
      case 125 * w:
      case 59:
      case 0:
        switch (c) {
          case 0:
          case 125:
            R = 0;
          case 59 + d:
            f == -1 && (x = A(x, /\f/g, "")), g > 0 && qe(x) - p && Br(g > 32 ? du(x + ";", r, n, p - 1) : du(A(x, " ", "") + ";", r, n, p - 2), u);
            break;
          case 59:
            x += ";";
          default:
            if (Br(P = fu(x, t, n, a, d, o, s, m, S = [], E = [], p), l), c === 123)
              if (d === 0)
                co(x, t, P, P, S, l, p, s, E);
              else
                switch (h === 99 && ae(x, 3) === 110 ? 100 : h) {
                  case 100:
                  case 108:
                  case 109:
                  case 115:
                    co(e, P, P, r && Br(fu(e, P, P, 0, 0, o, s, m, o, S = [], p), E), o, E, p, s, r ? S : E);
                    break;
                  default:
                    co(x, P, P, P, [""], E, 0, s, E);
                }
        }
        a = d = g = 0, w = f = 1, m = x = "", p = i;
        break;
      case 58:
        p = 1 + qe(x), g = v;
      default:
        if (w < 1) {
          if (c == 123)
            --w;
          else if (c == 125 && w++ == 0 && Ap() == 125)
            continue;
        }
        switch (x += Zo(c), c * w) {
          case 38:
            f = d > 0 ? 1 : (x += "\f", -1);
            break;
          case 44:
            s[a++] = (qe(x) - 1) * f, f = 1;
            break;
          case 64:
            nt() === 45 && (x += ao(ze())), h = nt(), d = p = qe(m = x += Up(uo())), c++;
            break;
          case 45:
            v === 45 && qe(x) == 2 && (w = 0);
        }
    }
  return l;
}
function fu(e, t, n, r, o, l, i, s, u, a, d) {
  for (var p = o - 1, h = o === 0 ? l : [""], g = us(h), v = 0, w = 0, R = 0; v < r; ++v)
    for (var f = 0, c = sr(e, p + 1, p = Mp(w = i[v])), m = e; f < g; ++f)
      (m = qa(w > 0 ? h[f] + " " + c : A(c, /&\f/g, h[f]))) && (u[R++] = m);
  return qo(e, t, n, o === 0 ? is : s, u, a, d);
}
function Hp(e, t, n) {
  return qo(e, t, n, Za, Zo(Fp()), sr(e, 2, -2), 0);
}
function du(e, t, n, r) {
  return qo(e, t, n, ss, sr(e, 0, r), sr(e, r + 1, -1), r);
}
function hn(e, t) {
  for (var n = "", r = us(e), o = 0; o < r; o++)
    n += t(e[o], o, e, t) || "";
  return n;
}
function Vp(e, t, n, r) {
  switch (e.type) {
    case Lp:
      if (e.children.length) break;
    case zp:
    case ss:
      return e.return = e.return || e.value;
    case Za:
      return "";
    case Ja:
      return e.return = e.value + "{" + hn(e.children, r) + "}";
    case is:
      e.value = e.props.join(",");
  }
  return qe(n = hn(e.children, r)) ? e.return = e.value + "{" + n + "}" : "";
}
function Qp(e) {
  var t = us(e);
  return function(n, r, o, l) {
    for (var i = "", s = 0; s < t; s++)
      i += e[s](n, r, o, l) || "";
    return i;
  };
}
function Gp(e) {
  return function(t) {
    t.root || (t = t.return) && e(t);
  };
}
function Yp(e) {
  var t = /* @__PURE__ */ Object.create(null);
  return function(n) {
    return t[n] === void 0 && (t[n] = e(n)), t[n];
  };
}
var Kp = function(t, n, r) {
  for (var o = 0, l = 0; o = l, l = nt(), o === 38 && l === 12 && (n[r] = 1), !ur(l); )
    ze();
  return Rr(t, Ne);
}, Xp = function(t, n) {
  var r = -1, o = 44;
  do
    switch (ur(o)) {
      case 0:
        o === 38 && nt() === 12 && (n[r] = 1), t[r] += Kp(Ne - 1, n, r);
        break;
      case 2:
        t[r] += ao(o);
        break;
      case 4:
        if (o === 44) {
          t[++r] = nt() === 58 ? "&\f" : "", n[r] = t[r].length;
          break;
        }
      default:
        t[r] += Zo(o);
    }
  while (o = ze());
  return t;
}, Zp = function(t, n) {
  return nc(Xp(tc(t), n));
}, pu = /* @__PURE__ */ new WeakMap(), Jp = function(t) {
  if (!(t.type !== "rule" || !t.parent || // positive .length indicates that this rule contains pseudo
  // negative .length indicates that this rule has been already prefixed
  t.length < 1)) {
    for (var n = t.value, r = t.parent, o = t.column === r.column && t.line === r.line; r.type !== "rule"; )
      if (r = r.parent, !r) return;
    if (!(t.props.length === 1 && n.charCodeAt(0) !== 58 && !pu.get(r)) && !o) {
      pu.set(t, !0);
      for (var l = [], i = Zp(n, l), s = r.props, u = 0, a = 0; u < i.length; u++)
        for (var d = 0; d < s.length; d++, a++)
          t.props[a] = l[u] ? i[u].replace(/&\f/g, s[d]) : s[d] + " " + i[u];
    }
  }
}, qp = function(t) {
  if (t.type === "decl") {
    var n = t.value;
    // charcode for l
    n.charCodeAt(0) === 108 && // charcode for b
    n.charCodeAt(2) === 98 && (t.return = "", t.value = "");
  }
};
function rc(e, t) {
  switch ($p(e, t)) {
    case 5103:
      return F + "print-" + e + e;
    case 5737:
    case 4201:
    case 3177:
    case 3433:
    case 1641:
    case 4457:
    case 2921:
    case 5572:
    case 6356:
    case 5844:
    case 3191:
    case 6645:
    case 3005:
    case 6391:
    case 5879:
    case 5623:
    case 6135:
    case 4599:
    case 4855:
    case 4215:
    case 6389:
    case 5109:
    case 5365:
    case 5621:
    case 3829:
      return F + e + e;
    case 5349:
    case 4246:
    case 4810:
    case 6968:
    case 2756:
      return F + e + xo + e + he + e + e;
    case 6828:
    case 4268:
      return F + e + he + e + e;
    case 6165:
      return F + e + he + "flex-" + e + e;
    case 5187:
      return F + e + A(e, /(\w+).+(:[^]+)/, F + "box-$1$2" + he + "flex-$1$2") + e;
    case 5443:
      return F + e + he + "flex-item-" + A(e, /flex-|-self/, "") + e;
    case 4675:
      return F + e + he + "flex-line-pack" + A(e, /align-content|flex-|-self/, "") + e;
    case 5548:
      return F + e + he + A(e, "shrink", "negative") + e;
    case 5292:
      return F + e + he + A(e, "basis", "preferred-size") + e;
    case 6060:
      return F + "box-" + A(e, "-grow", "") + F + e + he + A(e, "grow", "positive") + e;
    case 4554:
      return F + A(e, /([^-])(transform)/g, "$1" + F + "$2") + e;
    case 6187:
      return A(A(A(e, /(zoom-|grab)/, F + "$1"), /(image-set)/, F + "$1"), e, "") + e;
    case 5495:
    case 3959:
      return A(e, /(image-set\([^]*)/, F + "$1$`$1");
    case 4968:
      return A(A(e, /(.+:)(flex-)?(.*)/, F + "box-pack:$3" + he + "flex-pack:$3"), /s.+-b[^;]+/, "justify") + F + e + e;
    case 4095:
    case 3583:
    case 4068:
    case 2532:
      return A(e, /(.+)-inline(.+)/, F + "$1$2") + e;
    case 8116:
    case 7059:
    case 5753:
    case 5535:
    case 5445:
    case 5701:
    case 4933:
    case 4677:
    case 5533:
    case 5789:
    case 5021:
    case 4765:
      if (qe(e) - 1 - t > 6) switch (ae(e, t + 1)) {
        case 109:
          if (ae(e, t + 4) !== 45) break;
        case 102:
          return A(e, /(.+:)(.+)-([^]+)/, "$1" + F + "$2-$3$1" + xo + (ae(e, t + 3) == 108 ? "$3" : "$2-$3")) + e;
        case 115:
          return ~oi(e, "stretch") ? rc(A(e, "stretch", "fill-available"), t) + e : e;
      }
      break;
    case 4949:
      if (ae(e, t + 1) !== 115) break;
    case 6444:
      switch (ae(e, qe(e) - 3 - (~oi(e, "!important") && 10))) {
        case 107:
          return A(e, ":", ":" + F) + e;
        case 101:
          return A(e, /(.+:)([^;!]+)(;|!.+)?/, "$1" + F + (ae(e, 14) === 45 ? "inline-" : "") + "box$3$1" + F + "$2$3$1" + he + "$2box$3") + e;
      }
      break;
    case 5936:
      switch (ae(e, t + 11)) {
        case 114:
          return F + e + he + A(e, /[svh]\w+-[tblr]{2}/, "tb") + e;
        case 108:
          return F + e + he + A(e, /[svh]\w+-[tblr]{2}/, "tb-rl") + e;
        case 45:
          return F + e + he + A(e, /[svh]\w+-[tblr]{2}/, "lr") + e;
      }
      return F + e + he + e + e;
  }
  return e;
}
var eh = function(t, n, r, o) {
  if (t.length > -1 && !t.return) switch (t.type) {
    case ss:
      t.return = rc(t.value, t.length);
      break;
    case Ja:
      return hn([Fn(t, {
        value: A(t.value, "@", "@" + F)
      })], o);
    case is:
      if (t.length) return Ip(t.props, function(l) {
        switch (Dp(l, /(::plac\w+|:read-\w+)/)) {
          case ":read-only":
          case ":read-write":
            return hn([Fn(t, {
              props: [A(l, /:(read-\w+)/, ":" + xo + "$1")]
            })], o);
          case "::placeholder":
            return hn([Fn(t, {
              props: [A(l, /:(plac\w+)/, ":" + F + "input-$1")]
            }), Fn(t, {
              props: [A(l, /:(plac\w+)/, ":" + xo + "$1")]
            }), Fn(t, {
              props: [A(l, /:(plac\w+)/, he + "input-$1")]
            })], o);
        }
        return "";
      });
  }
}, th = [eh], as = function(t) {
  var n = t.key;
  if (n === "css") {
    var r = document.querySelectorAll("style[data-emotion]:not([data-s])");
    Array.prototype.forEach.call(r, function(w) {
      var R = w.getAttribute("data-emotion");
      R.indexOf(" ") !== -1 && (document.head.appendChild(w), w.setAttribute("data-s", ""));
    });
  }
  var o = t.stylisPlugins || th, l = {}, i, s = [];
  i = t.container || document.head, Array.prototype.forEach.call(
    // this means we will ignore elements which don't have a space in them which
    // means that the style elements we're looking at are only Emotion 11 server-rendered style elements
    document.querySelectorAll('style[data-emotion^="' + n + ' "]'),
    function(w) {
      for (var R = w.getAttribute("data-emotion").split(" "), f = 1; f < R.length; f++)
        l[R[f]] = !0;
      s.push(w);
    }
  );
  var u, a = [Jp, qp];
  {
    var d, p = [Vp, Gp(function(w) {
      d.insert(w);
    })], h = Qp(a.concat(o, p)), g = function(R) {
      return hn(Wp(R), h);
    };
    u = function(R, f, c, m) {
      d = c, g(R ? R + "{" + f.styles + "}" : f.styles), m && (v.inserted[f.name] = !0);
    };
  }
  var v = {
    key: n,
    sheet: new Rp({
      key: n,
      container: i,
      nonce: t.nonce,
      speedy: t.speedy,
      prepend: t.prepend,
      insertionPoint: t.insertionPoint
    }),
    nonce: t.nonce,
    inserted: l,
    registered: {},
    insert: u
  };
  return v.sheet.hydrate(s), v;
}, oc = { exports: {} }, B = {};
/** @license React v16.13.1
 * react-is.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var se = typeof Symbol == "function" && Symbol.for, cs = se ? Symbol.for("react.element") : 60103, fs = se ? Symbol.for("react.portal") : 60106, el = se ? Symbol.for("react.fragment") : 60107, tl = se ? Symbol.for("react.strict_mode") : 60108, nl = se ? Symbol.for("react.profiler") : 60114, rl = se ? Symbol.for("react.provider") : 60109, ol = se ? Symbol.for("react.context") : 60110, ds = se ? Symbol.for("react.async_mode") : 60111, ll = se ? Symbol.for("react.concurrent_mode") : 60111, il = se ? Symbol.for("react.forward_ref") : 60112, sl = se ? Symbol.for("react.suspense") : 60113, nh = se ? Symbol.for("react.suspense_list") : 60120, ul = se ? Symbol.for("react.memo") : 60115, al = se ? Symbol.for("react.lazy") : 60116, rh = se ? Symbol.for("react.block") : 60121, oh = se ? Symbol.for("react.fundamental") : 60117, lh = se ? Symbol.for("react.responder") : 60118, ih = se ? Symbol.for("react.scope") : 60119;
function Oe(e) {
  if (typeof e == "object" && e !== null) {
    var t = e.$$typeof;
    switch (t) {
      case cs:
        switch (e = e.type, e) {
          case ds:
          case ll:
          case el:
          case nl:
          case tl:
          case sl:
            return e;
          default:
            switch (e = e && e.$$typeof, e) {
              case ol:
              case il:
              case al:
              case ul:
              case rl:
                return e;
              default:
                return t;
            }
        }
      case fs:
        return t;
    }
  }
}
function lc(e) {
  return Oe(e) === ll;
}
B.AsyncMode = ds;
B.ConcurrentMode = ll;
B.ContextConsumer = ol;
B.ContextProvider = rl;
B.Element = cs;
B.ForwardRef = il;
B.Fragment = el;
B.Lazy = al;
B.Memo = ul;
B.Portal = fs;
B.Profiler = nl;
B.StrictMode = tl;
B.Suspense = sl;
B.isAsyncMode = function(e) {
  return lc(e) || Oe(e) === ds;
};
B.isConcurrentMode = lc;
B.isContextConsumer = function(e) {
  return Oe(e) === ol;
};
B.isContextProvider = function(e) {
  return Oe(e) === rl;
};
B.isElement = function(e) {
  return typeof e == "object" && e !== null && e.$$typeof === cs;
};
B.isForwardRef = function(e) {
  return Oe(e) === il;
};
B.isFragment = function(e) {
  return Oe(e) === el;
};
B.isLazy = function(e) {
  return Oe(e) === al;
};
B.isMemo = function(e) {
  return Oe(e) === ul;
};
B.isPortal = function(e) {
  return Oe(e) === fs;
};
B.isProfiler = function(e) {
  return Oe(e) === nl;
};
B.isStrictMode = function(e) {
  return Oe(e) === tl;
};
B.isSuspense = function(e) {
  return Oe(e) === sl;
};
B.isValidElementType = function(e) {
  return typeof e == "string" || typeof e == "function" || e === el || e === ll || e === nl || e === tl || e === sl || e === nh || typeof e == "object" && e !== null && (e.$$typeof === al || e.$$typeof === ul || e.$$typeof === rl || e.$$typeof === ol || e.$$typeof === il || e.$$typeof === oh || e.$$typeof === lh || e.$$typeof === ih || e.$$typeof === rh);
};
B.typeOf = Oe;
oc.exports = B;
var sh = oc.exports, ic = sh, uh = {
  $$typeof: !0,
  render: !0,
  defaultProps: !0,
  displayName: !0,
  propTypes: !0
}, ah = {
  $$typeof: !0,
  compare: !0,
  defaultProps: !0,
  displayName: !0,
  propTypes: !0,
  type: !0
}, sc = {};
sc[ic.ForwardRef] = uh;
sc[ic.Memo] = ah;
var ch = !0;
function ps(e, t, n) {
  var r = "";
  return n.split(" ").forEach(function(o) {
    e[o] !== void 0 ? t.push(e[o] + ";") : r += o + " ";
  }), r;
}
var uc = function(t, n, r) {
  var o = t.key + "-" + n.name;
  // we only need to add the styles to the registered cache if the
  // class name could be used further down
  // the tree but if it's a string tag, we know it won't
  // so we don't have to add it to registered cache.
  // this improves memory usage since we can avoid storing the whole style string
  (r === !1 || // we need to always store it if we're in compat mode and
  // in node since emotion-server relies on whether a style is in
  // the registered cache to know whether a style is global or not
  // also, note that this check will be dead code eliminated in the browser
  ch === !1) && t.registered[o] === void 0 && (t.registered[o] = n.styles);
}, hs = function(t, n, r) {
  uc(t, n, r);
  var o = t.key + "-" + n.name;
  if (t.inserted[n.name] === void 0) {
    var l = n;
    do
      t.insert(n === l ? "." + o : "", l, t.sheet, !0), l = l.next;
    while (l !== void 0);
  }
};
function fh(e) {
  for (var t = 0, n, r = 0, o = e.length; o >= 4; ++r, o -= 4)
    n = e.charCodeAt(r) & 255 | (e.charCodeAt(++r) & 255) << 8 | (e.charCodeAt(++r) & 255) << 16 | (e.charCodeAt(++r) & 255) << 24, n = /* Math.imul(k, m): */
    (n & 65535) * 1540483477 + ((n >>> 16) * 59797 << 16), n ^= /* k >>> r: */
    n >>> 24, t = /* Math.imul(k, m): */
    (n & 65535) * 1540483477 + ((n >>> 16) * 59797 << 16) ^ /* Math.imul(h, m): */
    (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16);
  switch (o) {
    case 3:
      t ^= (e.charCodeAt(r + 2) & 255) << 16;
    case 2:
      t ^= (e.charCodeAt(r + 1) & 255) << 8;
    case 1:
      t ^= e.charCodeAt(r) & 255, t = /* Math.imul(h, m): */
      (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16);
  }
  return t ^= t >>> 13, t = /* Math.imul(h, m): */
  (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16), ((t ^ t >>> 15) >>> 0).toString(36);
}
var dh = {
  animationIterationCount: 1,
  aspectRatio: 1,
  borderImageOutset: 1,
  borderImageSlice: 1,
  borderImageWidth: 1,
  boxFlex: 1,
  boxFlexGroup: 1,
  boxOrdinalGroup: 1,
  columnCount: 1,
  columns: 1,
  flex: 1,
  flexGrow: 1,
  flexPositive: 1,
  flexShrink: 1,
  flexNegative: 1,
  flexOrder: 1,
  gridRow: 1,
  gridRowEnd: 1,
  gridRowSpan: 1,
  gridRowStart: 1,
  gridColumn: 1,
  gridColumnEnd: 1,
  gridColumnSpan: 1,
  gridColumnStart: 1,
  msGridRow: 1,
  msGridRowSpan: 1,
  msGridColumn: 1,
  msGridColumnSpan: 1,
  fontWeight: 1,
  lineHeight: 1,
  opacity: 1,
  order: 1,
  orphans: 1,
  scale: 1,
  tabSize: 1,
  widows: 1,
  zIndex: 1,
  zoom: 1,
  WebkitLineClamp: 1,
  // SVG-related properties
  fillOpacity: 1,
  floodOpacity: 1,
  stopOpacity: 1,
  strokeDasharray: 1,
  strokeDashoffset: 1,
  strokeMiterlimit: 1,
  strokeOpacity: 1,
  strokeWidth: 1
}, ph = !1, hh = /[A-Z]|^ms/g, mh = /_EMO_([^_]+?)_([^]*?)_EMO_/g, ac = function(t) {
  return t.charCodeAt(1) === 45;
}, hu = function(t) {
  return t != null && typeof t != "boolean";
}, zl = /* @__PURE__ */ Yp(function(e) {
  return ac(e) ? e : e.replace(hh, "-$&").toLowerCase();
}), mu = function(t, n) {
  switch (t) {
    case "animation":
    case "animationName":
      if (typeof n == "string")
        return n.replace(mh, function(r, o, l) {
          return et = {
            name: o,
            styles: l,
            next: et
          }, o;
        });
  }
  return dh[t] !== 1 && !ac(t) && typeof n == "number" && n !== 0 ? n + "px" : n;
}, gh = "Component selectors can only be used in conjunction with @emotion/babel-plugin, the swc Emotion plugin, or another Emotion-aware compiler transform.";
function ar(e, t, n) {
  if (n == null)
    return "";
  var r = n;
  if (r.__emotion_styles !== void 0)
    return r;
  switch (typeof n) {
    case "boolean":
      return "";
    case "object": {
      var o = n;
      if (o.anim === 1)
        return et = {
          name: o.name,
          styles: o.styles,
          next: et
        }, o.name;
      var l = n;
      if (l.styles !== void 0) {
        var i = l.next;
        if (i !== void 0)
          for (; i !== void 0; )
            et = {
              name: i.name,
              styles: i.styles,
              next: et
            }, i = i.next;
        var s = l.styles + ";";
        return s;
      }
      return yh(e, t, n);
    }
    case "function": {
      if (e !== void 0) {
        var u = et, a = n(e);
        return et = u, ar(e, t, a);
      }
      break;
    }
  }
  var d = n;
  if (t == null)
    return d;
  var p = t[d];
  return p !== void 0 ? p : d;
}
function yh(e, t, n) {
  var r = "";
  if (Array.isArray(n))
    for (var o = 0; o < n.length; o++)
      r += ar(e, t, n[o]) + ";";
  else
    for (var l in n) {
      var i = n[l];
      if (typeof i != "object") {
        var s = i;
        t != null && t[s] !== void 0 ? r += l + "{" + t[s] + "}" : hu(s) && (r += zl(l) + ":" + mu(l, s) + ";");
      } else {
        if (l === "NO_COMPONENT_SELECTOR" && ph)
          throw new Error(gh);
        if (Array.isArray(i) && typeof i[0] == "string" && (t == null || t[i[0]] === void 0))
          for (var u = 0; u < i.length; u++)
            hu(i[u]) && (r += zl(l) + ":" + mu(l, i[u]) + ";");
        else {
          var a = ar(e, t, i);
          switch (l) {
            case "animation":
            case "animationName": {
              r += zl(l) + ":" + a + ";";
              break;
            }
            default:
              r += l + "{" + a + "}";
          }
        }
      }
    }
  return r;
}
var gu = /label:\s*([^\s;\n{]+)\s*(;|$)/g, et;
function Xn(e, t, n) {
  if (e.length === 1 && typeof e[0] == "object" && e[0] !== null && e[0].styles !== void 0)
    return e[0];
  var r = !0, o = "";
  et = void 0;
  var l = e[0];
  if (l == null || l.raw === void 0)
    r = !1, o += ar(n, t, l);
  else {
    var i = l;
    o += i[0];
  }
  for (var s = 1; s < e.length; s++)
    if (o += ar(n, t, e[s]), r) {
      var u = l;
      o += u[s];
    }
  gu.lastIndex = 0;
  for (var a = "", d; (d = gu.exec(o)) !== null; )
    a += "-" + d[1];
  var p = fh(o) + a;
  return {
    name: p,
    styles: o,
    next: et
  };
}
var vh = function(t) {
  return t();
}, cc = cu.useInsertionEffect ? cu.useInsertionEffect : !1, wh = cc || vh, yu = cc || y.useLayoutEffect, kh = !1, fc = /* @__PURE__ */ y.createContext(
  // we're doing this to avoid preconstruct's dead code elimination in this one case
  // because this module is primarily intended for the browser and node
  // but it's also required in react native and similar environments sometimes
  // and we could have a special build just for that
  // but this is much easier and the native packages
  // might use a different theme context in the future anyway
  typeof HTMLElement < "u" ? /* @__PURE__ */ as({
    key: "css"
  }) : null
), Sh = fc.Provider, dc = function(t) {
  return /* @__PURE__ */ y.forwardRef(function(n, r) {
    var o = y.useContext(fc);
    return t(n, o, r);
  });
}, pc = /* @__PURE__ */ y.createContext({}), cl = {}.hasOwnProperty, ii = "__EMOTION_TYPE_PLEASE_DO_NOT_USE__", hc = function(t, n) {
  var r = {};
  for (var o in n)
    cl.call(n, o) && (r[o] = n[o]);
  return r[ii] = t, r;
}, Ch = function(t) {
  var n = t.cache, r = t.serialized, o = t.isStringTag;
  return uc(n, r, o), wh(function() {
    return hs(n, r, o);
  }), null;
}, xh = /* @__PURE__ */ dc(
  /* <any, any> */
  function(e, t, n) {
    var r = e.css;
    typeof r == "string" && t.registered[r] !== void 0 && (r = t.registered[r]);
    var o = e[ii], l = [r], i = "";
    typeof e.className == "string" ? i = ps(t.registered, l, e.className) : e.className != null && (i = e.className + " ");
    var s = Xn(l, void 0, y.useContext(pc));
    i += t.key + "-" + s.name;
    var u = {};
    for (var a in e)
      cl.call(e, a) && a !== "css" && a !== ii && !kh && (u[a] = e[a]);
    return u.className = i, n && (u.ref = n), /* @__PURE__ */ y.createElement(y.Fragment, null, /* @__PURE__ */ y.createElement(Ch, {
      cache: t,
      serialized: s,
      isStringTag: typeof o == "string"
    }), /* @__PURE__ */ y.createElement(o, u));
  }
), mc = xh, Eh = ge.Fragment;
function k(e, t, n) {
  return cl.call(t, "css") ? ge.jsx(mc, hc(e, t), n) : ge.jsx(e, t, n);
}
function D(e, t, n) {
  return cl.call(t, "css") ? ge.jsxs(mc, hc(e, t), n) : ge.jsxs(e, t, n);
}
var gc = { exports: {} }, $e = {}, yc = { exports: {} }, vc = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
(function(e) {
  function t(N, z) {
    var L = N.length;
    N.push(z);
    e: for (; 0 < L; ) {
      var Z = L - 1 >>> 1, re = N[Z];
      if (0 < o(re, z)) N[Z] = z, N[L] = re, L = Z;
      else break e;
    }
  }
  function n(N) {
    return N.length === 0 ? null : N[0];
  }
  function r(N) {
    if (N.length === 0) return null;
    var z = N[0], L = N.pop();
    if (L !== z) {
      N[0] = L;
      e: for (var Z = 0, re = N.length, Ir = re >>> 1; Z < Ir; ) {
        var Ft = 2 * (Z + 1) - 1, Tl = N[Ft], At = Ft + 1, Fr = N[At];
        if (0 > o(Tl, L)) At < re && 0 > o(Fr, Tl) ? (N[Z] = Fr, N[At] = L, Z = At) : (N[Z] = Tl, N[Ft] = L, Z = Ft);
        else if (At < re && 0 > o(Fr, L)) N[Z] = Fr, N[At] = L, Z = At;
        else break e;
      }
    }
    return z;
  }
  function o(N, z) {
    var L = N.sortIndex - z.sortIndex;
    return L !== 0 ? L : N.id - z.id;
  }
  if (typeof performance == "object" && typeof performance.now == "function") {
    var l = performance;
    e.unstable_now = function() {
      return l.now();
    };
  } else {
    var i = Date, s = i.now();
    e.unstable_now = function() {
      return i.now() - s;
    };
  }
  var u = [], a = [], d = 1, p = null, h = 3, g = !1, v = !1, w = !1, R = typeof setTimeout == "function" ? setTimeout : null, f = typeof clearTimeout == "function" ? clearTimeout : null, c = typeof setImmediate < "u" ? setImmediate : null;
  typeof navigator < "u" && navigator.scheduling !== void 0 && navigator.scheduling.isInputPending !== void 0 && navigator.scheduling.isInputPending.bind(navigator.scheduling);
  function m(N) {
    for (var z = n(a); z !== null; ) {
      if (z.callback === null) r(a);
      else if (z.startTime <= N) r(a), z.sortIndex = z.expirationTime, t(u, z);
      else break;
      z = n(a);
    }
  }
  function S(N) {
    if (w = !1, m(N), !v) if (n(u) !== null) v = !0, _l(E);
    else {
      var z = n(a);
      z !== null && Nl(S, z.startTime - N);
    }
  }
  function E(N, z) {
    v = !1, w && (w = !1, f(T), T = -1), g = !0;
    var L = h;
    try {
      for (m(z), p = n(u); p !== null && (!(p.expirationTime > z) || N && !Ue()); ) {
        var Z = p.callback;
        if (typeof Z == "function") {
          p.callback = null, h = p.priorityLevel;
          var re = Z(p.expirationTime <= z);
          z = e.unstable_now(), typeof re == "function" ? p.callback = re : p === n(u) && r(u), m(z);
        } else r(u);
        p = n(u);
      }
      if (p !== null) var Ir = !0;
      else {
        var Ft = n(a);
        Ft !== null && Nl(S, Ft.startTime - z), Ir = !1;
      }
      return Ir;
    } finally {
      p = null, h = L, g = !1;
    }
  }
  var P = !1, x = null, T = -1, X = 5, O = -1;
  function Ue() {
    return !(e.unstable_now() - O < X);
  }
  function Dn() {
    if (x !== null) {
      var N = e.unstable_now();
      O = N;
      var z = !0;
      try {
        z = x(!0, N);
      } finally {
        z ? In() : (P = !1, x = null);
      }
    } else P = !1;
  }
  var In;
  if (typeof c == "function") In = function() {
    c(Dn);
  };
  else if (typeof MessageChannel < "u") {
    var iu = new MessageChannel(), Yd = iu.port2;
    iu.port1.onmessage = Dn, In = function() {
      Yd.postMessage(null);
    };
  } else In = function() {
    R(Dn, 0);
  };
  function _l(N) {
    x = N, P || (P = !0, In());
  }
  function Nl(N, z) {
    T = R(function() {
      N(e.unstable_now());
    }, z);
  }
  e.unstable_IdlePriority = 5, e.unstable_ImmediatePriority = 1, e.unstable_LowPriority = 4, e.unstable_NormalPriority = 3, e.unstable_Profiling = null, e.unstable_UserBlockingPriority = 2, e.unstable_cancelCallback = function(N) {
    N.callback = null;
  }, e.unstable_continueExecution = function() {
    v || g || (v = !0, _l(E));
  }, e.unstable_forceFrameRate = function(N) {
    0 > N || 125 < N ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : X = 0 < N ? Math.floor(1e3 / N) : 5;
  }, e.unstable_getCurrentPriorityLevel = function() {
    return h;
  }, e.unstable_getFirstCallbackNode = function() {
    return n(u);
  }, e.unstable_next = function(N) {
    switch (h) {
      case 1:
      case 2:
      case 3:
        var z = 3;
        break;
      default:
        z = h;
    }
    var L = h;
    h = z;
    try {
      return N();
    } finally {
      h = L;
    }
  }, e.unstable_pauseExecution = function() {
  }, e.unstable_requestPaint = function() {
  }, e.unstable_runWithPriority = function(N, z) {
    switch (N) {
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
        break;
      default:
        N = 3;
    }
    var L = h;
    h = N;
    try {
      return z();
    } finally {
      h = L;
    }
  }, e.unstable_scheduleCallback = function(N, z, L) {
    var Z = e.unstable_now();
    switch (typeof L == "object" && L !== null ? (L = L.delay, L = typeof L == "number" && 0 < L ? Z + L : Z) : L = Z, N) {
      case 1:
        var re = -1;
        break;
      case 2:
        re = 250;
        break;
      case 5:
        re = 1073741823;
        break;
      case 4:
        re = 1e4;
        break;
      default:
        re = 5e3;
    }
    return re = L + re, N = { id: d++, callback: z, priorityLevel: N, startTime: L, expirationTime: re, sortIndex: -1 }, L > Z ? (N.sortIndex = L, t(a, N), n(u) === null && N === n(a) && (w ? (f(T), T = -1) : w = !0, Nl(S, L - Z))) : (N.sortIndex = re, t(u, N), v || g || (v = !0, _l(E))), N;
  }, e.unstable_shouldYield = Ue, e.unstable_wrapCallback = function(N) {
    var z = h;
    return function() {
      var L = h;
      h = z;
      try {
        return N.apply(this, arguments);
      } finally {
        h = L;
      }
    };
  };
})(vc);
yc.exports = vc;
var Ph = yc.exports;
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var _h = y, Me = Ph;
function C(e) {
  for (var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, n = 1; n < arguments.length; n++) t += "&args[]=" + encodeURIComponent(arguments[n]);
  return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
}
var wc = /* @__PURE__ */ new Set(), cr = {};
function Jt(e, t) {
  Cn(e, t), Cn(e + "Capture", t);
}
function Cn(e, t) {
  for (cr[e] = t, e = 0; e < t.length; e++) wc.add(t[e]);
}
var dt = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"), si = Object.prototype.hasOwnProperty, Nh = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/, vu = {}, wu = {};
function Th(e) {
  return si.call(wu, e) ? !0 : si.call(vu, e) ? !1 : Nh.test(e) ? wu[e] = !0 : (vu[e] = !0, !1);
}
function Rh(e, t, n, r) {
  if (n !== null && n.type === 0) return !1;
  switch (typeof t) {
    case "function":
    case "symbol":
      return !0;
    case "boolean":
      return r ? !1 : n !== null ? !n.acceptsBooleans : (e = e.toLowerCase().slice(0, 5), e !== "data-" && e !== "aria-");
    default:
      return !1;
  }
}
function zh(e, t, n, r) {
  if (t === null || typeof t > "u" || Rh(e, t, n, r)) return !0;
  if (r) return !1;
  if (n !== null) switch (n.type) {
    case 3:
      return !t;
    case 4:
      return t === !1;
    case 5:
      return isNaN(t);
    case 6:
      return isNaN(t) || 1 > t;
  }
  return !1;
}
function Se(e, t, n, r, o, l, i) {
  this.acceptsBooleans = t === 2 || t === 3 || t === 4, this.attributeName = r, this.attributeNamespace = o, this.mustUseProperty = n, this.propertyName = e, this.type = t, this.sanitizeURL = l, this.removeEmptyString = i;
}
var fe = {};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e) {
  fe[e] = new Se(e, 0, !1, e, null, !1, !1);
});
[["acceptCharset", "accept-charset"], ["className", "class"], ["htmlFor", "for"], ["httpEquiv", "http-equiv"]].forEach(function(e) {
  var t = e[0];
  fe[t] = new Se(t, 1, !1, e[1], null, !1, !1);
});
["contentEditable", "draggable", "spellCheck", "value"].forEach(function(e) {
  fe[e] = new Se(e, 2, !1, e.toLowerCase(), null, !1, !1);
});
["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(e) {
  fe[e] = new Se(e, 2, !1, e, null, !1, !1);
});
"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e) {
  fe[e] = new Se(e, 3, !1, e.toLowerCase(), null, !1, !1);
});
["checked", "multiple", "muted", "selected"].forEach(function(e) {
  fe[e] = new Se(e, 3, !0, e, null, !1, !1);
});
["capture", "download"].forEach(function(e) {
  fe[e] = new Se(e, 4, !1, e, null, !1, !1);
});
["cols", "rows", "size", "span"].forEach(function(e) {
  fe[e] = new Se(e, 6, !1, e, null, !1, !1);
});
["rowSpan", "start"].forEach(function(e) {
  fe[e] = new Se(e, 5, !1, e.toLowerCase(), null, !1, !1);
});
var ms = /[\-:]([a-z])/g;
function gs(e) {
  return e[1].toUpperCase();
}
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e) {
  var t = e.replace(
    ms,
    gs
  );
  fe[t] = new Se(t, 1, !1, e, null, !1, !1);
});
"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e) {
  var t = e.replace(ms, gs);
  fe[t] = new Se(t, 1, !1, e, "http://www.w3.org/1999/xlink", !1, !1);
});
["xml:base", "xml:lang", "xml:space"].forEach(function(e) {
  var t = e.replace(ms, gs);
  fe[t] = new Se(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace", !1, !1);
});
["tabIndex", "crossOrigin"].forEach(function(e) {
  fe[e] = new Se(e, 1, !1, e.toLowerCase(), null, !1, !1);
});
fe.xlinkHref = new Se("xlinkHref", 1, !1, "xlink:href", "http://www.w3.org/1999/xlink", !0, !1);
["src", "href", "action", "formAction"].forEach(function(e) {
  fe[e] = new Se(e, 1, !1, e.toLowerCase(), null, !0, !0);
});
function ys(e, t, n, r) {
  var o = fe.hasOwnProperty(t) ? fe[t] : null;
  (o !== null ? o.type !== 0 : r || !(2 < t.length) || t[0] !== "o" && t[0] !== "O" || t[1] !== "n" && t[1] !== "N") && (zh(t, n, o, r) && (n = null), r || o === null ? Th(t) && (n === null ? e.removeAttribute(t) : e.setAttribute(t, "" + n)) : o.mustUseProperty ? e[o.propertyName] = n === null ? o.type === 3 ? !1 : "" : n : (t = o.attributeName, r = o.attributeNamespace, n === null ? e.removeAttribute(t) : (o = o.type, n = o === 3 || o === 4 && n === !0 ? "" : "" + n, r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))));
}
var gt = _h.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED, br = Symbol.for("react.element"), tn = Symbol.for("react.portal"), nn = Symbol.for("react.fragment"), vs = Symbol.for("react.strict_mode"), ui = Symbol.for("react.profiler"), kc = Symbol.for("react.provider"), Sc = Symbol.for("react.context"), ws = Symbol.for("react.forward_ref"), ai = Symbol.for("react.suspense"), ci = Symbol.for("react.suspense_list"), ks = Symbol.for("react.memo"), vt = Symbol.for("react.lazy"), Cc = Symbol.for("react.offscreen"), ku = Symbol.iterator;
function An(e) {
  return e === null || typeof e != "object" ? null : (e = ku && e[ku] || e["@@iterator"], typeof e == "function" ? e : null);
}
var Y = Object.assign, Ll;
function Qn(e) {
  if (Ll === void 0) try {
    throw Error();
  } catch (n) {
    var t = n.stack.trim().match(/\n( *(at )?)/);
    Ll = t && t[1] || "";
  }
  return `
` + Ll + e;
}
var Ml = !1;
function Ol(e, t) {
  if (!e || Ml) return "";
  Ml = !0;
  var n = Error.prepareStackTrace;
  Error.prepareStackTrace = void 0;
  try {
    if (t) if (t = function() {
      throw Error();
    }, Object.defineProperty(t.prototype, "props", { set: function() {
      throw Error();
    } }), typeof Reflect == "object" && Reflect.construct) {
      try {
        Reflect.construct(t, []);
      } catch (a) {
        var r = a;
      }
      Reflect.construct(e, [], t);
    } else {
      try {
        t.call();
      } catch (a) {
        r = a;
      }
      e.call(t.prototype);
    }
    else {
      try {
        throw Error();
      } catch (a) {
        r = a;
      }
      e();
    }
  } catch (a) {
    if (a && r && typeof a.stack == "string") {
      for (var o = a.stack.split(`
`), l = r.stack.split(`
`), i = o.length - 1, s = l.length - 1; 1 <= i && 0 <= s && o[i] !== l[s]; ) s--;
      for (; 1 <= i && 0 <= s; i--, s--) if (o[i] !== l[s]) {
        if (i !== 1 || s !== 1)
          do
            if (i--, s--, 0 > s || o[i] !== l[s]) {
              var u = `
` + o[i].replace(" at new ", " at ");
              return e.displayName && u.includes("<anonymous>") && (u = u.replace("<anonymous>", e.displayName)), u;
            }
          while (1 <= i && 0 <= s);
        break;
      }
    }
  } finally {
    Ml = !1, Error.prepareStackTrace = n;
  }
  return (e = e ? e.displayName || e.name : "") ? Qn(e) : "";
}
function Lh(e) {
  switch (e.tag) {
    case 5:
      return Qn(e.type);
    case 16:
      return Qn("Lazy");
    case 13:
      return Qn("Suspense");
    case 19:
      return Qn("SuspenseList");
    case 0:
    case 2:
    case 15:
      return e = Ol(e.type, !1), e;
    case 11:
      return e = Ol(e.type.render, !1), e;
    case 1:
      return e = Ol(e.type, !0), e;
    default:
      return "";
  }
}
function fi(e) {
  if (e == null) return null;
  if (typeof e == "function") return e.displayName || e.name || null;
  if (typeof e == "string") return e;
  switch (e) {
    case nn:
      return "Fragment";
    case tn:
      return "Portal";
    case ui:
      return "Profiler";
    case vs:
      return "StrictMode";
    case ai:
      return "Suspense";
    case ci:
      return "SuspenseList";
  }
  if (typeof e == "object") switch (e.$$typeof) {
    case Sc:
      return (e.displayName || "Context") + ".Consumer";
    case kc:
      return (e._context.displayName || "Context") + ".Provider";
    case ws:
      var t = e.render;
      return e = e.displayName, e || (e = t.displayName || t.name || "", e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
    case ks:
      return t = e.displayName || null, t !== null ? t : fi(e.type) || "Memo";
    case vt:
      t = e._payload, e = e._init;
      try {
        return fi(e(t));
      } catch {
      }
  }
  return null;
}
function Mh(e) {
  var t = e.type;
  switch (e.tag) {
    case 24:
      return "Cache";
    case 9:
      return (t.displayName || "Context") + ".Consumer";
    case 10:
      return (t._context.displayName || "Context") + ".Provider";
    case 18:
      return "DehydratedFragment";
    case 11:
      return e = t.render, e = e.displayName || e.name || "", t.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef");
    case 7:
      return "Fragment";
    case 5:
      return t;
    case 4:
      return "Portal";
    case 3:
      return "Root";
    case 6:
      return "Text";
    case 16:
      return fi(t);
    case 8:
      return t === vs ? "StrictMode" : "Mode";
    case 22:
      return "Offscreen";
    case 12:
      return "Profiler";
    case 21:
      return "Scope";
    case 13:
      return "Suspense";
    case 19:
      return "SuspenseList";
    case 25:
      return "TracingMarker";
    case 1:
    case 0:
    case 17:
    case 2:
    case 14:
    case 15:
      if (typeof t == "function") return t.displayName || t.name || null;
      if (typeof t == "string") return t;
  }
  return null;
}
function Mt(e) {
  switch (typeof e) {
    case "boolean":
    case "number":
    case "string":
    case "undefined":
      return e;
    case "object":
      return e;
    default:
      return "";
  }
}
function xc(e) {
  var t = e.type;
  return (e = e.nodeName) && e.toLowerCase() === "input" && (t === "checkbox" || t === "radio");
}
function Oh(e) {
  var t = xc(e) ? "checked" : "value", n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t), r = "" + e[t];
  if (!e.hasOwnProperty(t) && typeof n < "u" && typeof n.get == "function" && typeof n.set == "function") {
    var o = n.get, l = n.set;
    return Object.defineProperty(e, t, { configurable: !0, get: function() {
      return o.call(this);
    }, set: function(i) {
      r = "" + i, l.call(this, i);
    } }), Object.defineProperty(e, t, { enumerable: n.enumerable }), { getValue: function() {
      return r;
    }, setValue: function(i) {
      r = "" + i;
    }, stopTracking: function() {
      e._valueTracker = null, delete e[t];
    } };
  }
}
function Ur(e) {
  e._valueTracker || (e._valueTracker = Oh(e));
}
function Ec(e) {
  if (!e) return !1;
  var t = e._valueTracker;
  if (!t) return !0;
  var n = t.getValue(), r = "";
  return e && (r = xc(e) ? e.checked ? "true" : "false" : e.value), e = r, e !== n ? (t.setValue(e), !0) : !1;
}
function Eo(e) {
  if (e = e || (typeof document < "u" ? document : void 0), typeof e > "u") return null;
  try {
    return e.activeElement || e.body;
  } catch {
    return e.body;
  }
}
function di(e, t) {
  var n = t.checked;
  return Y({}, t, { defaultChecked: void 0, defaultValue: void 0, value: void 0, checked: n ?? e._wrapperState.initialChecked });
}
function Su(e, t) {
  var n = t.defaultValue == null ? "" : t.defaultValue, r = t.checked != null ? t.checked : t.defaultChecked;
  n = Mt(t.value != null ? t.value : n), e._wrapperState = { initialChecked: r, initialValue: n, controlled: t.type === "checkbox" || t.type === "radio" ? t.checked != null : t.value != null };
}
function Pc(e, t) {
  t = t.checked, t != null && ys(e, "checked", t, !1);
}
function pi(e, t) {
  Pc(e, t);
  var n = Mt(t.value), r = t.type;
  if (n != null) r === "number" ? (n === 0 && e.value === "" || e.value != n) && (e.value = "" + n) : e.value !== "" + n && (e.value = "" + n);
  else if (r === "submit" || r === "reset") {
    e.removeAttribute("value");
    return;
  }
  t.hasOwnProperty("value") ? hi(e, t.type, n) : t.hasOwnProperty("defaultValue") && hi(e, t.type, Mt(t.defaultValue)), t.checked == null && t.defaultChecked != null && (e.defaultChecked = !!t.defaultChecked);
}
function Cu(e, t, n) {
  if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
    var r = t.type;
    if (!(r !== "submit" && r !== "reset" || t.value !== void 0 && t.value !== null)) return;
    t = "" + e._wrapperState.initialValue, n || t === e.value || (e.value = t), e.defaultValue = t;
  }
  n = e.name, n !== "" && (e.name = ""), e.defaultChecked = !!e._wrapperState.initialChecked, n !== "" && (e.name = n);
}
function hi(e, t, n) {
  (t !== "number" || Eo(e.ownerDocument) !== e) && (n == null ? e.defaultValue = "" + e._wrapperState.initialValue : e.defaultValue !== "" + n && (e.defaultValue = "" + n));
}
var Gn = Array.isArray;
function mn(e, t, n, r) {
  if (e = e.options, t) {
    t = {};
    for (var o = 0; o < n.length; o++) t["$" + n[o]] = !0;
    for (n = 0; n < e.length; n++) o = t.hasOwnProperty("$" + e[n].value), e[n].selected !== o && (e[n].selected = o), o && r && (e[n].defaultSelected = !0);
  } else {
    for (n = "" + Mt(n), t = null, o = 0; o < e.length; o++) {
      if (e[o].value === n) {
        e[o].selected = !0, r && (e[o].defaultSelected = !0);
        return;
      }
      t !== null || e[o].disabled || (t = e[o]);
    }
    t !== null && (t.selected = !0);
  }
}
function mi(e, t) {
  if (t.dangerouslySetInnerHTML != null) throw Error(C(91));
  return Y({}, t, { value: void 0, defaultValue: void 0, children: "" + e._wrapperState.initialValue });
}
function xu(e, t) {
  var n = t.value;
  if (n == null) {
    if (n = t.children, t = t.defaultValue, n != null) {
      if (t != null) throw Error(C(92));
      if (Gn(n)) {
        if (1 < n.length) throw Error(C(93));
        n = n[0];
      }
      t = n;
    }
    t == null && (t = ""), n = t;
  }
  e._wrapperState = { initialValue: Mt(n) };
}
function _c(e, t) {
  var n = Mt(t.value), r = Mt(t.defaultValue);
  n != null && (n = "" + n, n !== e.value && (e.value = n), t.defaultValue == null && e.defaultValue !== n && (e.defaultValue = n)), r != null && (e.defaultValue = "" + r);
}
function Eu(e) {
  var t = e.textContent;
  t === e._wrapperState.initialValue && t !== "" && t !== null && (e.value = t);
}
function Nc(e) {
  switch (e) {
    case "svg":
      return "http://www.w3.org/2000/svg";
    case "math":
      return "http://www.w3.org/1998/Math/MathML";
    default:
      return "http://www.w3.org/1999/xhtml";
  }
}
function gi(e, t) {
  return e == null || e === "http://www.w3.org/1999/xhtml" ? Nc(t) : e === "http://www.w3.org/2000/svg" && t === "foreignObject" ? "http://www.w3.org/1999/xhtml" : e;
}
var Wr, Tc = function(e) {
  return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction ? function(t, n, r, o) {
    MSApp.execUnsafeLocalFunction(function() {
      return e(t, n, r, o);
    });
  } : e;
}(function(e, t) {
  if (e.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in e) e.innerHTML = t;
  else {
    for (Wr = Wr || document.createElement("div"), Wr.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>", t = Wr.firstChild; e.firstChild; ) e.removeChild(e.firstChild);
    for (; t.firstChild; ) e.appendChild(t.firstChild);
  }
});
function fr(e, t) {
  if (t) {
    var n = e.firstChild;
    if (n && n === e.lastChild && n.nodeType === 3) {
      n.nodeValue = t;
      return;
    }
  }
  e.textContent = t;
}
var Zn = {
  animationIterationCount: !0,
  aspectRatio: !0,
  borderImageOutset: !0,
  borderImageSlice: !0,
  borderImageWidth: !0,
  boxFlex: !0,
  boxFlexGroup: !0,
  boxOrdinalGroup: !0,
  columnCount: !0,
  columns: !0,
  flex: !0,
  flexGrow: !0,
  flexPositive: !0,
  flexShrink: !0,
  flexNegative: !0,
  flexOrder: !0,
  gridArea: !0,
  gridRow: !0,
  gridRowEnd: !0,
  gridRowSpan: !0,
  gridRowStart: !0,
  gridColumn: !0,
  gridColumnEnd: !0,
  gridColumnSpan: !0,
  gridColumnStart: !0,
  fontWeight: !0,
  lineClamp: !0,
  lineHeight: !0,
  opacity: !0,
  order: !0,
  orphans: !0,
  tabSize: !0,
  widows: !0,
  zIndex: !0,
  zoom: !0,
  fillOpacity: !0,
  floodOpacity: !0,
  stopOpacity: !0,
  strokeDasharray: !0,
  strokeDashoffset: !0,
  strokeMiterlimit: !0,
  strokeOpacity: !0,
  strokeWidth: !0
}, $h = ["Webkit", "ms", "Moz", "O"];
Object.keys(Zn).forEach(function(e) {
  $h.forEach(function(t) {
    t = t + e.charAt(0).toUpperCase() + e.substring(1), Zn[t] = Zn[e];
  });
});
function Rc(e, t, n) {
  return t == null || typeof t == "boolean" || t === "" ? "" : n || typeof t != "number" || t === 0 || Zn.hasOwnProperty(e) && Zn[e] ? ("" + t).trim() : t + "px";
}
function zc(e, t) {
  e = e.style;
  for (var n in t) if (t.hasOwnProperty(n)) {
    var r = n.indexOf("--") === 0, o = Rc(n, t[n], r);
    n === "float" && (n = "cssFloat"), r ? e.setProperty(n, o) : e[n] = o;
  }
}
var Dh = Y({ menuitem: !0 }, { area: !0, base: !0, br: !0, col: !0, embed: !0, hr: !0, img: !0, input: !0, keygen: !0, link: !0, meta: !0, param: !0, source: !0, track: !0, wbr: !0 });
function yi(e, t) {
  if (t) {
    if (Dh[e] && (t.children != null || t.dangerouslySetInnerHTML != null)) throw Error(C(137, e));
    if (t.dangerouslySetInnerHTML != null) {
      if (t.children != null) throw Error(C(60));
      if (typeof t.dangerouslySetInnerHTML != "object" || !("__html" in t.dangerouslySetInnerHTML)) throw Error(C(61));
    }
    if (t.style != null && typeof t.style != "object") throw Error(C(62));
  }
}
function vi(e, t) {
  if (e.indexOf("-") === -1) return typeof t.is == "string";
  switch (e) {
    case "annotation-xml":
    case "color-profile":
    case "font-face":
    case "font-face-src":
    case "font-face-uri":
    case "font-face-format":
    case "font-face-name":
    case "missing-glyph":
      return !1;
    default:
      return !0;
  }
}
var wi = null;
function Ss(e) {
  return e = e.target || e.srcElement || window, e.correspondingUseElement && (e = e.correspondingUseElement), e.nodeType === 3 ? e.parentNode : e;
}
var ki = null, gn = null, yn = null;
function Pu(e) {
  if (e = Mr(e)) {
    if (typeof ki != "function") throw Error(C(280));
    var t = e.stateNode;
    t && (t = ml(t), ki(e.stateNode, e.type, t));
  }
}
function Lc(e) {
  gn ? yn ? yn.push(e) : yn = [e] : gn = e;
}
function Mc() {
  if (gn) {
    var e = gn, t = yn;
    if (yn = gn = null, Pu(e), t) for (e = 0; e < t.length; e++) Pu(t[e]);
  }
}
function Oc(e, t) {
  return e(t);
}
function $c() {
}
var $l = !1;
function Dc(e, t, n) {
  if ($l) return e(t, n);
  $l = !0;
  try {
    return Oc(e, t, n);
  } finally {
    $l = !1, (gn !== null || yn !== null) && ($c(), Mc());
  }
}
function dr(e, t) {
  var n = e.stateNode;
  if (n === null) return null;
  var r = ml(n);
  if (r === null) return null;
  n = r[t];
  e: switch (t) {
    case "onClick":
    case "onClickCapture":
    case "onDoubleClick":
    case "onDoubleClickCapture":
    case "onMouseDown":
    case "onMouseDownCapture":
    case "onMouseMove":
    case "onMouseMoveCapture":
    case "onMouseUp":
    case "onMouseUpCapture":
    case "onMouseEnter":
      (r = !r.disabled) || (e = e.type, r = !(e === "button" || e === "input" || e === "select" || e === "textarea")), e = !r;
      break e;
    default:
      e = !1;
  }
  if (e) return null;
  if (n && typeof n != "function") throw Error(C(231, t, typeof n));
  return n;
}
var Si = !1;
if (dt) try {
  var jn = {};
  Object.defineProperty(jn, "passive", { get: function() {
    Si = !0;
  } }), window.addEventListener("test", jn, jn), window.removeEventListener("test", jn, jn);
} catch {
  Si = !1;
}
function Ih(e, t, n, r, o, l, i, s, u) {
  var a = Array.prototype.slice.call(arguments, 3);
  try {
    t.apply(n, a);
  } catch (d) {
    this.onError(d);
  }
}
var Jn = !1, Po = null, _o = !1, Ci = null, Fh = { onError: function(e) {
  Jn = !0, Po = e;
} };
function Ah(e, t, n, r, o, l, i, s, u) {
  Jn = !1, Po = null, Ih.apply(Fh, arguments);
}
function jh(e, t, n, r, o, l, i, s, u) {
  if (Ah.apply(this, arguments), Jn) {
    if (Jn) {
      var a = Po;
      Jn = !1, Po = null;
    } else throw Error(C(198));
    _o || (_o = !0, Ci = a);
  }
}
function qt(e) {
  var t = e, n = e;
  if (e.alternate) for (; t.return; ) t = t.return;
  else {
    e = t;
    do
      t = e, t.flags & 4098 && (n = t.return), e = t.return;
    while (e);
  }
  return t.tag === 3 ? n : null;
}
function Ic(e) {
  if (e.tag === 13) {
    var t = e.memoizedState;
    if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated;
  }
  return null;
}
function _u(e) {
  if (qt(e) !== e) throw Error(C(188));
}
function Bh(e) {
  var t = e.alternate;
  if (!t) {
    if (t = qt(e), t === null) throw Error(C(188));
    return t !== e ? null : e;
  }
  for (var n = e, r = t; ; ) {
    var o = n.return;
    if (o === null) break;
    var l = o.alternate;
    if (l === null) {
      if (r = o.return, r !== null) {
        n = r;
        continue;
      }
      break;
    }
    if (o.child === l.child) {
      for (l = o.child; l; ) {
        if (l === n) return _u(o), e;
        if (l === r) return _u(o), t;
        l = l.sibling;
      }
      throw Error(C(188));
    }
    if (n.return !== r.return) n = o, r = l;
    else {
      for (var i = !1, s = o.child; s; ) {
        if (s === n) {
          i = !0, n = o, r = l;
          break;
        }
        if (s === r) {
          i = !0, r = o, n = l;
          break;
        }
        s = s.sibling;
      }
      if (!i) {
        for (s = l.child; s; ) {
          if (s === n) {
            i = !0, n = l, r = o;
            break;
          }
          if (s === r) {
            i = !0, r = l, n = o;
            break;
          }
          s = s.sibling;
        }
        if (!i) throw Error(C(189));
      }
    }
    if (n.alternate !== r) throw Error(C(190));
  }
  if (n.tag !== 3) throw Error(C(188));
  return n.stateNode.current === n ? e : t;
}
function Fc(e) {
  return e = Bh(e), e !== null ? Ac(e) : null;
}
function Ac(e) {
  if (e.tag === 5 || e.tag === 6) return e;
  for (e = e.child; e !== null; ) {
    var t = Ac(e);
    if (t !== null) return t;
    e = e.sibling;
  }
  return null;
}
var jc = Me.unstable_scheduleCallback, Nu = Me.unstable_cancelCallback, bh = Me.unstable_shouldYield, Uh = Me.unstable_requestPaint, J = Me.unstable_now, Wh = Me.unstable_getCurrentPriorityLevel, Cs = Me.unstable_ImmediatePriority, Bc = Me.unstable_UserBlockingPriority, No = Me.unstable_NormalPriority, Hh = Me.unstable_LowPriority, bc = Me.unstable_IdlePriority, fl = null, rt = null;
function Vh(e) {
  if (rt && typeof rt.onCommitFiberRoot == "function") try {
    rt.onCommitFiberRoot(fl, e, void 0, (e.current.flags & 128) === 128);
  } catch {
  }
}
var Ye = Math.clz32 ? Math.clz32 : Yh, Qh = Math.log, Gh = Math.LN2;
function Yh(e) {
  return e >>>= 0, e === 0 ? 32 : 31 - (Qh(e) / Gh | 0) | 0;
}
var Hr = 64, Vr = 4194304;
function Yn(e) {
  switch (e & -e) {
    case 1:
      return 1;
    case 2:
      return 2;
    case 4:
      return 4;
    case 8:
      return 8;
    case 16:
      return 16;
    case 32:
      return 32;
    case 64:
    case 128:
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
    case 8192:
    case 16384:
    case 32768:
    case 65536:
    case 131072:
    case 262144:
    case 524288:
    case 1048576:
    case 2097152:
      return e & 4194240;
    case 4194304:
    case 8388608:
    case 16777216:
    case 33554432:
    case 67108864:
      return e & 130023424;
    case 134217728:
      return 134217728;
    case 268435456:
      return 268435456;
    case 536870912:
      return 536870912;
    case 1073741824:
      return 1073741824;
    default:
      return e;
  }
}
function To(e, t) {
  var n = e.pendingLanes;
  if (n === 0) return 0;
  var r = 0, o = e.suspendedLanes, l = e.pingedLanes, i = n & 268435455;
  if (i !== 0) {
    var s = i & ~o;
    s !== 0 ? r = Yn(s) : (l &= i, l !== 0 && (r = Yn(l)));
  } else i = n & ~o, i !== 0 ? r = Yn(i) : l !== 0 && (r = Yn(l));
  if (r === 0) return 0;
  if (t !== 0 && t !== r && !(t & o) && (o = r & -r, l = t & -t, o >= l || o === 16 && (l & 4194240) !== 0)) return t;
  if (r & 4 && (r |= n & 16), t = e.entangledLanes, t !== 0) for (e = e.entanglements, t &= r; 0 < t; ) n = 31 - Ye(t), o = 1 << n, r |= e[n], t &= ~o;
  return r;
}
function Kh(e, t) {
  switch (e) {
    case 1:
    case 2:
    case 4:
      return t + 250;
    case 8:
    case 16:
    case 32:
    case 64:
    case 128:
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
    case 8192:
    case 16384:
    case 32768:
    case 65536:
    case 131072:
    case 262144:
    case 524288:
    case 1048576:
    case 2097152:
      return t + 5e3;
    case 4194304:
    case 8388608:
    case 16777216:
    case 33554432:
    case 67108864:
      return -1;
    case 134217728:
    case 268435456:
    case 536870912:
    case 1073741824:
      return -1;
    default:
      return -1;
  }
}
function Xh(e, t) {
  for (var n = e.suspendedLanes, r = e.pingedLanes, o = e.expirationTimes, l = e.pendingLanes; 0 < l; ) {
    var i = 31 - Ye(l), s = 1 << i, u = o[i];
    u === -1 ? (!(s & n) || s & r) && (o[i] = Kh(s, t)) : u <= t && (e.expiredLanes |= s), l &= ~s;
  }
}
function xi(e) {
  return e = e.pendingLanes & -1073741825, e !== 0 ? e : e & 1073741824 ? 1073741824 : 0;
}
function Uc() {
  var e = Hr;
  return Hr <<= 1, !(Hr & 4194240) && (Hr = 64), e;
}
function Dl(e) {
  for (var t = [], n = 0; 31 > n; n++) t.push(e);
  return t;
}
function zr(e, t, n) {
  e.pendingLanes |= t, t !== 536870912 && (e.suspendedLanes = 0, e.pingedLanes = 0), e = e.eventTimes, t = 31 - Ye(t), e[t] = n;
}
function Zh(e, t) {
  var n = e.pendingLanes & ~t;
  e.pendingLanes = t, e.suspendedLanes = 0, e.pingedLanes = 0, e.expiredLanes &= t, e.mutableReadLanes &= t, e.entangledLanes &= t, t = e.entanglements;
  var r = e.eventTimes;
  for (e = e.expirationTimes; 0 < n; ) {
    var o = 31 - Ye(n), l = 1 << o;
    t[o] = 0, r[o] = -1, e[o] = -1, n &= ~l;
  }
}
function xs(e, t) {
  var n = e.entangledLanes |= t;
  for (e = e.entanglements; n; ) {
    var r = 31 - Ye(n), o = 1 << r;
    o & t | e[r] & t && (e[r] |= t), n &= ~o;
  }
}
var j = 0;
function Wc(e) {
  return e &= -e, 1 < e ? 4 < e ? e & 268435455 ? 16 : 536870912 : 4 : 1;
}
var Hc, Es, Vc, Qc, Gc, Ei = !1, Qr = [], Et = null, Pt = null, _t = null, pr = /* @__PURE__ */ new Map(), hr = /* @__PURE__ */ new Map(), kt = [], Jh = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
function Tu(e, t) {
  switch (e) {
    case "focusin":
    case "focusout":
      Et = null;
      break;
    case "dragenter":
    case "dragleave":
      Pt = null;
      break;
    case "mouseover":
    case "mouseout":
      _t = null;
      break;
    case "pointerover":
    case "pointerout":
      pr.delete(t.pointerId);
      break;
    case "gotpointercapture":
    case "lostpointercapture":
      hr.delete(t.pointerId);
  }
}
function Bn(e, t, n, r, o, l) {
  return e === null || e.nativeEvent !== l ? (e = { blockedOn: t, domEventName: n, eventSystemFlags: r, nativeEvent: l, targetContainers: [o] }, t !== null && (t = Mr(t), t !== null && Es(t)), e) : (e.eventSystemFlags |= r, t = e.targetContainers, o !== null && t.indexOf(o) === -1 && t.push(o), e);
}
function qh(e, t, n, r, o) {
  switch (t) {
    case "focusin":
      return Et = Bn(Et, e, t, n, r, o), !0;
    case "dragenter":
      return Pt = Bn(Pt, e, t, n, r, o), !0;
    case "mouseover":
      return _t = Bn(_t, e, t, n, r, o), !0;
    case "pointerover":
      var l = o.pointerId;
      return pr.set(l, Bn(pr.get(l) || null, e, t, n, r, o)), !0;
    case "gotpointercapture":
      return l = o.pointerId, hr.set(l, Bn(hr.get(l) || null, e, t, n, r, o)), !0;
  }
  return !1;
}
function Yc(e) {
  var t = Ut(e.target);
  if (t !== null) {
    var n = qt(t);
    if (n !== null) {
      if (t = n.tag, t === 13) {
        if (t = Ic(n), t !== null) {
          e.blockedOn = t, Gc(e.priority, function() {
            Vc(n);
          });
          return;
        }
      } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
        e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
        return;
      }
    }
  }
  e.blockedOn = null;
}
function fo(e) {
  if (e.blockedOn !== null) return !1;
  for (var t = e.targetContainers; 0 < t.length; ) {
    var n = Pi(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
    if (n === null) {
      n = e.nativeEvent;
      var r = new n.constructor(n.type, n);
      wi = r, n.target.dispatchEvent(r), wi = null;
    } else return t = Mr(n), t !== null && Es(t), e.blockedOn = n, !1;
    t.shift();
  }
  return !0;
}
function Ru(e, t, n) {
  fo(e) && n.delete(t);
}
function em() {
  Ei = !1, Et !== null && fo(Et) && (Et = null), Pt !== null && fo(Pt) && (Pt = null), _t !== null && fo(_t) && (_t = null), pr.forEach(Ru), hr.forEach(Ru);
}
function bn(e, t) {
  e.blockedOn === t && (e.blockedOn = null, Ei || (Ei = !0, Me.unstable_scheduleCallback(Me.unstable_NormalPriority, em)));
}
function mr(e) {
  function t(o) {
    return bn(o, e);
  }
  if (0 < Qr.length) {
    bn(Qr[0], e);
    for (var n = 1; n < Qr.length; n++) {
      var r = Qr[n];
      r.blockedOn === e && (r.blockedOn = null);
    }
  }
  for (Et !== null && bn(Et, e), Pt !== null && bn(Pt, e), _t !== null && bn(_t, e), pr.forEach(t), hr.forEach(t), n = 0; n < kt.length; n++) r = kt[n], r.blockedOn === e && (r.blockedOn = null);
  for (; 0 < kt.length && (n = kt[0], n.blockedOn === null); ) Yc(n), n.blockedOn === null && kt.shift();
}
var vn = gt.ReactCurrentBatchConfig, Ro = !0;
function tm(e, t, n, r) {
  var o = j, l = vn.transition;
  vn.transition = null;
  try {
    j = 1, Ps(e, t, n, r);
  } finally {
    j = o, vn.transition = l;
  }
}
function nm(e, t, n, r) {
  var o = j, l = vn.transition;
  vn.transition = null;
  try {
    j = 4, Ps(e, t, n, r);
  } finally {
    j = o, vn.transition = l;
  }
}
function Ps(e, t, n, r) {
  if (Ro) {
    var o = Pi(e, t, n, r);
    if (o === null) Vl(e, t, r, zo, n), Tu(e, r);
    else if (qh(o, e, t, n, r)) r.stopPropagation();
    else if (Tu(e, r), t & 4 && -1 < Jh.indexOf(e)) {
      for (; o !== null; ) {
        var l = Mr(o);
        if (l !== null && Hc(l), l = Pi(e, t, n, r), l === null && Vl(e, t, r, zo, n), l === o) break;
        o = l;
      }
      o !== null && r.stopPropagation();
    } else Vl(e, t, r, null, n);
  }
}
var zo = null;
function Pi(e, t, n, r) {
  if (zo = null, e = Ss(r), e = Ut(e), e !== null) if (t = qt(e), t === null) e = null;
  else if (n = t.tag, n === 13) {
    if (e = Ic(t), e !== null) return e;
    e = null;
  } else if (n === 3) {
    if (t.stateNode.current.memoizedState.isDehydrated) return t.tag === 3 ? t.stateNode.containerInfo : null;
    e = null;
  } else t !== e && (e = null);
  return zo = e, null;
}
function Kc(e) {
  switch (e) {
    case "cancel":
    case "click":
    case "close":
    case "contextmenu":
    case "copy":
    case "cut":
    case "auxclick":
    case "dblclick":
    case "dragend":
    case "dragstart":
    case "drop":
    case "focusin":
    case "focusout":
    case "input":
    case "invalid":
    case "keydown":
    case "keypress":
    case "keyup":
    case "mousedown":
    case "mouseup":
    case "paste":
    case "pause":
    case "play":
    case "pointercancel":
    case "pointerdown":
    case "pointerup":
    case "ratechange":
    case "reset":
    case "resize":
    case "seeked":
    case "submit":
    case "touchcancel":
    case "touchend":
    case "touchstart":
    case "volumechange":
    case "change":
    case "selectionchange":
    case "textInput":
    case "compositionstart":
    case "compositionend":
    case "compositionupdate":
    case "beforeblur":
    case "afterblur":
    case "beforeinput":
    case "blur":
    case "fullscreenchange":
    case "focus":
    case "hashchange":
    case "popstate":
    case "select":
    case "selectstart":
      return 1;
    case "drag":
    case "dragenter":
    case "dragexit":
    case "dragleave":
    case "dragover":
    case "mousemove":
    case "mouseout":
    case "mouseover":
    case "pointermove":
    case "pointerout":
    case "pointerover":
    case "scroll":
    case "toggle":
    case "touchmove":
    case "wheel":
    case "mouseenter":
    case "mouseleave":
    case "pointerenter":
    case "pointerleave":
      return 4;
    case "message":
      switch (Wh()) {
        case Cs:
          return 1;
        case Bc:
          return 4;
        case No:
        case Hh:
          return 16;
        case bc:
          return 536870912;
        default:
          return 16;
      }
    default:
      return 16;
  }
}
var Ct = null, _s = null, po = null;
function Xc() {
  if (po) return po;
  var e, t = _s, n = t.length, r, o = "value" in Ct ? Ct.value : Ct.textContent, l = o.length;
  for (e = 0; e < n && t[e] === o[e]; e++) ;
  var i = n - e;
  for (r = 1; r <= i && t[n - r] === o[l - r]; r++) ;
  return po = o.slice(e, 1 < r ? 1 - r : void 0);
}
function ho(e) {
  var t = e.keyCode;
  return "charCode" in e ? (e = e.charCode, e === 0 && t === 13 && (e = 13)) : e = t, e === 10 && (e = 13), 32 <= e || e === 13 ? e : 0;
}
function Gr() {
  return !0;
}
function zu() {
  return !1;
}
function De(e) {
  function t(n, r, o, l, i) {
    this._reactName = n, this._targetInst = o, this.type = r, this.nativeEvent = l, this.target = i, this.currentTarget = null;
    for (var s in e) e.hasOwnProperty(s) && (n = e[s], this[s] = n ? n(l) : l[s]);
    return this.isDefaultPrevented = (l.defaultPrevented != null ? l.defaultPrevented : l.returnValue === !1) ? Gr : zu, this.isPropagationStopped = zu, this;
  }
  return Y(t.prototype, { preventDefault: function() {
    this.defaultPrevented = !0;
    var n = this.nativeEvent;
    n && (n.preventDefault ? n.preventDefault() : typeof n.returnValue != "unknown" && (n.returnValue = !1), this.isDefaultPrevented = Gr);
  }, stopPropagation: function() {
    var n = this.nativeEvent;
    n && (n.stopPropagation ? n.stopPropagation() : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0), this.isPropagationStopped = Gr);
  }, persist: function() {
  }, isPersistent: Gr }), t;
}
var Ln = { eventPhase: 0, bubbles: 0, cancelable: 0, timeStamp: function(e) {
  return e.timeStamp || Date.now();
}, defaultPrevented: 0, isTrusted: 0 }, Ns = De(Ln), Lr = Y({}, Ln, { view: 0, detail: 0 }), rm = De(Lr), Il, Fl, Un, dl = Y({}, Lr, { screenX: 0, screenY: 0, clientX: 0, clientY: 0, pageX: 0, pageY: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, getModifierState: Ts, button: 0, buttons: 0, relatedTarget: function(e) {
  return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget;
}, movementX: function(e) {
  return "movementX" in e ? e.movementX : (e !== Un && (Un && e.type === "mousemove" ? (Il = e.screenX - Un.screenX, Fl = e.screenY - Un.screenY) : Fl = Il = 0, Un = e), Il);
}, movementY: function(e) {
  return "movementY" in e ? e.movementY : Fl;
} }), Lu = De(dl), om = Y({}, dl, { dataTransfer: 0 }), lm = De(om), im = Y({}, Lr, { relatedTarget: 0 }), Al = De(im), sm = Y({}, Ln, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }), um = De(sm), am = Y({}, Ln, { clipboardData: function(e) {
  return "clipboardData" in e ? e.clipboardData : window.clipboardData;
} }), cm = De(am), fm = Y({}, Ln, { data: 0 }), Mu = De(fm), dm = {
  Esc: "Escape",
  Spacebar: " ",
  Left: "ArrowLeft",
  Up: "ArrowUp",
  Right: "ArrowRight",
  Down: "ArrowDown",
  Del: "Delete",
  Win: "OS",
  Menu: "ContextMenu",
  Apps: "ContextMenu",
  Scroll: "ScrollLock",
  MozPrintableKey: "Unidentified"
}, pm = {
  8: "Backspace",
  9: "Tab",
  12: "Clear",
  13: "Enter",
  16: "Shift",
  17: "Control",
  18: "Alt",
  19: "Pause",
  20: "CapsLock",
  27: "Escape",
  32: " ",
  33: "PageUp",
  34: "PageDown",
  35: "End",
  36: "Home",
  37: "ArrowLeft",
  38: "ArrowUp",
  39: "ArrowRight",
  40: "ArrowDown",
  45: "Insert",
  46: "Delete",
  112: "F1",
  113: "F2",
  114: "F3",
  115: "F4",
  116: "F5",
  117: "F6",
  118: "F7",
  119: "F8",
  120: "F9",
  121: "F10",
  122: "F11",
  123: "F12",
  144: "NumLock",
  145: "ScrollLock",
  224: "Meta"
}, hm = { Alt: "altKey", Control: "ctrlKey", Meta: "metaKey", Shift: "shiftKey" };
function mm(e) {
  var t = this.nativeEvent;
  return t.getModifierState ? t.getModifierState(e) : (e = hm[e]) ? !!t[e] : !1;
}
function Ts() {
  return mm;
}
var gm = Y({}, Lr, { key: function(e) {
  if (e.key) {
    var t = dm[e.key] || e.key;
    if (t !== "Unidentified") return t;
  }
  return e.type === "keypress" ? (e = ho(e), e === 13 ? "Enter" : String.fromCharCode(e)) : e.type === "keydown" || e.type === "keyup" ? pm[e.keyCode] || "Unidentified" : "";
}, code: 0, location: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, repeat: 0, locale: 0, getModifierState: Ts, charCode: function(e) {
  return e.type === "keypress" ? ho(e) : 0;
}, keyCode: function(e) {
  return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
}, which: function(e) {
  return e.type === "keypress" ? ho(e) : e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
} }), ym = De(gm), vm = Y({}, dl, { pointerId: 0, width: 0, height: 0, pressure: 0, tangentialPressure: 0, tiltX: 0, tiltY: 0, twist: 0, pointerType: 0, isPrimary: 0 }), Ou = De(vm), wm = Y({}, Lr, { touches: 0, targetTouches: 0, changedTouches: 0, altKey: 0, metaKey: 0, ctrlKey: 0, shiftKey: 0, getModifierState: Ts }), km = De(wm), Sm = Y({}, Ln, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }), Cm = De(Sm), xm = Y({}, dl, {
  deltaX: function(e) {
    return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0;
  },
  deltaY: function(e) {
    return "deltaY" in e ? e.deltaY : "wheelDeltaY" in e ? -e.wheelDeltaY : "wheelDelta" in e ? -e.wheelDelta : 0;
  },
  deltaZ: 0,
  deltaMode: 0
}), Em = De(xm), Pm = [9, 13, 27, 32], Rs = dt && "CompositionEvent" in window, qn = null;
dt && "documentMode" in document && (qn = document.documentMode);
var _m = dt && "TextEvent" in window && !qn, Zc = dt && (!Rs || qn && 8 < qn && 11 >= qn), $u = " ", Du = !1;
function Jc(e, t) {
  switch (e) {
    case "keyup":
      return Pm.indexOf(t.keyCode) !== -1;
    case "keydown":
      return t.keyCode !== 229;
    case "keypress":
    case "mousedown":
    case "focusout":
      return !0;
    default:
      return !1;
  }
}
function qc(e) {
  return e = e.detail, typeof e == "object" && "data" in e ? e.data : null;
}
var rn = !1;
function Nm(e, t) {
  switch (e) {
    case "compositionend":
      return qc(t);
    case "keypress":
      return t.which !== 32 ? null : (Du = !0, $u);
    case "textInput":
      return e = t.data, e === $u && Du ? null : e;
    default:
      return null;
  }
}
function Tm(e, t) {
  if (rn) return e === "compositionend" || !Rs && Jc(e, t) ? (e = Xc(), po = _s = Ct = null, rn = !1, e) : null;
  switch (e) {
    case "paste":
      return null;
    case "keypress":
      if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
        if (t.char && 1 < t.char.length) return t.char;
        if (t.which) return String.fromCharCode(t.which);
      }
      return null;
    case "compositionend":
      return Zc && t.locale !== "ko" ? null : t.data;
    default:
      return null;
  }
}
var Rm = { color: !0, date: !0, datetime: !0, "datetime-local": !0, email: !0, month: !0, number: !0, password: !0, range: !0, search: !0, tel: !0, text: !0, time: !0, url: !0, week: !0 };
function Iu(e) {
  var t = e && e.nodeName && e.nodeName.toLowerCase();
  return t === "input" ? !!Rm[e.type] : t === "textarea";
}
function ef(e, t, n, r) {
  Lc(r), t = Lo(t, "onChange"), 0 < t.length && (n = new Ns("onChange", "change", null, n, r), e.push({ event: n, listeners: t }));
}
var er = null, gr = null;
function zm(e) {
  df(e, 0);
}
function pl(e) {
  var t = sn(e);
  if (Ec(t)) return e;
}
function Lm(e, t) {
  if (e === "change") return t;
}
var tf = !1;
if (dt) {
  var jl;
  if (dt) {
    var Bl = "oninput" in document;
    if (!Bl) {
      var Fu = document.createElement("div");
      Fu.setAttribute("oninput", "return;"), Bl = typeof Fu.oninput == "function";
    }
    jl = Bl;
  } else jl = !1;
  tf = jl && (!document.documentMode || 9 < document.documentMode);
}
function Au() {
  er && (er.detachEvent("onpropertychange", nf), gr = er = null);
}
function nf(e) {
  if (e.propertyName === "value" && pl(gr)) {
    var t = [];
    ef(t, gr, e, Ss(e)), Dc(zm, t);
  }
}
function Mm(e, t, n) {
  e === "focusin" ? (Au(), er = t, gr = n, er.attachEvent("onpropertychange", nf)) : e === "focusout" && Au();
}
function Om(e) {
  if (e === "selectionchange" || e === "keyup" || e === "keydown") return pl(gr);
}
function $m(e, t) {
  if (e === "click") return pl(t);
}
function Dm(e, t) {
  if (e === "input" || e === "change") return pl(t);
}
function Im(e, t) {
  return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t;
}
var Xe = typeof Object.is == "function" ? Object.is : Im;
function yr(e, t) {
  if (Xe(e, t)) return !0;
  if (typeof e != "object" || e === null || typeof t != "object" || t === null) return !1;
  var n = Object.keys(e), r = Object.keys(t);
  if (n.length !== r.length) return !1;
  for (r = 0; r < n.length; r++) {
    var o = n[r];
    if (!si.call(t, o) || !Xe(e[o], t[o])) return !1;
  }
  return !0;
}
function ju(e) {
  for (; e && e.firstChild; ) e = e.firstChild;
  return e;
}
function Bu(e, t) {
  var n = ju(e);
  e = 0;
  for (var r; n; ) {
    if (n.nodeType === 3) {
      if (r = e + n.textContent.length, e <= t && r >= t) return { node: n, offset: t - e };
      e = r;
    }
    e: {
      for (; n; ) {
        if (n.nextSibling) {
          n = n.nextSibling;
          break e;
        }
        n = n.parentNode;
      }
      n = void 0;
    }
    n = ju(n);
  }
}
function rf(e, t) {
  return e && t ? e === t ? !0 : e && e.nodeType === 3 ? !1 : t && t.nodeType === 3 ? rf(e, t.parentNode) : "contains" in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : !1 : !1;
}
function of() {
  for (var e = window, t = Eo(); t instanceof e.HTMLIFrameElement; ) {
    try {
      var n = typeof t.contentWindow.location.href == "string";
    } catch {
      n = !1;
    }
    if (n) e = t.contentWindow;
    else break;
    t = Eo(e.document);
  }
  return t;
}
function zs(e) {
  var t = e && e.nodeName && e.nodeName.toLowerCase();
  return t && (t === "input" && (e.type === "text" || e.type === "search" || e.type === "tel" || e.type === "url" || e.type === "password") || t === "textarea" || e.contentEditable === "true");
}
function Fm(e) {
  var t = of(), n = e.focusedElem, r = e.selectionRange;
  if (t !== n && n && n.ownerDocument && rf(n.ownerDocument.documentElement, n)) {
    if (r !== null && zs(n)) {
      if (t = r.start, e = r.end, e === void 0 && (e = t), "selectionStart" in n) n.selectionStart = t, n.selectionEnd = Math.min(e, n.value.length);
      else if (e = (t = n.ownerDocument || document) && t.defaultView || window, e.getSelection) {
        e = e.getSelection();
        var o = n.textContent.length, l = Math.min(r.start, o);
        r = r.end === void 0 ? l : Math.min(r.end, o), !e.extend && l > r && (o = r, r = l, l = o), o = Bu(n, l);
        var i = Bu(
          n,
          r
        );
        o && i && (e.rangeCount !== 1 || e.anchorNode !== o.node || e.anchorOffset !== o.offset || e.focusNode !== i.node || e.focusOffset !== i.offset) && (t = t.createRange(), t.setStart(o.node, o.offset), e.removeAllRanges(), l > r ? (e.addRange(t), e.extend(i.node, i.offset)) : (t.setEnd(i.node, i.offset), e.addRange(t)));
      }
    }
    for (t = [], e = n; e = e.parentNode; ) e.nodeType === 1 && t.push({ element: e, left: e.scrollLeft, top: e.scrollTop });
    for (typeof n.focus == "function" && n.focus(), n = 0; n < t.length; n++) e = t[n], e.element.scrollLeft = e.left, e.element.scrollTop = e.top;
  }
}
var Am = dt && "documentMode" in document && 11 >= document.documentMode, on = null, _i = null, tr = null, Ni = !1;
function bu(e, t, n) {
  var r = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
  Ni || on == null || on !== Eo(r) || (r = on, "selectionStart" in r && zs(r) ? r = { start: r.selectionStart, end: r.selectionEnd } : (r = (r.ownerDocument && r.ownerDocument.defaultView || window).getSelection(), r = { anchorNode: r.anchorNode, anchorOffset: r.anchorOffset, focusNode: r.focusNode, focusOffset: r.focusOffset }), tr && yr(tr, r) || (tr = r, r = Lo(_i, "onSelect"), 0 < r.length && (t = new Ns("onSelect", "select", null, t, n), e.push({ event: t, listeners: r }), t.target = on)));
}
function Yr(e, t) {
  var n = {};
  return n[e.toLowerCase()] = t.toLowerCase(), n["Webkit" + e] = "webkit" + t, n["Moz" + e] = "moz" + t, n;
}
var ln = { animationend: Yr("Animation", "AnimationEnd"), animationiteration: Yr("Animation", "AnimationIteration"), animationstart: Yr("Animation", "AnimationStart"), transitionend: Yr("Transition", "TransitionEnd") }, bl = {}, lf = {};
dt && (lf = document.createElement("div").style, "AnimationEvent" in window || (delete ln.animationend.animation, delete ln.animationiteration.animation, delete ln.animationstart.animation), "TransitionEvent" in window || delete ln.transitionend.transition);
function hl(e) {
  if (bl[e]) return bl[e];
  if (!ln[e]) return e;
  var t = ln[e], n;
  for (n in t) if (t.hasOwnProperty(n) && n in lf) return bl[e] = t[n];
  return e;
}
var sf = hl("animationend"), uf = hl("animationiteration"), af = hl("animationstart"), cf = hl("transitionend"), ff = /* @__PURE__ */ new Map(), Uu = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
function $t(e, t) {
  ff.set(e, t), Jt(t, [e]);
}
for (var Ul = 0; Ul < Uu.length; Ul++) {
  var Wl = Uu[Ul], jm = Wl.toLowerCase(), Bm = Wl[0].toUpperCase() + Wl.slice(1);
  $t(jm, "on" + Bm);
}
$t(sf, "onAnimationEnd");
$t(uf, "onAnimationIteration");
$t(af, "onAnimationStart");
$t("dblclick", "onDoubleClick");
$t("focusin", "onFocus");
$t("focusout", "onBlur");
$t(cf, "onTransitionEnd");
Cn("onMouseEnter", ["mouseout", "mouseover"]);
Cn("onMouseLeave", ["mouseout", "mouseover"]);
Cn("onPointerEnter", ["pointerout", "pointerover"]);
Cn("onPointerLeave", ["pointerout", "pointerover"]);
Jt("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
Jt("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
Jt("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
Jt("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
Jt("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
Jt("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
var Kn = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "), bm = new Set("cancel close invalid load scroll toggle".split(" ").concat(Kn));
function Wu(e, t, n) {
  var r = e.type || "unknown-event";
  e.currentTarget = n, jh(r, t, void 0, e), e.currentTarget = null;
}
function df(e, t) {
  t = (t & 4) !== 0;
  for (var n = 0; n < e.length; n++) {
    var r = e[n], o = r.event;
    r = r.listeners;
    e: {
      var l = void 0;
      if (t) for (var i = r.length - 1; 0 <= i; i--) {
        var s = r[i], u = s.instance, a = s.currentTarget;
        if (s = s.listener, u !== l && o.isPropagationStopped()) break e;
        Wu(o, s, a), l = u;
      }
      else for (i = 0; i < r.length; i++) {
        if (s = r[i], u = s.instance, a = s.currentTarget, s = s.listener, u !== l && o.isPropagationStopped()) break e;
        Wu(o, s, a), l = u;
      }
    }
  }
  if (_o) throw e = Ci, _o = !1, Ci = null, e;
}
function U(e, t) {
  var n = t[Mi];
  n === void 0 && (n = t[Mi] = /* @__PURE__ */ new Set());
  var r = e + "__bubble";
  n.has(r) || (pf(t, e, 2, !1), n.add(r));
}
function Hl(e, t, n) {
  var r = 0;
  t && (r |= 4), pf(n, e, r, t);
}
var Kr = "_reactListening" + Math.random().toString(36).slice(2);
function vr(e) {
  if (!e[Kr]) {
    e[Kr] = !0, wc.forEach(function(n) {
      n !== "selectionchange" && (bm.has(n) || Hl(n, !1, e), Hl(n, !0, e));
    });
    var t = e.nodeType === 9 ? e : e.ownerDocument;
    t === null || t[Kr] || (t[Kr] = !0, Hl("selectionchange", !1, t));
  }
}
function pf(e, t, n, r) {
  switch (Kc(t)) {
    case 1:
      var o = tm;
      break;
    case 4:
      o = nm;
      break;
    default:
      o = Ps;
  }
  n = o.bind(null, t, n, e), o = void 0, !Si || t !== "touchstart" && t !== "touchmove" && t !== "wheel" || (o = !0), r ? o !== void 0 ? e.addEventListener(t, n, { capture: !0, passive: o }) : e.addEventListener(t, n, !0) : o !== void 0 ? e.addEventListener(t, n, { passive: o }) : e.addEventListener(t, n, !1);
}
function Vl(e, t, n, r, o) {
  var l = r;
  if (!(t & 1) && !(t & 2) && r !== null) e: for (; ; ) {
    if (r === null) return;
    var i = r.tag;
    if (i === 3 || i === 4) {
      var s = r.stateNode.containerInfo;
      if (s === o || s.nodeType === 8 && s.parentNode === o) break;
      if (i === 4) for (i = r.return; i !== null; ) {
        var u = i.tag;
        if ((u === 3 || u === 4) && (u = i.stateNode.containerInfo, u === o || u.nodeType === 8 && u.parentNode === o)) return;
        i = i.return;
      }
      for (; s !== null; ) {
        if (i = Ut(s), i === null) return;
        if (u = i.tag, u === 5 || u === 6) {
          r = l = i;
          continue e;
        }
        s = s.parentNode;
      }
    }
    r = r.return;
  }
  Dc(function() {
    var a = l, d = Ss(n), p = [];
    e: {
      var h = ff.get(e);
      if (h !== void 0) {
        var g = Ns, v = e;
        switch (e) {
          case "keypress":
            if (ho(n) === 0) break e;
          case "keydown":
          case "keyup":
            g = ym;
            break;
          case "focusin":
            v = "focus", g = Al;
            break;
          case "focusout":
            v = "blur", g = Al;
            break;
          case "beforeblur":
          case "afterblur":
            g = Al;
            break;
          case "click":
            if (n.button === 2) break e;
          case "auxclick":
          case "dblclick":
          case "mousedown":
          case "mousemove":
          case "mouseup":
          case "mouseout":
          case "mouseover":
          case "contextmenu":
            g = Lu;
            break;
          case "drag":
          case "dragend":
          case "dragenter":
          case "dragexit":
          case "dragleave":
          case "dragover":
          case "dragstart":
          case "drop":
            g = lm;
            break;
          case "touchcancel":
          case "touchend":
          case "touchmove":
          case "touchstart":
            g = km;
            break;
          case sf:
          case uf:
          case af:
            g = um;
            break;
          case cf:
            g = Cm;
            break;
          case "scroll":
            g = rm;
            break;
          case "wheel":
            g = Em;
            break;
          case "copy":
          case "cut":
          case "paste":
            g = cm;
            break;
          case "gotpointercapture":
          case "lostpointercapture":
          case "pointercancel":
          case "pointerdown":
          case "pointermove":
          case "pointerout":
          case "pointerover":
          case "pointerup":
            g = Ou;
        }
        var w = (t & 4) !== 0, R = !w && e === "scroll", f = w ? h !== null ? h + "Capture" : null : h;
        w = [];
        for (var c = a, m; c !== null; ) {
          m = c;
          var S = m.stateNode;
          if (m.tag === 5 && S !== null && (m = S, f !== null && (S = dr(c, f), S != null && w.push(wr(c, S, m)))), R) break;
          c = c.return;
        }
        0 < w.length && (h = new g(h, v, null, n, d), p.push({ event: h, listeners: w }));
      }
    }
    if (!(t & 7)) {
      e: {
        if (h = e === "mouseover" || e === "pointerover", g = e === "mouseout" || e === "pointerout", h && n !== wi && (v = n.relatedTarget || n.fromElement) && (Ut(v) || v[pt])) break e;
        if ((g || h) && (h = d.window === d ? d : (h = d.ownerDocument) ? h.defaultView || h.parentWindow : window, g ? (v = n.relatedTarget || n.toElement, g = a, v = v ? Ut(v) : null, v !== null && (R = qt(v), v !== R || v.tag !== 5 && v.tag !== 6) && (v = null)) : (g = null, v = a), g !== v)) {
          if (w = Lu, S = "onMouseLeave", f = "onMouseEnter", c = "mouse", (e === "pointerout" || e === "pointerover") && (w = Ou, S = "onPointerLeave", f = "onPointerEnter", c = "pointer"), R = g == null ? h : sn(g), m = v == null ? h : sn(v), h = new w(S, c + "leave", g, n, d), h.target = R, h.relatedTarget = m, S = null, Ut(d) === a && (w = new w(f, c + "enter", v, n, d), w.target = m, w.relatedTarget = R, S = w), R = S, g && v) t: {
            for (w = g, f = v, c = 0, m = w; m; m = en(m)) c++;
            for (m = 0, S = f; S; S = en(S)) m++;
            for (; 0 < c - m; ) w = en(w), c--;
            for (; 0 < m - c; ) f = en(f), m--;
            for (; c--; ) {
              if (w === f || f !== null && w === f.alternate) break t;
              w = en(w), f = en(f);
            }
            w = null;
          }
          else w = null;
          g !== null && Hu(p, h, g, w, !1), v !== null && R !== null && Hu(p, R, v, w, !0);
        }
      }
      e: {
        if (h = a ? sn(a) : window, g = h.nodeName && h.nodeName.toLowerCase(), g === "select" || g === "input" && h.type === "file") var E = Lm;
        else if (Iu(h)) if (tf) E = Dm;
        else {
          E = Om;
          var P = Mm;
        }
        else (g = h.nodeName) && g.toLowerCase() === "input" && (h.type === "checkbox" || h.type === "radio") && (E = $m);
        if (E && (E = E(e, a))) {
          ef(p, E, n, d);
          break e;
        }
        P && P(e, h, a), e === "focusout" && (P = h._wrapperState) && P.controlled && h.type === "number" && hi(h, "number", h.value);
      }
      switch (P = a ? sn(a) : window, e) {
        case "focusin":
          (Iu(P) || P.contentEditable === "true") && (on = P, _i = a, tr = null);
          break;
        case "focusout":
          tr = _i = on = null;
          break;
        case "mousedown":
          Ni = !0;
          break;
        case "contextmenu":
        case "mouseup":
        case "dragend":
          Ni = !1, bu(p, n, d);
          break;
        case "selectionchange":
          if (Am) break;
        case "keydown":
        case "keyup":
          bu(p, n, d);
      }
      var x;
      if (Rs) e: {
        switch (e) {
          case "compositionstart":
            var T = "onCompositionStart";
            break e;
          case "compositionend":
            T = "onCompositionEnd";
            break e;
          case "compositionupdate":
            T = "onCompositionUpdate";
            break e;
        }
        T = void 0;
      }
      else rn ? Jc(e, n) && (T = "onCompositionEnd") : e === "keydown" && n.keyCode === 229 && (T = "onCompositionStart");
      T && (Zc && n.locale !== "ko" && (rn || T !== "onCompositionStart" ? T === "onCompositionEnd" && rn && (x = Xc()) : (Ct = d, _s = "value" in Ct ? Ct.value : Ct.textContent, rn = !0)), P = Lo(a, T), 0 < P.length && (T = new Mu(T, e, null, n, d), p.push({ event: T, listeners: P }), x ? T.data = x : (x = qc(n), x !== null && (T.data = x)))), (x = _m ? Nm(e, n) : Tm(e, n)) && (a = Lo(a, "onBeforeInput"), 0 < a.length && (d = new Mu("onBeforeInput", "beforeinput", null, n, d), p.push({ event: d, listeners: a }), d.data = x));
    }
    df(p, t);
  });
}
function wr(e, t, n) {
  return { instance: e, listener: t, currentTarget: n };
}
function Lo(e, t) {
  for (var n = t + "Capture", r = []; e !== null; ) {
    var o = e, l = o.stateNode;
    o.tag === 5 && l !== null && (o = l, l = dr(e, n), l != null && r.unshift(wr(e, l, o)), l = dr(e, t), l != null && r.push(wr(e, l, o))), e = e.return;
  }
  return r;
}
function en(e) {
  if (e === null) return null;
  do
    e = e.return;
  while (e && e.tag !== 5);
  return e || null;
}
function Hu(e, t, n, r, o) {
  for (var l = t._reactName, i = []; n !== null && n !== r; ) {
    var s = n, u = s.alternate, a = s.stateNode;
    if (u !== null && u === r) break;
    s.tag === 5 && a !== null && (s = a, o ? (u = dr(n, l), u != null && i.unshift(wr(n, u, s))) : o || (u = dr(n, l), u != null && i.push(wr(n, u, s)))), n = n.return;
  }
  i.length !== 0 && e.push({ event: t, listeners: i });
}
var Um = /\r\n?/g, Wm = /\u0000|\uFFFD/g;
function Vu(e) {
  return (typeof e == "string" ? e : "" + e).replace(Um, `
`).replace(Wm, "");
}
function Xr(e, t, n) {
  if (t = Vu(t), Vu(e) !== t && n) throw Error(C(425));
}
function Mo() {
}
var Ti = null, Ri = null;
function zi(e, t) {
  return e === "textarea" || e === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null;
}
var Li = typeof setTimeout == "function" ? setTimeout : void 0, Hm = typeof clearTimeout == "function" ? clearTimeout : void 0, Qu = typeof Promise == "function" ? Promise : void 0, Vm = typeof queueMicrotask == "function" ? queueMicrotask : typeof Qu < "u" ? function(e) {
  return Qu.resolve(null).then(e).catch(Qm);
} : Li;
function Qm(e) {
  setTimeout(function() {
    throw e;
  });
}
function Ql(e, t) {
  var n = t, r = 0;
  do {
    var o = n.nextSibling;
    if (e.removeChild(n), o && o.nodeType === 8) if (n = o.data, n === "/$") {
      if (r === 0) {
        e.removeChild(o), mr(t);
        return;
      }
      r--;
    } else n !== "$" && n !== "$?" && n !== "$!" || r++;
    n = o;
  } while (n);
  mr(t);
}
function Nt(e) {
  for (; e != null; e = e.nextSibling) {
    var t = e.nodeType;
    if (t === 1 || t === 3) break;
    if (t === 8) {
      if (t = e.data, t === "$" || t === "$!" || t === "$?") break;
      if (t === "/$") return null;
    }
  }
  return e;
}
function Gu(e) {
  e = e.previousSibling;
  for (var t = 0; e; ) {
    if (e.nodeType === 8) {
      var n = e.data;
      if (n === "$" || n === "$!" || n === "$?") {
        if (t === 0) return e;
        t--;
      } else n === "/$" && t++;
    }
    e = e.previousSibling;
  }
  return null;
}
var Mn = Math.random().toString(36).slice(2), tt = "__reactFiber$" + Mn, kr = "__reactProps$" + Mn, pt = "__reactContainer$" + Mn, Mi = "__reactEvents$" + Mn, Gm = "__reactListeners$" + Mn, Ym = "__reactHandles$" + Mn;
function Ut(e) {
  var t = e[tt];
  if (t) return t;
  for (var n = e.parentNode; n; ) {
    if (t = n[pt] || n[tt]) {
      if (n = t.alternate, t.child !== null || n !== null && n.child !== null) for (e = Gu(e); e !== null; ) {
        if (n = e[tt]) return n;
        e = Gu(e);
      }
      return t;
    }
    e = n, n = e.parentNode;
  }
  return null;
}
function Mr(e) {
  return e = e[tt] || e[pt], !e || e.tag !== 5 && e.tag !== 6 && e.tag !== 13 && e.tag !== 3 ? null : e;
}
function sn(e) {
  if (e.tag === 5 || e.tag === 6) return e.stateNode;
  throw Error(C(33));
}
function ml(e) {
  return e[kr] || null;
}
var Oi = [], un = -1;
function Dt(e) {
  return { current: e };
}
function H(e) {
  0 > un || (e.current = Oi[un], Oi[un] = null, un--);
}
function b(e, t) {
  un++, Oi[un] = e.current, e.current = t;
}
var Ot = {}, ye = Dt(Ot), Ee = Dt(!1), Gt = Ot;
function xn(e, t) {
  var n = e.type.contextTypes;
  if (!n) return Ot;
  var r = e.stateNode;
  if (r && r.__reactInternalMemoizedUnmaskedChildContext === t) return r.__reactInternalMemoizedMaskedChildContext;
  var o = {}, l;
  for (l in n) o[l] = t[l];
  return r && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = t, e.__reactInternalMemoizedMaskedChildContext = o), o;
}
function Pe(e) {
  return e = e.childContextTypes, e != null;
}
function Oo() {
  H(Ee), H(ye);
}
function Yu(e, t, n) {
  if (ye.current !== Ot) throw Error(C(168));
  b(ye, t), b(Ee, n);
}
function hf(e, t, n) {
  var r = e.stateNode;
  if (t = t.childContextTypes, typeof r.getChildContext != "function") return n;
  r = r.getChildContext();
  for (var o in r) if (!(o in t)) throw Error(C(108, Mh(e) || "Unknown", o));
  return Y({}, n, r);
}
function $o(e) {
  return e = (e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext || Ot, Gt = ye.current, b(ye, e), b(Ee, Ee.current), !0;
}
function Ku(e, t, n) {
  var r = e.stateNode;
  if (!r) throw Error(C(169));
  n ? (e = hf(e, t, Gt), r.__reactInternalMemoizedMergedChildContext = e, H(Ee), H(ye), b(ye, e)) : H(Ee), b(Ee, n);
}
var it = null, gl = !1, Gl = !1;
function mf(e) {
  it === null ? it = [e] : it.push(e);
}
function Km(e) {
  gl = !0, mf(e);
}
function It() {
  if (!Gl && it !== null) {
    Gl = !0;
    var e = 0, t = j;
    try {
      var n = it;
      for (j = 1; e < n.length; e++) {
        var r = n[e];
        do
          r = r(!0);
        while (r !== null);
      }
      it = null, gl = !1;
    } catch (o) {
      throw it !== null && (it = it.slice(e + 1)), jc(Cs, It), o;
    } finally {
      j = t, Gl = !1;
    }
  }
  return null;
}
var an = [], cn = 0, Do = null, Io = 0, Ie = [], Fe = 0, Yt = null, at = 1, ct = "";
function Bt(e, t) {
  an[cn++] = Io, an[cn++] = Do, Do = e, Io = t;
}
function gf(e, t, n) {
  Ie[Fe++] = at, Ie[Fe++] = ct, Ie[Fe++] = Yt, Yt = e;
  var r = at;
  e = ct;
  var o = 32 - Ye(r) - 1;
  r &= ~(1 << o), n += 1;
  var l = 32 - Ye(t) + o;
  if (30 < l) {
    var i = o - o % 5;
    l = (r & (1 << i) - 1).toString(32), r >>= i, o -= i, at = 1 << 32 - Ye(t) + o | n << o | r, ct = l + e;
  } else at = 1 << l | n << o | r, ct = e;
}
function Ls(e) {
  e.return !== null && (Bt(e, 1), gf(e, 1, 0));
}
function Ms(e) {
  for (; e === Do; ) Do = an[--cn], an[cn] = null, Io = an[--cn], an[cn] = null;
  for (; e === Yt; ) Yt = Ie[--Fe], Ie[Fe] = null, ct = Ie[--Fe], Ie[Fe] = null, at = Ie[--Fe], Ie[Fe] = null;
}
var Le = null, Re = null, V = !1, Ge = null;
function yf(e, t) {
  var n = Ae(5, null, null, 0);
  n.elementType = "DELETED", n.stateNode = t, n.return = e, t = e.deletions, t === null ? (e.deletions = [n], e.flags |= 16) : t.push(n);
}
function Xu(e, t) {
  switch (e.tag) {
    case 5:
      var n = e.type;
      return t = t.nodeType !== 1 || n.toLowerCase() !== t.nodeName.toLowerCase() ? null : t, t !== null ? (e.stateNode = t, Le = e, Re = Nt(t.firstChild), !0) : !1;
    case 6:
      return t = e.pendingProps === "" || t.nodeType !== 3 ? null : t, t !== null ? (e.stateNode = t, Le = e, Re = null, !0) : !1;
    case 13:
      return t = t.nodeType !== 8 ? null : t, t !== null ? (n = Yt !== null ? { id: at, overflow: ct } : null, e.memoizedState = { dehydrated: t, treeContext: n, retryLane: 1073741824 }, n = Ae(18, null, null, 0), n.stateNode = t, n.return = e, e.child = n, Le = e, Re = null, !0) : !1;
    default:
      return !1;
  }
}
function $i(e) {
  return (e.mode & 1) !== 0 && (e.flags & 128) === 0;
}
function Di(e) {
  if (V) {
    var t = Re;
    if (t) {
      var n = t;
      if (!Xu(e, t)) {
        if ($i(e)) throw Error(C(418));
        t = Nt(n.nextSibling);
        var r = Le;
        t && Xu(e, t) ? yf(r, n) : (e.flags = e.flags & -4097 | 2, V = !1, Le = e);
      }
    } else {
      if ($i(e)) throw Error(C(418));
      e.flags = e.flags & -4097 | 2, V = !1, Le = e;
    }
  }
}
function Zu(e) {
  for (e = e.return; e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13; ) e = e.return;
  Le = e;
}
function Zr(e) {
  if (e !== Le) return !1;
  if (!V) return Zu(e), V = !0, !1;
  var t;
  if ((t = e.tag !== 3) && !(t = e.tag !== 5) && (t = e.type, t = t !== "head" && t !== "body" && !zi(e.type, e.memoizedProps)), t && (t = Re)) {
    if ($i(e)) throw vf(), Error(C(418));
    for (; t; ) yf(e, t), t = Nt(t.nextSibling);
  }
  if (Zu(e), e.tag === 13) {
    if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(C(317));
    e: {
      for (e = e.nextSibling, t = 0; e; ) {
        if (e.nodeType === 8) {
          var n = e.data;
          if (n === "/$") {
            if (t === 0) {
              Re = Nt(e.nextSibling);
              break e;
            }
            t--;
          } else n !== "$" && n !== "$!" && n !== "$?" || t++;
        }
        e = e.nextSibling;
      }
      Re = null;
    }
  } else Re = Le ? Nt(e.stateNode.nextSibling) : null;
  return !0;
}
function vf() {
  for (var e = Re; e; ) e = Nt(e.nextSibling);
}
function En() {
  Re = Le = null, V = !1;
}
function Os(e) {
  Ge === null ? Ge = [e] : Ge.push(e);
}
var Xm = gt.ReactCurrentBatchConfig;
function Wn(e, t, n) {
  if (e = n.ref, e !== null && typeof e != "function" && typeof e != "object") {
    if (n._owner) {
      if (n = n._owner, n) {
        if (n.tag !== 1) throw Error(C(309));
        var r = n.stateNode;
      }
      if (!r) throw Error(C(147, e));
      var o = r, l = "" + e;
      return t !== null && t.ref !== null && typeof t.ref == "function" && t.ref._stringRef === l ? t.ref : (t = function(i) {
        var s = o.refs;
        i === null ? delete s[l] : s[l] = i;
      }, t._stringRef = l, t);
    }
    if (typeof e != "string") throw Error(C(284));
    if (!n._owner) throw Error(C(290, e));
  }
  return e;
}
function Jr(e, t) {
  throw e = Object.prototype.toString.call(t), Error(C(31, e === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : e));
}
function Ju(e) {
  var t = e._init;
  return t(e._payload);
}
function wf(e) {
  function t(f, c) {
    if (e) {
      var m = f.deletions;
      m === null ? (f.deletions = [c], f.flags |= 16) : m.push(c);
    }
  }
  function n(f, c) {
    if (!e) return null;
    for (; c !== null; ) t(f, c), c = c.sibling;
    return null;
  }
  function r(f, c) {
    for (f = /* @__PURE__ */ new Map(); c !== null; ) c.key !== null ? f.set(c.key, c) : f.set(c.index, c), c = c.sibling;
    return f;
  }
  function o(f, c) {
    return f = Lt(f, c), f.index = 0, f.sibling = null, f;
  }
  function l(f, c, m) {
    return f.index = m, e ? (m = f.alternate, m !== null ? (m = m.index, m < c ? (f.flags |= 2, c) : m) : (f.flags |= 2, c)) : (f.flags |= 1048576, c);
  }
  function i(f) {
    return e && f.alternate === null && (f.flags |= 2), f;
  }
  function s(f, c, m, S) {
    return c === null || c.tag !== 6 ? (c = ei(m, f.mode, S), c.return = f, c) : (c = o(c, m), c.return = f, c);
  }
  function u(f, c, m, S) {
    var E = m.type;
    return E === nn ? d(f, c, m.props.children, S, m.key) : c !== null && (c.elementType === E || typeof E == "object" && E !== null && E.$$typeof === vt && Ju(E) === c.type) ? (S = o(c, m.props), S.ref = Wn(f, c, m), S.return = f, S) : (S = So(m.type, m.key, m.props, null, f.mode, S), S.ref = Wn(f, c, m), S.return = f, S);
  }
  function a(f, c, m, S) {
    return c === null || c.tag !== 4 || c.stateNode.containerInfo !== m.containerInfo || c.stateNode.implementation !== m.implementation ? (c = ti(m, f.mode, S), c.return = f, c) : (c = o(c, m.children || []), c.return = f, c);
  }
  function d(f, c, m, S, E) {
    return c === null || c.tag !== 7 ? (c = Qt(m, f.mode, S, E), c.return = f, c) : (c = o(c, m), c.return = f, c);
  }
  function p(f, c, m) {
    if (typeof c == "string" && c !== "" || typeof c == "number") return c = ei("" + c, f.mode, m), c.return = f, c;
    if (typeof c == "object" && c !== null) {
      switch (c.$$typeof) {
        case br:
          return m = So(c.type, c.key, c.props, null, f.mode, m), m.ref = Wn(f, null, c), m.return = f, m;
        case tn:
          return c = ti(c, f.mode, m), c.return = f, c;
        case vt:
          var S = c._init;
          return p(f, S(c._payload), m);
      }
      if (Gn(c) || An(c)) return c = Qt(c, f.mode, m, null), c.return = f, c;
      Jr(f, c);
    }
    return null;
  }
  function h(f, c, m, S) {
    var E = c !== null ? c.key : null;
    if (typeof m == "string" && m !== "" || typeof m == "number") return E !== null ? null : s(f, c, "" + m, S);
    if (typeof m == "object" && m !== null) {
      switch (m.$$typeof) {
        case br:
          return m.key === E ? u(f, c, m, S) : null;
        case tn:
          return m.key === E ? a(f, c, m, S) : null;
        case vt:
          return E = m._init, h(
            f,
            c,
            E(m._payload),
            S
          );
      }
      if (Gn(m) || An(m)) return E !== null ? null : d(f, c, m, S, null);
      Jr(f, m);
    }
    return null;
  }
  function g(f, c, m, S, E) {
    if (typeof S == "string" && S !== "" || typeof S == "number") return f = f.get(m) || null, s(c, f, "" + S, E);
    if (typeof S == "object" && S !== null) {
      switch (S.$$typeof) {
        case br:
          return f = f.get(S.key === null ? m : S.key) || null, u(c, f, S, E);
        case tn:
          return f = f.get(S.key === null ? m : S.key) || null, a(c, f, S, E);
        case vt:
          var P = S._init;
          return g(f, c, m, P(S._payload), E);
      }
      if (Gn(S) || An(S)) return f = f.get(m) || null, d(c, f, S, E, null);
      Jr(c, S);
    }
    return null;
  }
  function v(f, c, m, S) {
    for (var E = null, P = null, x = c, T = c = 0, X = null; x !== null && T < m.length; T++) {
      x.index > T ? (X = x, x = null) : X = x.sibling;
      var O = h(f, x, m[T], S);
      if (O === null) {
        x === null && (x = X);
        break;
      }
      e && x && O.alternate === null && t(f, x), c = l(O, c, T), P === null ? E = O : P.sibling = O, P = O, x = X;
    }
    if (T === m.length) return n(f, x), V && Bt(f, T), E;
    if (x === null) {
      for (; T < m.length; T++) x = p(f, m[T], S), x !== null && (c = l(x, c, T), P === null ? E = x : P.sibling = x, P = x);
      return V && Bt(f, T), E;
    }
    for (x = r(f, x); T < m.length; T++) X = g(x, f, T, m[T], S), X !== null && (e && X.alternate !== null && x.delete(X.key === null ? T : X.key), c = l(X, c, T), P === null ? E = X : P.sibling = X, P = X);
    return e && x.forEach(function(Ue) {
      return t(f, Ue);
    }), V && Bt(f, T), E;
  }
  function w(f, c, m, S) {
    var E = An(m);
    if (typeof E != "function") throw Error(C(150));
    if (m = E.call(m), m == null) throw Error(C(151));
    for (var P = E = null, x = c, T = c = 0, X = null, O = m.next(); x !== null && !O.done; T++, O = m.next()) {
      x.index > T ? (X = x, x = null) : X = x.sibling;
      var Ue = h(f, x, O.value, S);
      if (Ue === null) {
        x === null && (x = X);
        break;
      }
      e && x && Ue.alternate === null && t(f, x), c = l(Ue, c, T), P === null ? E = Ue : P.sibling = Ue, P = Ue, x = X;
    }
    if (O.done) return n(
      f,
      x
    ), V && Bt(f, T), E;
    if (x === null) {
      for (; !O.done; T++, O = m.next()) O = p(f, O.value, S), O !== null && (c = l(O, c, T), P === null ? E = O : P.sibling = O, P = O);
      return V && Bt(f, T), E;
    }
    for (x = r(f, x); !O.done; T++, O = m.next()) O = g(x, f, T, O.value, S), O !== null && (e && O.alternate !== null && x.delete(O.key === null ? T : O.key), c = l(O, c, T), P === null ? E = O : P.sibling = O, P = O);
    return e && x.forEach(function(Dn) {
      return t(f, Dn);
    }), V && Bt(f, T), E;
  }
  function R(f, c, m, S) {
    if (typeof m == "object" && m !== null && m.type === nn && m.key === null && (m = m.props.children), typeof m == "object" && m !== null) {
      switch (m.$$typeof) {
        case br:
          e: {
            for (var E = m.key, P = c; P !== null; ) {
              if (P.key === E) {
                if (E = m.type, E === nn) {
                  if (P.tag === 7) {
                    n(f, P.sibling), c = o(P, m.props.children), c.return = f, f = c;
                    break e;
                  }
                } else if (P.elementType === E || typeof E == "object" && E !== null && E.$$typeof === vt && Ju(E) === P.type) {
                  n(f, P.sibling), c = o(P, m.props), c.ref = Wn(f, P, m), c.return = f, f = c;
                  break e;
                }
                n(f, P);
                break;
              } else t(f, P);
              P = P.sibling;
            }
            m.type === nn ? (c = Qt(m.props.children, f.mode, S, m.key), c.return = f, f = c) : (S = So(m.type, m.key, m.props, null, f.mode, S), S.ref = Wn(f, c, m), S.return = f, f = S);
          }
          return i(f);
        case tn:
          e: {
            for (P = m.key; c !== null; ) {
              if (c.key === P) if (c.tag === 4 && c.stateNode.containerInfo === m.containerInfo && c.stateNode.implementation === m.implementation) {
                n(f, c.sibling), c = o(c, m.children || []), c.return = f, f = c;
                break e;
              } else {
                n(f, c);
                break;
              }
              else t(f, c);
              c = c.sibling;
            }
            c = ti(m, f.mode, S), c.return = f, f = c;
          }
          return i(f);
        case vt:
          return P = m._init, R(f, c, P(m._payload), S);
      }
      if (Gn(m)) return v(f, c, m, S);
      if (An(m)) return w(f, c, m, S);
      Jr(f, m);
    }
    return typeof m == "string" && m !== "" || typeof m == "number" ? (m = "" + m, c !== null && c.tag === 6 ? (n(f, c.sibling), c = o(c, m), c.return = f, f = c) : (n(f, c), c = ei(m, f.mode, S), c.return = f, f = c), i(f)) : n(f, c);
  }
  return R;
}
var Pn = wf(!0), kf = wf(!1), Fo = Dt(null), Ao = null, fn = null, $s = null;
function Ds() {
  $s = fn = Ao = null;
}
function Is(e) {
  var t = Fo.current;
  H(Fo), e._currentValue = t;
}
function Ii(e, t, n) {
  for (; e !== null; ) {
    var r = e.alternate;
    if ((e.childLanes & t) !== t ? (e.childLanes |= t, r !== null && (r.childLanes |= t)) : r !== null && (r.childLanes & t) !== t && (r.childLanes |= t), e === n) break;
    e = e.return;
  }
}
function wn(e, t) {
  Ao = e, $s = fn = null, e = e.dependencies, e !== null && e.firstContext !== null && (e.lanes & t && (xe = !0), e.firstContext = null);
}
function Be(e) {
  var t = e._currentValue;
  if ($s !== e) if (e = { context: e, memoizedValue: t, next: null }, fn === null) {
    if (Ao === null) throw Error(C(308));
    fn = e, Ao.dependencies = { lanes: 0, firstContext: e };
  } else fn = fn.next = e;
  return t;
}
var Wt = null;
function Fs(e) {
  Wt === null ? Wt = [e] : Wt.push(e);
}
function Sf(e, t, n, r) {
  var o = t.interleaved;
  return o === null ? (n.next = n, Fs(t)) : (n.next = o.next, o.next = n), t.interleaved = n, ht(e, r);
}
function ht(e, t) {
  e.lanes |= t;
  var n = e.alternate;
  for (n !== null && (n.lanes |= t), n = e, e = e.return; e !== null; ) e.childLanes |= t, n = e.alternate, n !== null && (n.childLanes |= t), n = e, e = e.return;
  return n.tag === 3 ? n.stateNode : null;
}
var wt = !1;
function As(e) {
  e.updateQueue = { baseState: e.memoizedState, firstBaseUpdate: null, lastBaseUpdate: null, shared: { pending: null, interleaved: null, lanes: 0 }, effects: null };
}
function Cf(e, t) {
  e = e.updateQueue, t.updateQueue === e && (t.updateQueue = { baseState: e.baseState, firstBaseUpdate: e.firstBaseUpdate, lastBaseUpdate: e.lastBaseUpdate, shared: e.shared, effects: e.effects });
}
function ft(e, t) {
  return { eventTime: e, lane: t, tag: 0, payload: null, callback: null, next: null };
}
function Tt(e, t, n) {
  var r = e.updateQueue;
  if (r === null) return null;
  if (r = r.shared, I & 2) {
    var o = r.pending;
    return o === null ? t.next = t : (t.next = o.next, o.next = t), r.pending = t, ht(e, n);
  }
  return o = r.interleaved, o === null ? (t.next = t, Fs(r)) : (t.next = o.next, o.next = t), r.interleaved = t, ht(e, n);
}
function mo(e, t, n) {
  if (t = t.updateQueue, t !== null && (t = t.shared, (n & 4194240) !== 0)) {
    var r = t.lanes;
    r &= e.pendingLanes, n |= r, t.lanes = n, xs(e, n);
  }
}
function qu(e, t) {
  var n = e.updateQueue, r = e.alternate;
  if (r !== null && (r = r.updateQueue, n === r)) {
    var o = null, l = null;
    if (n = n.firstBaseUpdate, n !== null) {
      do {
        var i = { eventTime: n.eventTime, lane: n.lane, tag: n.tag, payload: n.payload, callback: n.callback, next: null };
        l === null ? o = l = i : l = l.next = i, n = n.next;
      } while (n !== null);
      l === null ? o = l = t : l = l.next = t;
    } else o = l = t;
    n = { baseState: r.baseState, firstBaseUpdate: o, lastBaseUpdate: l, shared: r.shared, effects: r.effects }, e.updateQueue = n;
    return;
  }
  e = n.lastBaseUpdate, e === null ? n.firstBaseUpdate = t : e.next = t, n.lastBaseUpdate = t;
}
function jo(e, t, n, r) {
  var o = e.updateQueue;
  wt = !1;
  var l = o.firstBaseUpdate, i = o.lastBaseUpdate, s = o.shared.pending;
  if (s !== null) {
    o.shared.pending = null;
    var u = s, a = u.next;
    u.next = null, i === null ? l = a : i.next = a, i = u;
    var d = e.alternate;
    d !== null && (d = d.updateQueue, s = d.lastBaseUpdate, s !== i && (s === null ? d.firstBaseUpdate = a : s.next = a, d.lastBaseUpdate = u));
  }
  if (l !== null) {
    var p = o.baseState;
    i = 0, d = a = u = null, s = l;
    do {
      var h = s.lane, g = s.eventTime;
      if ((r & h) === h) {
        d !== null && (d = d.next = {
          eventTime: g,
          lane: 0,
          tag: s.tag,
          payload: s.payload,
          callback: s.callback,
          next: null
        });
        e: {
          var v = e, w = s;
          switch (h = t, g = n, w.tag) {
            case 1:
              if (v = w.payload, typeof v == "function") {
                p = v.call(g, p, h);
                break e;
              }
              p = v;
              break e;
            case 3:
              v.flags = v.flags & -65537 | 128;
            case 0:
              if (v = w.payload, h = typeof v == "function" ? v.call(g, p, h) : v, h == null) break e;
              p = Y({}, p, h);
              break e;
            case 2:
              wt = !0;
          }
        }
        s.callback !== null && s.lane !== 0 && (e.flags |= 64, h = o.effects, h === null ? o.effects = [s] : h.push(s));
      } else g = { eventTime: g, lane: h, tag: s.tag, payload: s.payload, callback: s.callback, next: null }, d === null ? (a = d = g, u = p) : d = d.next = g, i |= h;
      if (s = s.next, s === null) {
        if (s = o.shared.pending, s === null) break;
        h = s, s = h.next, h.next = null, o.lastBaseUpdate = h, o.shared.pending = null;
      }
    } while (!0);
    if (d === null && (u = p), o.baseState = u, o.firstBaseUpdate = a, o.lastBaseUpdate = d, t = o.shared.interleaved, t !== null) {
      o = t;
      do
        i |= o.lane, o = o.next;
      while (o !== t);
    } else l === null && (o.shared.lanes = 0);
    Xt |= i, e.lanes = i, e.memoizedState = p;
  }
}
function ea(e, t, n) {
  if (e = t.effects, t.effects = null, e !== null) for (t = 0; t < e.length; t++) {
    var r = e[t], o = r.callback;
    if (o !== null) {
      if (r.callback = null, r = n, typeof o != "function") throw Error(C(191, o));
      o.call(r);
    }
  }
}
var Or = {}, ot = Dt(Or), Sr = Dt(Or), Cr = Dt(Or);
function Ht(e) {
  if (e === Or) throw Error(C(174));
  return e;
}
function js(e, t) {
  switch (b(Cr, t), b(Sr, e), b(ot, Or), e = t.nodeType, e) {
    case 9:
    case 11:
      t = (t = t.documentElement) ? t.namespaceURI : gi(null, "");
      break;
    default:
      e = e === 8 ? t.parentNode : t, t = e.namespaceURI || null, e = e.tagName, t = gi(t, e);
  }
  H(ot), b(ot, t);
}
function _n() {
  H(ot), H(Sr), H(Cr);
}
function xf(e) {
  Ht(Cr.current);
  var t = Ht(ot.current), n = gi(t, e.type);
  t !== n && (b(Sr, e), b(ot, n));
}
function Bs(e) {
  Sr.current === e && (H(ot), H(Sr));
}
var Q = Dt(0);
function Bo(e) {
  for (var t = e; t !== null; ) {
    if (t.tag === 13) {
      var n = t.memoizedState;
      if (n !== null && (n = n.dehydrated, n === null || n.data === "$?" || n.data === "$!")) return t;
    } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
      if (t.flags & 128) return t;
    } else if (t.child !== null) {
      t.child.return = t, t = t.child;
      continue;
    }
    if (t === e) break;
    for (; t.sibling === null; ) {
      if (t.return === null || t.return === e) return null;
      t = t.return;
    }
    t.sibling.return = t.return, t = t.sibling;
  }
  return null;
}
var Yl = [];
function bs() {
  for (var e = 0; e < Yl.length; e++) Yl[e]._workInProgressVersionPrimary = null;
  Yl.length = 0;
}
var go = gt.ReactCurrentDispatcher, Kl = gt.ReactCurrentBatchConfig, Kt = 0, G = null, te = null, le = null, bo = !1, nr = !1, xr = 0, Zm = 0;
function de() {
  throw Error(C(321));
}
function Us(e, t) {
  if (t === null) return !1;
  for (var n = 0; n < t.length && n < e.length; n++) if (!Xe(e[n], t[n])) return !1;
  return !0;
}
function Ws(e, t, n, r, o, l) {
  if (Kt = l, G = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, go.current = e === null || e.memoizedState === null ? t0 : n0, e = n(r, o), nr) {
    l = 0;
    do {
      if (nr = !1, xr = 0, 25 <= l) throw Error(C(301));
      l += 1, le = te = null, t.updateQueue = null, go.current = r0, e = n(r, o);
    } while (nr);
  }
  if (go.current = Uo, t = te !== null && te.next !== null, Kt = 0, le = te = G = null, bo = !1, t) throw Error(C(300));
  return e;
}
function Hs() {
  var e = xr !== 0;
  return xr = 0, e;
}
function Je() {
  var e = { memoizedState: null, baseState: null, baseQueue: null, queue: null, next: null };
  return le === null ? G.memoizedState = le = e : le = le.next = e, le;
}
function be() {
  if (te === null) {
    var e = G.alternate;
    e = e !== null ? e.memoizedState : null;
  } else e = te.next;
  var t = le === null ? G.memoizedState : le.next;
  if (t !== null) le = t, te = e;
  else {
    if (e === null) throw Error(C(310));
    te = e, e = { memoizedState: te.memoizedState, baseState: te.baseState, baseQueue: te.baseQueue, queue: te.queue, next: null }, le === null ? G.memoizedState = le = e : le = le.next = e;
  }
  return le;
}
function Er(e, t) {
  return typeof t == "function" ? t(e) : t;
}
function Xl(e) {
  var t = be(), n = t.queue;
  if (n === null) throw Error(C(311));
  n.lastRenderedReducer = e;
  var r = te, o = r.baseQueue, l = n.pending;
  if (l !== null) {
    if (o !== null) {
      var i = o.next;
      o.next = l.next, l.next = i;
    }
    r.baseQueue = o = l, n.pending = null;
  }
  if (o !== null) {
    l = o.next, r = r.baseState;
    var s = i = null, u = null, a = l;
    do {
      var d = a.lane;
      if ((Kt & d) === d) u !== null && (u = u.next = { lane: 0, action: a.action, hasEagerState: a.hasEagerState, eagerState: a.eagerState, next: null }), r = a.hasEagerState ? a.eagerState : e(r, a.action);
      else {
        var p = {
          lane: d,
          action: a.action,
          hasEagerState: a.hasEagerState,
          eagerState: a.eagerState,
          next: null
        };
        u === null ? (s = u = p, i = r) : u = u.next = p, G.lanes |= d, Xt |= d;
      }
      a = a.next;
    } while (a !== null && a !== l);
    u === null ? i = r : u.next = s, Xe(r, t.memoizedState) || (xe = !0), t.memoizedState = r, t.baseState = i, t.baseQueue = u, n.lastRenderedState = r;
  }
  if (e = n.interleaved, e !== null) {
    o = e;
    do
      l = o.lane, G.lanes |= l, Xt |= l, o = o.next;
    while (o !== e);
  } else o === null && (n.lanes = 0);
  return [t.memoizedState, n.dispatch];
}
function Zl(e) {
  var t = be(), n = t.queue;
  if (n === null) throw Error(C(311));
  n.lastRenderedReducer = e;
  var r = n.dispatch, o = n.pending, l = t.memoizedState;
  if (o !== null) {
    n.pending = null;
    var i = o = o.next;
    do
      l = e(l, i.action), i = i.next;
    while (i !== o);
    Xe(l, t.memoizedState) || (xe = !0), t.memoizedState = l, t.baseQueue === null && (t.baseState = l), n.lastRenderedState = l;
  }
  return [l, r];
}
function Ef() {
}
function Pf(e, t) {
  var n = G, r = be(), o = t(), l = !Xe(r.memoizedState, o);
  if (l && (r.memoizedState = o, xe = !0), r = r.queue, Vs(Tf.bind(null, n, r, e), [e]), r.getSnapshot !== t || l || le !== null && le.memoizedState.tag & 1) {
    if (n.flags |= 2048, Pr(9, Nf.bind(null, n, r, o, t), void 0, null), ie === null) throw Error(C(349));
    Kt & 30 || _f(n, t, o);
  }
  return o;
}
function _f(e, t, n) {
  e.flags |= 16384, e = { getSnapshot: t, value: n }, t = G.updateQueue, t === null ? (t = { lastEffect: null, stores: null }, G.updateQueue = t, t.stores = [e]) : (n = t.stores, n === null ? t.stores = [e] : n.push(e));
}
function Nf(e, t, n, r) {
  t.value = n, t.getSnapshot = r, Rf(t) && zf(e);
}
function Tf(e, t, n) {
  return n(function() {
    Rf(t) && zf(e);
  });
}
function Rf(e) {
  var t = e.getSnapshot;
  e = e.value;
  try {
    var n = t();
    return !Xe(e, n);
  } catch {
    return !0;
  }
}
function zf(e) {
  var t = ht(e, 1);
  t !== null && Ke(t, e, 1, -1);
}
function ta(e) {
  var t = Je();
  return typeof e == "function" && (e = e()), t.memoizedState = t.baseState = e, e = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: Er, lastRenderedState: e }, t.queue = e, e = e.dispatch = e0.bind(null, G, e), [t.memoizedState, e];
}
function Pr(e, t, n, r) {
  return e = { tag: e, create: t, destroy: n, deps: r, next: null }, t = G.updateQueue, t === null ? (t = { lastEffect: null, stores: null }, G.updateQueue = t, t.lastEffect = e.next = e) : (n = t.lastEffect, n === null ? t.lastEffect = e.next = e : (r = n.next, n.next = e, e.next = r, t.lastEffect = e)), e;
}
function Lf() {
  return be().memoizedState;
}
function yo(e, t, n, r) {
  var o = Je();
  G.flags |= e, o.memoizedState = Pr(1 | t, n, void 0, r === void 0 ? null : r);
}
function yl(e, t, n, r) {
  var o = be();
  r = r === void 0 ? null : r;
  var l = void 0;
  if (te !== null) {
    var i = te.memoizedState;
    if (l = i.destroy, r !== null && Us(r, i.deps)) {
      o.memoizedState = Pr(t, n, l, r);
      return;
    }
  }
  G.flags |= e, o.memoizedState = Pr(1 | t, n, l, r);
}
function na(e, t) {
  return yo(8390656, 8, e, t);
}
function Vs(e, t) {
  return yl(2048, 8, e, t);
}
function Mf(e, t) {
  return yl(4, 2, e, t);
}
function Of(e, t) {
  return yl(4, 4, e, t);
}
function $f(e, t) {
  if (typeof t == "function") return e = e(), t(e), function() {
    t(null);
  };
  if (t != null) return e = e(), t.current = e, function() {
    t.current = null;
  };
}
function Df(e, t, n) {
  return n = n != null ? n.concat([e]) : null, yl(4, 4, $f.bind(null, t, e), n);
}
function Qs() {
}
function If(e, t) {
  var n = be();
  t = t === void 0 ? null : t;
  var r = n.memoizedState;
  return r !== null && t !== null && Us(t, r[1]) ? r[0] : (n.memoizedState = [e, t], e);
}
function Ff(e, t) {
  var n = be();
  t = t === void 0 ? null : t;
  var r = n.memoizedState;
  return r !== null && t !== null && Us(t, r[1]) ? r[0] : (e = e(), n.memoizedState = [e, t], e);
}
function Af(e, t, n) {
  return Kt & 21 ? (Xe(n, t) || (n = Uc(), G.lanes |= n, Xt |= n, e.baseState = !0), t) : (e.baseState && (e.baseState = !1, xe = !0), e.memoizedState = n);
}
function Jm(e, t) {
  var n = j;
  j = n !== 0 && 4 > n ? n : 4, e(!0);
  var r = Kl.transition;
  Kl.transition = {};
  try {
    e(!1), t();
  } finally {
    j = n, Kl.transition = r;
  }
}
function jf() {
  return be().memoizedState;
}
function qm(e, t, n) {
  var r = zt(e);
  if (n = { lane: r, action: n, hasEagerState: !1, eagerState: null, next: null }, Bf(e)) bf(t, n);
  else if (n = Sf(e, t, n, r), n !== null) {
    var o = we();
    Ke(n, e, r, o), Uf(n, t, r);
  }
}
function e0(e, t, n) {
  var r = zt(e), o = { lane: r, action: n, hasEagerState: !1, eagerState: null, next: null };
  if (Bf(e)) bf(t, o);
  else {
    var l = e.alternate;
    if (e.lanes === 0 && (l === null || l.lanes === 0) && (l = t.lastRenderedReducer, l !== null)) try {
      var i = t.lastRenderedState, s = l(i, n);
      if (o.hasEagerState = !0, o.eagerState = s, Xe(s, i)) {
        var u = t.interleaved;
        u === null ? (o.next = o, Fs(t)) : (o.next = u.next, u.next = o), t.interleaved = o;
        return;
      }
    } catch {
    } finally {
    }
    n = Sf(e, t, o, r), n !== null && (o = we(), Ke(n, e, r, o), Uf(n, t, r));
  }
}
function Bf(e) {
  var t = e.alternate;
  return e === G || t !== null && t === G;
}
function bf(e, t) {
  nr = bo = !0;
  var n = e.pending;
  n === null ? t.next = t : (t.next = n.next, n.next = t), e.pending = t;
}
function Uf(e, t, n) {
  if (n & 4194240) {
    var r = t.lanes;
    r &= e.pendingLanes, n |= r, t.lanes = n, xs(e, n);
  }
}
var Uo = { readContext: Be, useCallback: de, useContext: de, useEffect: de, useImperativeHandle: de, useInsertionEffect: de, useLayoutEffect: de, useMemo: de, useReducer: de, useRef: de, useState: de, useDebugValue: de, useDeferredValue: de, useTransition: de, useMutableSource: de, useSyncExternalStore: de, useId: de, unstable_isNewReconciler: !1 }, t0 = { readContext: Be, useCallback: function(e, t) {
  return Je().memoizedState = [e, t === void 0 ? null : t], e;
}, useContext: Be, useEffect: na, useImperativeHandle: function(e, t, n) {
  return n = n != null ? n.concat([e]) : null, yo(
    4194308,
    4,
    $f.bind(null, t, e),
    n
  );
}, useLayoutEffect: function(e, t) {
  return yo(4194308, 4, e, t);
}, useInsertionEffect: function(e, t) {
  return yo(4, 2, e, t);
}, useMemo: function(e, t) {
  var n = Je();
  return t = t === void 0 ? null : t, e = e(), n.memoizedState = [e, t], e;
}, useReducer: function(e, t, n) {
  var r = Je();
  return t = n !== void 0 ? n(t) : t, r.memoizedState = r.baseState = t, e = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: e, lastRenderedState: t }, r.queue = e, e = e.dispatch = qm.bind(null, G, e), [r.memoizedState, e];
}, useRef: function(e) {
  var t = Je();
  return e = { current: e }, t.memoizedState = e;
}, useState: ta, useDebugValue: Qs, useDeferredValue: function(e) {
  return Je().memoizedState = e;
}, useTransition: function() {
  var e = ta(!1), t = e[0];
  return e = Jm.bind(null, e[1]), Je().memoizedState = e, [t, e];
}, useMutableSource: function() {
}, useSyncExternalStore: function(e, t, n) {
  var r = G, o = Je();
  if (V) {
    if (n === void 0) throw Error(C(407));
    n = n();
  } else {
    if (n = t(), ie === null) throw Error(C(349));
    Kt & 30 || _f(r, t, n);
  }
  o.memoizedState = n;
  var l = { value: n, getSnapshot: t };
  return o.queue = l, na(Tf.bind(
    null,
    r,
    l,
    e
  ), [e]), r.flags |= 2048, Pr(9, Nf.bind(null, r, l, n, t), void 0, null), n;
}, useId: function() {
  var e = Je(), t = ie.identifierPrefix;
  if (V) {
    var n = ct, r = at;
    n = (r & ~(1 << 32 - Ye(r) - 1)).toString(32) + n, t = ":" + t + "R" + n, n = xr++, 0 < n && (t += "H" + n.toString(32)), t += ":";
  } else n = Zm++, t = ":" + t + "r" + n.toString(32) + ":";
  return e.memoizedState = t;
}, unstable_isNewReconciler: !1 }, n0 = {
  readContext: Be,
  useCallback: If,
  useContext: Be,
  useEffect: Vs,
  useImperativeHandle: Df,
  useInsertionEffect: Mf,
  useLayoutEffect: Of,
  useMemo: Ff,
  useReducer: Xl,
  useRef: Lf,
  useState: function() {
    return Xl(Er);
  },
  useDebugValue: Qs,
  useDeferredValue: function(e) {
    var t = be();
    return Af(t, te.memoizedState, e);
  },
  useTransition: function() {
    var e = Xl(Er)[0], t = be().memoizedState;
    return [e, t];
  },
  useMutableSource: Ef,
  useSyncExternalStore: Pf,
  useId: jf,
  unstable_isNewReconciler: !1
}, r0 = { readContext: Be, useCallback: If, useContext: Be, useEffect: Vs, useImperativeHandle: Df, useInsertionEffect: Mf, useLayoutEffect: Of, useMemo: Ff, useReducer: Zl, useRef: Lf, useState: function() {
  return Zl(Er);
}, useDebugValue: Qs, useDeferredValue: function(e) {
  var t = be();
  return te === null ? t.memoizedState = e : Af(t, te.memoizedState, e);
}, useTransition: function() {
  var e = Zl(Er)[0], t = be().memoizedState;
  return [e, t];
}, useMutableSource: Ef, useSyncExternalStore: Pf, useId: jf, unstable_isNewReconciler: !1 };
function Ve(e, t) {
  if (e && e.defaultProps) {
    t = Y({}, t), e = e.defaultProps;
    for (var n in e) t[n] === void 0 && (t[n] = e[n]);
    return t;
  }
  return t;
}
function Fi(e, t, n, r) {
  t = e.memoizedState, n = n(r, t), n = n == null ? t : Y({}, t, n), e.memoizedState = n, e.lanes === 0 && (e.updateQueue.baseState = n);
}
var vl = { isMounted: function(e) {
  return (e = e._reactInternals) ? qt(e) === e : !1;
}, enqueueSetState: function(e, t, n) {
  e = e._reactInternals;
  var r = we(), o = zt(e), l = ft(r, o);
  l.payload = t, n != null && (l.callback = n), t = Tt(e, l, o), t !== null && (Ke(t, e, o, r), mo(t, e, o));
}, enqueueReplaceState: function(e, t, n) {
  e = e._reactInternals;
  var r = we(), o = zt(e), l = ft(r, o);
  l.tag = 1, l.payload = t, n != null && (l.callback = n), t = Tt(e, l, o), t !== null && (Ke(t, e, o, r), mo(t, e, o));
}, enqueueForceUpdate: function(e, t) {
  e = e._reactInternals;
  var n = we(), r = zt(e), o = ft(n, r);
  o.tag = 2, t != null && (o.callback = t), t = Tt(e, o, r), t !== null && (Ke(t, e, r, n), mo(t, e, r));
} };
function ra(e, t, n, r, o, l, i) {
  return e = e.stateNode, typeof e.shouldComponentUpdate == "function" ? e.shouldComponentUpdate(r, l, i) : t.prototype && t.prototype.isPureReactComponent ? !yr(n, r) || !yr(o, l) : !0;
}
function Wf(e, t, n) {
  var r = !1, o = Ot, l = t.contextType;
  return typeof l == "object" && l !== null ? l = Be(l) : (o = Pe(t) ? Gt : ye.current, r = t.contextTypes, l = (r = r != null) ? xn(e, o) : Ot), t = new t(n, l), e.memoizedState = t.state !== null && t.state !== void 0 ? t.state : null, t.updater = vl, e.stateNode = t, t._reactInternals = e, r && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = o, e.__reactInternalMemoizedMaskedChildContext = l), t;
}
function oa(e, t, n, r) {
  e = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(n, r), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(n, r), t.state !== e && vl.enqueueReplaceState(t, t.state, null);
}
function Ai(e, t, n, r) {
  var o = e.stateNode;
  o.props = n, o.state = e.memoizedState, o.refs = {}, As(e);
  var l = t.contextType;
  typeof l == "object" && l !== null ? o.context = Be(l) : (l = Pe(t) ? Gt : ye.current, o.context = xn(e, l)), o.state = e.memoizedState, l = t.getDerivedStateFromProps, typeof l == "function" && (Fi(e, t, l, n), o.state = e.memoizedState), typeof t.getDerivedStateFromProps == "function" || typeof o.getSnapshotBeforeUpdate == "function" || typeof o.UNSAFE_componentWillMount != "function" && typeof o.componentWillMount != "function" || (t = o.state, typeof o.componentWillMount == "function" && o.componentWillMount(), typeof o.UNSAFE_componentWillMount == "function" && o.UNSAFE_componentWillMount(), t !== o.state && vl.enqueueReplaceState(o, o.state, null), jo(e, n, o, r), o.state = e.memoizedState), typeof o.componentDidMount == "function" && (e.flags |= 4194308);
}
function Nn(e, t) {
  try {
    var n = "", r = t;
    do
      n += Lh(r), r = r.return;
    while (r);
    var o = n;
  } catch (l) {
    o = `
Error generating stack: ` + l.message + `
` + l.stack;
  }
  return { value: e, source: t, stack: o, digest: null };
}
function Jl(e, t, n) {
  return { value: e, source: null, stack: n ?? null, digest: t ?? null };
}
function ji(e, t) {
  try {
    console.error(t.value);
  } catch (n) {
    setTimeout(function() {
      throw n;
    });
  }
}
var o0 = typeof WeakMap == "function" ? WeakMap : Map;
function Hf(e, t, n) {
  n = ft(-1, n), n.tag = 3, n.payload = { element: null };
  var r = t.value;
  return n.callback = function() {
    Ho || (Ho = !0, Ki = r), ji(e, t);
  }, n;
}
function Vf(e, t, n) {
  n = ft(-1, n), n.tag = 3;
  var r = e.type.getDerivedStateFromError;
  if (typeof r == "function") {
    var o = t.value;
    n.payload = function() {
      return r(o);
    }, n.callback = function() {
      ji(e, t);
    };
  }
  var l = e.stateNode;
  return l !== null && typeof l.componentDidCatch == "function" && (n.callback = function() {
    ji(e, t), typeof r != "function" && (Rt === null ? Rt = /* @__PURE__ */ new Set([this]) : Rt.add(this));
    var i = t.stack;
    this.componentDidCatch(t.value, { componentStack: i !== null ? i : "" });
  }), n;
}
function la(e, t, n) {
  var r = e.pingCache;
  if (r === null) {
    r = e.pingCache = new o0();
    var o = /* @__PURE__ */ new Set();
    r.set(t, o);
  } else o = r.get(t), o === void 0 && (o = /* @__PURE__ */ new Set(), r.set(t, o));
  o.has(n) || (o.add(n), e = v0.bind(null, e, t, n), t.then(e, e));
}
function ia(e) {
  do {
    var t;
    if ((t = e.tag === 13) && (t = e.memoizedState, t = t !== null ? t.dehydrated !== null : !0), t) return e;
    e = e.return;
  } while (e !== null);
  return null;
}
function sa(e, t, n, r, o) {
  return e.mode & 1 ? (e.flags |= 65536, e.lanes = o, e) : (e === t ? e.flags |= 65536 : (e.flags |= 128, n.flags |= 131072, n.flags &= -52805, n.tag === 1 && (n.alternate === null ? n.tag = 17 : (t = ft(-1, 1), t.tag = 2, Tt(n, t, 1))), n.lanes |= 1), e);
}
var l0 = gt.ReactCurrentOwner, xe = !1;
function ve(e, t, n, r) {
  t.child = e === null ? kf(t, null, n, r) : Pn(t, e.child, n, r);
}
function ua(e, t, n, r, o) {
  n = n.render;
  var l = t.ref;
  return wn(t, o), r = Ws(e, t, n, r, l, o), n = Hs(), e !== null && !xe ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~o, mt(e, t, o)) : (V && n && Ls(t), t.flags |= 1, ve(e, t, r, o), t.child);
}
function aa(e, t, n, r, o) {
  if (e === null) {
    var l = n.type;
    return typeof l == "function" && !eu(l) && l.defaultProps === void 0 && n.compare === null && n.defaultProps === void 0 ? (t.tag = 15, t.type = l, Qf(e, t, l, r, o)) : (e = So(n.type, null, r, t, t.mode, o), e.ref = t.ref, e.return = t, t.child = e);
  }
  if (l = e.child, !(e.lanes & o)) {
    var i = l.memoizedProps;
    if (n = n.compare, n = n !== null ? n : yr, n(i, r) && e.ref === t.ref) return mt(e, t, o);
  }
  return t.flags |= 1, e = Lt(l, r), e.ref = t.ref, e.return = t, t.child = e;
}
function Qf(e, t, n, r, o) {
  if (e !== null) {
    var l = e.memoizedProps;
    if (yr(l, r) && e.ref === t.ref) if (xe = !1, t.pendingProps = r = l, (e.lanes & o) !== 0) e.flags & 131072 && (xe = !0);
    else return t.lanes = e.lanes, mt(e, t, o);
  }
  return Bi(e, t, n, r, o);
}
function Gf(e, t, n) {
  var r = t.pendingProps, o = r.children, l = e !== null ? e.memoizedState : null;
  if (r.mode === "hidden") if (!(t.mode & 1)) t.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, b(pn, Te), Te |= n;
  else {
    if (!(n & 1073741824)) return e = l !== null ? l.baseLanes | n : n, t.lanes = t.childLanes = 1073741824, t.memoizedState = { baseLanes: e, cachePool: null, transitions: null }, t.updateQueue = null, b(pn, Te), Te |= e, null;
    t.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, r = l !== null ? l.baseLanes : n, b(pn, Te), Te |= r;
  }
  else l !== null ? (r = l.baseLanes | n, t.memoizedState = null) : r = n, b(pn, Te), Te |= r;
  return ve(e, t, o, n), t.child;
}
function Yf(e, t) {
  var n = t.ref;
  (e === null && n !== null || e !== null && e.ref !== n) && (t.flags |= 512, t.flags |= 2097152);
}
function Bi(e, t, n, r, o) {
  var l = Pe(n) ? Gt : ye.current;
  return l = xn(t, l), wn(t, o), n = Ws(e, t, n, r, l, o), r = Hs(), e !== null && !xe ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~o, mt(e, t, o)) : (V && r && Ls(t), t.flags |= 1, ve(e, t, n, o), t.child);
}
function ca(e, t, n, r, o) {
  if (Pe(n)) {
    var l = !0;
    $o(t);
  } else l = !1;
  if (wn(t, o), t.stateNode === null) vo(e, t), Wf(t, n, r), Ai(t, n, r, o), r = !0;
  else if (e === null) {
    var i = t.stateNode, s = t.memoizedProps;
    i.props = s;
    var u = i.context, a = n.contextType;
    typeof a == "object" && a !== null ? a = Be(a) : (a = Pe(n) ? Gt : ye.current, a = xn(t, a));
    var d = n.getDerivedStateFromProps, p = typeof d == "function" || typeof i.getSnapshotBeforeUpdate == "function";
    p || typeof i.UNSAFE_componentWillReceiveProps != "function" && typeof i.componentWillReceiveProps != "function" || (s !== r || u !== a) && oa(t, i, r, a), wt = !1;
    var h = t.memoizedState;
    i.state = h, jo(t, r, i, o), u = t.memoizedState, s !== r || h !== u || Ee.current || wt ? (typeof d == "function" && (Fi(t, n, d, r), u = t.memoizedState), (s = wt || ra(t, n, s, r, h, u, a)) ? (p || typeof i.UNSAFE_componentWillMount != "function" && typeof i.componentWillMount != "function" || (typeof i.componentWillMount == "function" && i.componentWillMount(), typeof i.UNSAFE_componentWillMount == "function" && i.UNSAFE_componentWillMount()), typeof i.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof i.componentDidMount == "function" && (t.flags |= 4194308), t.memoizedProps = r, t.memoizedState = u), i.props = r, i.state = u, i.context = a, r = s) : (typeof i.componentDidMount == "function" && (t.flags |= 4194308), r = !1);
  } else {
    i = t.stateNode, Cf(e, t), s = t.memoizedProps, a = t.type === t.elementType ? s : Ve(t.type, s), i.props = a, p = t.pendingProps, h = i.context, u = n.contextType, typeof u == "object" && u !== null ? u = Be(u) : (u = Pe(n) ? Gt : ye.current, u = xn(t, u));
    var g = n.getDerivedStateFromProps;
    (d = typeof g == "function" || typeof i.getSnapshotBeforeUpdate == "function") || typeof i.UNSAFE_componentWillReceiveProps != "function" && typeof i.componentWillReceiveProps != "function" || (s !== p || h !== u) && oa(t, i, r, u), wt = !1, h = t.memoizedState, i.state = h, jo(t, r, i, o);
    var v = t.memoizedState;
    s !== p || h !== v || Ee.current || wt ? (typeof g == "function" && (Fi(t, n, g, r), v = t.memoizedState), (a = wt || ra(t, n, a, r, h, v, u) || !1) ? (d || typeof i.UNSAFE_componentWillUpdate != "function" && typeof i.componentWillUpdate != "function" || (typeof i.componentWillUpdate == "function" && i.componentWillUpdate(r, v, u), typeof i.UNSAFE_componentWillUpdate == "function" && i.UNSAFE_componentWillUpdate(r, v, u)), typeof i.componentDidUpdate == "function" && (t.flags |= 4), typeof i.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof i.componentDidUpdate != "function" || s === e.memoizedProps && h === e.memoizedState || (t.flags |= 4), typeof i.getSnapshotBeforeUpdate != "function" || s === e.memoizedProps && h === e.memoizedState || (t.flags |= 1024), t.memoizedProps = r, t.memoizedState = v), i.props = r, i.state = v, i.context = u, r = a) : (typeof i.componentDidUpdate != "function" || s === e.memoizedProps && h === e.memoizedState || (t.flags |= 4), typeof i.getSnapshotBeforeUpdate != "function" || s === e.memoizedProps && h === e.memoizedState || (t.flags |= 1024), r = !1);
  }
  return bi(e, t, n, r, l, o);
}
function bi(e, t, n, r, o, l) {
  Yf(e, t);
  var i = (t.flags & 128) !== 0;
  if (!r && !i) return o && Ku(t, n, !1), mt(e, t, l);
  r = t.stateNode, l0.current = t;
  var s = i && typeof n.getDerivedStateFromError != "function" ? null : r.render();
  return t.flags |= 1, e !== null && i ? (t.child = Pn(t, e.child, null, l), t.child = Pn(t, null, s, l)) : ve(e, t, s, l), t.memoizedState = r.state, o && Ku(t, n, !0), t.child;
}
function Kf(e) {
  var t = e.stateNode;
  t.pendingContext ? Yu(e, t.pendingContext, t.pendingContext !== t.context) : t.context && Yu(e, t.context, !1), js(e, t.containerInfo);
}
function fa(e, t, n, r, o) {
  return En(), Os(o), t.flags |= 256, ve(e, t, n, r), t.child;
}
var Ui = { dehydrated: null, treeContext: null, retryLane: 0 };
function Wi(e) {
  return { baseLanes: e, cachePool: null, transitions: null };
}
function Xf(e, t, n) {
  var r = t.pendingProps, o = Q.current, l = !1, i = (t.flags & 128) !== 0, s;
  if ((s = i) || (s = e !== null && e.memoizedState === null ? !1 : (o & 2) !== 0), s ? (l = !0, t.flags &= -129) : (e === null || e.memoizedState !== null) && (o |= 1), b(Q, o & 1), e === null)
    return Di(t), e = t.memoizedState, e !== null && (e = e.dehydrated, e !== null) ? (t.mode & 1 ? e.data === "$!" ? t.lanes = 8 : t.lanes = 1073741824 : t.lanes = 1, null) : (i = r.children, e = r.fallback, l ? (r = t.mode, l = t.child, i = { mode: "hidden", children: i }, !(r & 1) && l !== null ? (l.childLanes = 0, l.pendingProps = i) : l = Sl(i, r, 0, null), e = Qt(e, r, n, null), l.return = t, e.return = t, l.sibling = e, t.child = l, t.child.memoizedState = Wi(n), t.memoizedState = Ui, e) : Gs(t, i));
  if (o = e.memoizedState, o !== null && (s = o.dehydrated, s !== null)) return i0(e, t, i, r, s, o, n);
  if (l) {
    l = r.fallback, i = t.mode, o = e.child, s = o.sibling;
    var u = { mode: "hidden", children: r.children };
    return !(i & 1) && t.child !== o ? (r = t.child, r.childLanes = 0, r.pendingProps = u, t.deletions = null) : (r = Lt(o, u), r.subtreeFlags = o.subtreeFlags & 14680064), s !== null ? l = Lt(s, l) : (l = Qt(l, i, n, null), l.flags |= 2), l.return = t, r.return = t, r.sibling = l, t.child = r, r = l, l = t.child, i = e.child.memoizedState, i = i === null ? Wi(n) : { baseLanes: i.baseLanes | n, cachePool: null, transitions: i.transitions }, l.memoizedState = i, l.childLanes = e.childLanes & ~n, t.memoizedState = Ui, r;
  }
  return l = e.child, e = l.sibling, r = Lt(l, { mode: "visible", children: r.children }), !(t.mode & 1) && (r.lanes = n), r.return = t, r.sibling = null, e !== null && (n = t.deletions, n === null ? (t.deletions = [e], t.flags |= 16) : n.push(e)), t.child = r, t.memoizedState = null, r;
}
function Gs(e, t) {
  return t = Sl({ mode: "visible", children: t }, e.mode, 0, null), t.return = e, e.child = t;
}
function qr(e, t, n, r) {
  return r !== null && Os(r), Pn(t, e.child, null, n), e = Gs(t, t.pendingProps.children), e.flags |= 2, t.memoizedState = null, e;
}
function i0(e, t, n, r, o, l, i) {
  if (n)
    return t.flags & 256 ? (t.flags &= -257, r = Jl(Error(C(422))), qr(e, t, i, r)) : t.memoizedState !== null ? (t.child = e.child, t.flags |= 128, null) : (l = r.fallback, o = t.mode, r = Sl({ mode: "visible", children: r.children }, o, 0, null), l = Qt(l, o, i, null), l.flags |= 2, r.return = t, l.return = t, r.sibling = l, t.child = r, t.mode & 1 && Pn(t, e.child, null, i), t.child.memoizedState = Wi(i), t.memoizedState = Ui, l);
  if (!(t.mode & 1)) return qr(e, t, i, null);
  if (o.data === "$!") {
    if (r = o.nextSibling && o.nextSibling.dataset, r) var s = r.dgst;
    return r = s, l = Error(C(419)), r = Jl(l, r, void 0), qr(e, t, i, r);
  }
  if (s = (i & e.childLanes) !== 0, xe || s) {
    if (r = ie, r !== null) {
      switch (i & -i) {
        case 4:
          o = 2;
          break;
        case 16:
          o = 8;
          break;
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
          o = 32;
          break;
        case 536870912:
          o = 268435456;
          break;
        default:
          o = 0;
      }
      o = o & (r.suspendedLanes | i) ? 0 : o, o !== 0 && o !== l.retryLane && (l.retryLane = o, ht(e, o), Ke(r, e, o, -1));
    }
    return qs(), r = Jl(Error(C(421))), qr(e, t, i, r);
  }
  return o.data === "$?" ? (t.flags |= 128, t.child = e.child, t = w0.bind(null, e), o._reactRetry = t, null) : (e = l.treeContext, Re = Nt(o.nextSibling), Le = t, V = !0, Ge = null, e !== null && (Ie[Fe++] = at, Ie[Fe++] = ct, Ie[Fe++] = Yt, at = e.id, ct = e.overflow, Yt = t), t = Gs(t, r.children), t.flags |= 4096, t);
}
function da(e, t, n) {
  e.lanes |= t;
  var r = e.alternate;
  r !== null && (r.lanes |= t), Ii(e.return, t, n);
}
function ql(e, t, n, r, o) {
  var l = e.memoizedState;
  l === null ? e.memoizedState = { isBackwards: t, rendering: null, renderingStartTime: 0, last: r, tail: n, tailMode: o } : (l.isBackwards = t, l.rendering = null, l.renderingStartTime = 0, l.last = r, l.tail = n, l.tailMode = o);
}
function Zf(e, t, n) {
  var r = t.pendingProps, o = r.revealOrder, l = r.tail;
  if (ve(e, t, r.children, n), r = Q.current, r & 2) r = r & 1 | 2, t.flags |= 128;
  else {
    if (e !== null && e.flags & 128) e: for (e = t.child; e !== null; ) {
      if (e.tag === 13) e.memoizedState !== null && da(e, n, t);
      else if (e.tag === 19) da(e, n, t);
      else if (e.child !== null) {
        e.child.return = e, e = e.child;
        continue;
      }
      if (e === t) break e;
      for (; e.sibling === null; ) {
        if (e.return === null || e.return === t) break e;
        e = e.return;
      }
      e.sibling.return = e.return, e = e.sibling;
    }
    r &= 1;
  }
  if (b(Q, r), !(t.mode & 1)) t.memoizedState = null;
  else switch (o) {
    case "forwards":
      for (n = t.child, o = null; n !== null; ) e = n.alternate, e !== null && Bo(e) === null && (o = n), n = n.sibling;
      n = o, n === null ? (o = t.child, t.child = null) : (o = n.sibling, n.sibling = null), ql(t, !1, o, n, l);
      break;
    case "backwards":
      for (n = null, o = t.child, t.child = null; o !== null; ) {
        if (e = o.alternate, e !== null && Bo(e) === null) {
          t.child = o;
          break;
        }
        e = o.sibling, o.sibling = n, n = o, o = e;
      }
      ql(t, !0, n, null, l);
      break;
    case "together":
      ql(t, !1, null, null, void 0);
      break;
    default:
      t.memoizedState = null;
  }
  return t.child;
}
function vo(e, t) {
  !(t.mode & 1) && e !== null && (e.alternate = null, t.alternate = null, t.flags |= 2);
}
function mt(e, t, n) {
  if (e !== null && (t.dependencies = e.dependencies), Xt |= t.lanes, !(n & t.childLanes)) return null;
  if (e !== null && t.child !== e.child) throw Error(C(153));
  if (t.child !== null) {
    for (e = t.child, n = Lt(e, e.pendingProps), t.child = n, n.return = t; e.sibling !== null; ) e = e.sibling, n = n.sibling = Lt(e, e.pendingProps), n.return = t;
    n.sibling = null;
  }
  return t.child;
}
function s0(e, t, n) {
  switch (t.tag) {
    case 3:
      Kf(t), En();
      break;
    case 5:
      xf(t);
      break;
    case 1:
      Pe(t.type) && $o(t);
      break;
    case 4:
      js(t, t.stateNode.containerInfo);
      break;
    case 10:
      var r = t.type._context, o = t.memoizedProps.value;
      b(Fo, r._currentValue), r._currentValue = o;
      break;
    case 13:
      if (r = t.memoizedState, r !== null)
        return r.dehydrated !== null ? (b(Q, Q.current & 1), t.flags |= 128, null) : n & t.child.childLanes ? Xf(e, t, n) : (b(Q, Q.current & 1), e = mt(e, t, n), e !== null ? e.sibling : null);
      b(Q, Q.current & 1);
      break;
    case 19:
      if (r = (n & t.childLanes) !== 0, e.flags & 128) {
        if (r) return Zf(e, t, n);
        t.flags |= 128;
      }
      if (o = t.memoizedState, o !== null && (o.rendering = null, o.tail = null, o.lastEffect = null), b(Q, Q.current), r) break;
      return null;
    case 22:
    case 23:
      return t.lanes = 0, Gf(e, t, n);
  }
  return mt(e, t, n);
}
var Jf, Hi, qf, ed;
Jf = function(e, t) {
  for (var n = t.child; n !== null; ) {
    if (n.tag === 5 || n.tag === 6) e.appendChild(n.stateNode);
    else if (n.tag !== 4 && n.child !== null) {
      n.child.return = n, n = n.child;
      continue;
    }
    if (n === t) break;
    for (; n.sibling === null; ) {
      if (n.return === null || n.return === t) return;
      n = n.return;
    }
    n.sibling.return = n.return, n = n.sibling;
  }
};
Hi = function() {
};
qf = function(e, t, n, r) {
  var o = e.memoizedProps;
  if (o !== r) {
    e = t.stateNode, Ht(ot.current);
    var l = null;
    switch (n) {
      case "input":
        o = di(e, o), r = di(e, r), l = [];
        break;
      case "select":
        o = Y({}, o, { value: void 0 }), r = Y({}, r, { value: void 0 }), l = [];
        break;
      case "textarea":
        o = mi(e, o), r = mi(e, r), l = [];
        break;
      default:
        typeof o.onClick != "function" && typeof r.onClick == "function" && (e.onclick = Mo);
    }
    yi(n, r);
    var i;
    n = null;
    for (a in o) if (!r.hasOwnProperty(a) && o.hasOwnProperty(a) && o[a] != null) if (a === "style") {
      var s = o[a];
      for (i in s) s.hasOwnProperty(i) && (n || (n = {}), n[i] = "");
    } else a !== "dangerouslySetInnerHTML" && a !== "children" && a !== "suppressContentEditableWarning" && a !== "suppressHydrationWarning" && a !== "autoFocus" && (cr.hasOwnProperty(a) ? l || (l = []) : (l = l || []).push(a, null));
    for (a in r) {
      var u = r[a];
      if (s = o != null ? o[a] : void 0, r.hasOwnProperty(a) && u !== s && (u != null || s != null)) if (a === "style") if (s) {
        for (i in s) !s.hasOwnProperty(i) || u && u.hasOwnProperty(i) || (n || (n = {}), n[i] = "");
        for (i in u) u.hasOwnProperty(i) && s[i] !== u[i] && (n || (n = {}), n[i] = u[i]);
      } else n || (l || (l = []), l.push(
        a,
        n
      )), n = u;
      else a === "dangerouslySetInnerHTML" ? (u = u ? u.__html : void 0, s = s ? s.__html : void 0, u != null && s !== u && (l = l || []).push(a, u)) : a === "children" ? typeof u != "string" && typeof u != "number" || (l = l || []).push(a, "" + u) : a !== "suppressContentEditableWarning" && a !== "suppressHydrationWarning" && (cr.hasOwnProperty(a) ? (u != null && a === "onScroll" && U("scroll", e), l || s === u || (l = [])) : (l = l || []).push(a, u));
    }
    n && (l = l || []).push("style", n);
    var a = l;
    (t.updateQueue = a) && (t.flags |= 4);
  }
};
ed = function(e, t, n, r) {
  n !== r && (t.flags |= 4);
};
function Hn(e, t) {
  if (!V) switch (e.tailMode) {
    case "hidden":
      t = e.tail;
      for (var n = null; t !== null; ) t.alternate !== null && (n = t), t = t.sibling;
      n === null ? e.tail = null : n.sibling = null;
      break;
    case "collapsed":
      n = e.tail;
      for (var r = null; n !== null; ) n.alternate !== null && (r = n), n = n.sibling;
      r === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : r.sibling = null;
  }
}
function pe(e) {
  var t = e.alternate !== null && e.alternate.child === e.child, n = 0, r = 0;
  if (t) for (var o = e.child; o !== null; ) n |= o.lanes | o.childLanes, r |= o.subtreeFlags & 14680064, r |= o.flags & 14680064, o.return = e, o = o.sibling;
  else for (o = e.child; o !== null; ) n |= o.lanes | o.childLanes, r |= o.subtreeFlags, r |= o.flags, o.return = e, o = o.sibling;
  return e.subtreeFlags |= r, e.childLanes = n, t;
}
function u0(e, t, n) {
  var r = t.pendingProps;
  switch (Ms(t), t.tag) {
    case 2:
    case 16:
    case 15:
    case 0:
    case 11:
    case 7:
    case 8:
    case 12:
    case 9:
    case 14:
      return pe(t), null;
    case 1:
      return Pe(t.type) && Oo(), pe(t), null;
    case 3:
      return r = t.stateNode, _n(), H(Ee), H(ye), bs(), r.pendingContext && (r.context = r.pendingContext, r.pendingContext = null), (e === null || e.child === null) && (Zr(t) ? t.flags |= 4 : e === null || e.memoizedState.isDehydrated && !(t.flags & 256) || (t.flags |= 1024, Ge !== null && (Ji(Ge), Ge = null))), Hi(e, t), pe(t), null;
    case 5:
      Bs(t);
      var o = Ht(Cr.current);
      if (n = t.type, e !== null && t.stateNode != null) qf(e, t, n, r, o), e.ref !== t.ref && (t.flags |= 512, t.flags |= 2097152);
      else {
        if (!r) {
          if (t.stateNode === null) throw Error(C(166));
          return pe(t), null;
        }
        if (e = Ht(ot.current), Zr(t)) {
          r = t.stateNode, n = t.type;
          var l = t.memoizedProps;
          switch (r[tt] = t, r[kr] = l, e = (t.mode & 1) !== 0, n) {
            case "dialog":
              U("cancel", r), U("close", r);
              break;
            case "iframe":
            case "object":
            case "embed":
              U("load", r);
              break;
            case "video":
            case "audio":
              for (o = 0; o < Kn.length; o++) U(Kn[o], r);
              break;
            case "source":
              U("error", r);
              break;
            case "img":
            case "image":
            case "link":
              U(
                "error",
                r
              ), U("load", r);
              break;
            case "details":
              U("toggle", r);
              break;
            case "input":
              Su(r, l), U("invalid", r);
              break;
            case "select":
              r._wrapperState = { wasMultiple: !!l.multiple }, U("invalid", r);
              break;
            case "textarea":
              xu(r, l), U("invalid", r);
          }
          yi(n, l), o = null;
          for (var i in l) if (l.hasOwnProperty(i)) {
            var s = l[i];
            i === "children" ? typeof s == "string" ? r.textContent !== s && (l.suppressHydrationWarning !== !0 && Xr(r.textContent, s, e), o = ["children", s]) : typeof s == "number" && r.textContent !== "" + s && (l.suppressHydrationWarning !== !0 && Xr(
              r.textContent,
              s,
              e
            ), o = ["children", "" + s]) : cr.hasOwnProperty(i) && s != null && i === "onScroll" && U("scroll", r);
          }
          switch (n) {
            case "input":
              Ur(r), Cu(r, l, !0);
              break;
            case "textarea":
              Ur(r), Eu(r);
              break;
            case "select":
            case "option":
              break;
            default:
              typeof l.onClick == "function" && (r.onclick = Mo);
          }
          r = o, t.updateQueue = r, r !== null && (t.flags |= 4);
        } else {
          i = o.nodeType === 9 ? o : o.ownerDocument, e === "http://www.w3.org/1999/xhtml" && (e = Nc(n)), e === "http://www.w3.org/1999/xhtml" ? n === "script" ? (e = i.createElement("div"), e.innerHTML = "<script><\/script>", e = e.removeChild(e.firstChild)) : typeof r.is == "string" ? e = i.createElement(n, { is: r.is }) : (e = i.createElement(n), n === "select" && (i = e, r.multiple ? i.multiple = !0 : r.size && (i.size = r.size))) : e = i.createElementNS(e, n), e[tt] = t, e[kr] = r, Jf(e, t, !1, !1), t.stateNode = e;
          e: {
            switch (i = vi(n, r), n) {
              case "dialog":
                U("cancel", e), U("close", e), o = r;
                break;
              case "iframe":
              case "object":
              case "embed":
                U("load", e), o = r;
                break;
              case "video":
              case "audio":
                for (o = 0; o < Kn.length; o++) U(Kn[o], e);
                o = r;
                break;
              case "source":
                U("error", e), o = r;
                break;
              case "img":
              case "image":
              case "link":
                U(
                  "error",
                  e
                ), U("load", e), o = r;
                break;
              case "details":
                U("toggle", e), o = r;
                break;
              case "input":
                Su(e, r), o = di(e, r), U("invalid", e);
                break;
              case "option":
                o = r;
                break;
              case "select":
                e._wrapperState = { wasMultiple: !!r.multiple }, o = Y({}, r, { value: void 0 }), U("invalid", e);
                break;
              case "textarea":
                xu(e, r), o = mi(e, r), U("invalid", e);
                break;
              default:
                o = r;
            }
            yi(n, o), s = o;
            for (l in s) if (s.hasOwnProperty(l)) {
              var u = s[l];
              l === "style" ? zc(e, u) : l === "dangerouslySetInnerHTML" ? (u = u ? u.__html : void 0, u != null && Tc(e, u)) : l === "children" ? typeof u == "string" ? (n !== "textarea" || u !== "") && fr(e, u) : typeof u == "number" && fr(e, "" + u) : l !== "suppressContentEditableWarning" && l !== "suppressHydrationWarning" && l !== "autoFocus" && (cr.hasOwnProperty(l) ? u != null && l === "onScroll" && U("scroll", e) : u != null && ys(e, l, u, i));
            }
            switch (n) {
              case "input":
                Ur(e), Cu(e, r, !1);
                break;
              case "textarea":
                Ur(e), Eu(e);
                break;
              case "option":
                r.value != null && e.setAttribute("value", "" + Mt(r.value));
                break;
              case "select":
                e.multiple = !!r.multiple, l = r.value, l != null ? mn(e, !!r.multiple, l, !1) : r.defaultValue != null && mn(
                  e,
                  !!r.multiple,
                  r.defaultValue,
                  !0
                );
                break;
              default:
                typeof o.onClick == "function" && (e.onclick = Mo);
            }
            switch (n) {
              case "button":
              case "input":
              case "select":
              case "textarea":
                r = !!r.autoFocus;
                break e;
              case "img":
                r = !0;
                break e;
              default:
                r = !1;
            }
          }
          r && (t.flags |= 4);
        }
        t.ref !== null && (t.flags |= 512, t.flags |= 2097152);
      }
      return pe(t), null;
    case 6:
      if (e && t.stateNode != null) ed(e, t, e.memoizedProps, r);
      else {
        if (typeof r != "string" && t.stateNode === null) throw Error(C(166));
        if (n = Ht(Cr.current), Ht(ot.current), Zr(t)) {
          if (r = t.stateNode, n = t.memoizedProps, r[tt] = t, (l = r.nodeValue !== n) && (e = Le, e !== null)) switch (e.tag) {
            case 3:
              Xr(r.nodeValue, n, (e.mode & 1) !== 0);
              break;
            case 5:
              e.memoizedProps.suppressHydrationWarning !== !0 && Xr(r.nodeValue, n, (e.mode & 1) !== 0);
          }
          l && (t.flags |= 4);
        } else r = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(r), r[tt] = t, t.stateNode = r;
      }
      return pe(t), null;
    case 13:
      if (H(Q), r = t.memoizedState, e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
        if (V && Re !== null && t.mode & 1 && !(t.flags & 128)) vf(), En(), t.flags |= 98560, l = !1;
        else if (l = Zr(t), r !== null && r.dehydrated !== null) {
          if (e === null) {
            if (!l) throw Error(C(318));
            if (l = t.memoizedState, l = l !== null ? l.dehydrated : null, !l) throw Error(C(317));
            l[tt] = t;
          } else En(), !(t.flags & 128) && (t.memoizedState = null), t.flags |= 4;
          pe(t), l = !1;
        } else Ge !== null && (Ji(Ge), Ge = null), l = !0;
        if (!l) return t.flags & 65536 ? t : null;
      }
      return t.flags & 128 ? (t.lanes = n, t) : (r = r !== null, r !== (e !== null && e.memoizedState !== null) && r && (t.child.flags |= 8192, t.mode & 1 && (e === null || Q.current & 1 ? ne === 0 && (ne = 3) : qs())), t.updateQueue !== null && (t.flags |= 4), pe(t), null);
    case 4:
      return _n(), Hi(e, t), e === null && vr(t.stateNode.containerInfo), pe(t), null;
    case 10:
      return Is(t.type._context), pe(t), null;
    case 17:
      return Pe(t.type) && Oo(), pe(t), null;
    case 19:
      if (H(Q), l = t.memoizedState, l === null) return pe(t), null;
      if (r = (t.flags & 128) !== 0, i = l.rendering, i === null) if (r) Hn(l, !1);
      else {
        if (ne !== 0 || e !== null && e.flags & 128) for (e = t.child; e !== null; ) {
          if (i = Bo(e), i !== null) {
            for (t.flags |= 128, Hn(l, !1), r = i.updateQueue, r !== null && (t.updateQueue = r, t.flags |= 4), t.subtreeFlags = 0, r = n, n = t.child; n !== null; ) l = n, e = r, l.flags &= 14680066, i = l.alternate, i === null ? (l.childLanes = 0, l.lanes = e, l.child = null, l.subtreeFlags = 0, l.memoizedProps = null, l.memoizedState = null, l.updateQueue = null, l.dependencies = null, l.stateNode = null) : (l.childLanes = i.childLanes, l.lanes = i.lanes, l.child = i.child, l.subtreeFlags = 0, l.deletions = null, l.memoizedProps = i.memoizedProps, l.memoizedState = i.memoizedState, l.updateQueue = i.updateQueue, l.type = i.type, e = i.dependencies, l.dependencies = e === null ? null : { lanes: e.lanes, firstContext: e.firstContext }), n = n.sibling;
            return b(Q, Q.current & 1 | 2), t.child;
          }
          e = e.sibling;
        }
        l.tail !== null && J() > Tn && (t.flags |= 128, r = !0, Hn(l, !1), t.lanes = 4194304);
      }
      else {
        if (!r) if (e = Bo(i), e !== null) {
          if (t.flags |= 128, r = !0, n = e.updateQueue, n !== null && (t.updateQueue = n, t.flags |= 4), Hn(l, !0), l.tail === null && l.tailMode === "hidden" && !i.alternate && !V) return pe(t), null;
        } else 2 * J() - l.renderingStartTime > Tn && n !== 1073741824 && (t.flags |= 128, r = !0, Hn(l, !1), t.lanes = 4194304);
        l.isBackwards ? (i.sibling = t.child, t.child = i) : (n = l.last, n !== null ? n.sibling = i : t.child = i, l.last = i);
      }
      return l.tail !== null ? (t = l.tail, l.rendering = t, l.tail = t.sibling, l.renderingStartTime = J(), t.sibling = null, n = Q.current, b(Q, r ? n & 1 | 2 : n & 1), t) : (pe(t), null);
    case 22:
    case 23:
      return Js(), r = t.memoizedState !== null, e !== null && e.memoizedState !== null !== r && (t.flags |= 8192), r && t.mode & 1 ? Te & 1073741824 && (pe(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : pe(t), null;
    case 24:
      return null;
    case 25:
      return null;
  }
  throw Error(C(156, t.tag));
}
function a0(e, t) {
  switch (Ms(t), t.tag) {
    case 1:
      return Pe(t.type) && Oo(), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
    case 3:
      return _n(), H(Ee), H(ye), bs(), e = t.flags, e & 65536 && !(e & 128) ? (t.flags = e & -65537 | 128, t) : null;
    case 5:
      return Bs(t), null;
    case 13:
      if (H(Q), e = t.memoizedState, e !== null && e.dehydrated !== null) {
        if (t.alternate === null) throw Error(C(340));
        En();
      }
      return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
    case 19:
      return H(Q), null;
    case 4:
      return _n(), null;
    case 10:
      return Is(t.type._context), null;
    case 22:
    case 23:
      return Js(), null;
    case 24:
      return null;
    default:
      return null;
  }
}
var eo = !1, me = !1, c0 = typeof WeakSet == "function" ? WeakSet : Set, _ = null;
function dn(e, t) {
  var n = e.ref;
  if (n !== null) if (typeof n == "function") try {
    n(null);
  } catch (r) {
    K(e, t, r);
  }
  else n.current = null;
}
function Vi(e, t, n) {
  try {
    n();
  } catch (r) {
    K(e, t, r);
  }
}
var pa = !1;
function f0(e, t) {
  if (Ti = Ro, e = of(), zs(e)) {
    if ("selectionStart" in e) var n = { start: e.selectionStart, end: e.selectionEnd };
    else e: {
      n = (n = e.ownerDocument) && n.defaultView || window;
      var r = n.getSelection && n.getSelection();
      if (r && r.rangeCount !== 0) {
        n = r.anchorNode;
        var o = r.anchorOffset, l = r.focusNode;
        r = r.focusOffset;
        try {
          n.nodeType, l.nodeType;
        } catch {
          n = null;
          break e;
        }
        var i = 0, s = -1, u = -1, a = 0, d = 0, p = e, h = null;
        t: for (; ; ) {
          for (var g; p !== n || o !== 0 && p.nodeType !== 3 || (s = i + o), p !== l || r !== 0 && p.nodeType !== 3 || (u = i + r), p.nodeType === 3 && (i += p.nodeValue.length), (g = p.firstChild) !== null; )
            h = p, p = g;
          for (; ; ) {
            if (p === e) break t;
            if (h === n && ++a === o && (s = i), h === l && ++d === r && (u = i), (g = p.nextSibling) !== null) break;
            p = h, h = p.parentNode;
          }
          p = g;
        }
        n = s === -1 || u === -1 ? null : { start: s, end: u };
      } else n = null;
    }
    n = n || { start: 0, end: 0 };
  } else n = null;
  for (Ri = { focusedElem: e, selectionRange: n }, Ro = !1, _ = t; _ !== null; ) if (t = _, e = t.child, (t.subtreeFlags & 1028) !== 0 && e !== null) e.return = t, _ = e;
  else for (; _ !== null; ) {
    t = _;
    try {
      var v = t.alternate;
      if (t.flags & 1024) switch (t.tag) {
        case 0:
        case 11:
        case 15:
          break;
        case 1:
          if (v !== null) {
            var w = v.memoizedProps, R = v.memoizedState, f = t.stateNode, c = f.getSnapshotBeforeUpdate(t.elementType === t.type ? w : Ve(t.type, w), R);
            f.__reactInternalSnapshotBeforeUpdate = c;
          }
          break;
        case 3:
          var m = t.stateNode.containerInfo;
          m.nodeType === 1 ? m.textContent = "" : m.nodeType === 9 && m.documentElement && m.removeChild(m.documentElement);
          break;
        case 5:
        case 6:
        case 4:
        case 17:
          break;
        default:
          throw Error(C(163));
      }
    } catch (S) {
      K(t, t.return, S);
    }
    if (e = t.sibling, e !== null) {
      e.return = t.return, _ = e;
      break;
    }
    _ = t.return;
  }
  return v = pa, pa = !1, v;
}
function rr(e, t, n) {
  var r = t.updateQueue;
  if (r = r !== null ? r.lastEffect : null, r !== null) {
    var o = r = r.next;
    do {
      if ((o.tag & e) === e) {
        var l = o.destroy;
        o.destroy = void 0, l !== void 0 && Vi(t, n, l);
      }
      o = o.next;
    } while (o !== r);
  }
}
function wl(e, t) {
  if (t = t.updateQueue, t = t !== null ? t.lastEffect : null, t !== null) {
    var n = t = t.next;
    do {
      if ((n.tag & e) === e) {
        var r = n.create;
        n.destroy = r();
      }
      n = n.next;
    } while (n !== t);
  }
}
function Qi(e) {
  var t = e.ref;
  if (t !== null) {
    var n = e.stateNode;
    switch (e.tag) {
      case 5:
        e = n;
        break;
      default:
        e = n;
    }
    typeof t == "function" ? t(e) : t.current = e;
  }
}
function td(e) {
  var t = e.alternate;
  t !== null && (e.alternate = null, td(t)), e.child = null, e.deletions = null, e.sibling = null, e.tag === 5 && (t = e.stateNode, t !== null && (delete t[tt], delete t[kr], delete t[Mi], delete t[Gm], delete t[Ym])), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null;
}
function nd(e) {
  return e.tag === 5 || e.tag === 3 || e.tag === 4;
}
function ha(e) {
  e: for (; ; ) {
    for (; e.sibling === null; ) {
      if (e.return === null || nd(e.return)) return null;
      e = e.return;
    }
    for (e.sibling.return = e.return, e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 18; ) {
      if (e.flags & 2 || e.child === null || e.tag === 4) continue e;
      e.child.return = e, e = e.child;
    }
    if (!(e.flags & 2)) return e.stateNode;
  }
}
function Gi(e, t, n) {
  var r = e.tag;
  if (r === 5 || r === 6) e = e.stateNode, t ? n.nodeType === 8 ? n.parentNode.insertBefore(e, t) : n.insertBefore(e, t) : (n.nodeType === 8 ? (t = n.parentNode, t.insertBefore(e, n)) : (t = n, t.appendChild(e)), n = n._reactRootContainer, n != null || t.onclick !== null || (t.onclick = Mo));
  else if (r !== 4 && (e = e.child, e !== null)) for (Gi(e, t, n), e = e.sibling; e !== null; ) Gi(e, t, n), e = e.sibling;
}
function Yi(e, t, n) {
  var r = e.tag;
  if (r === 5 || r === 6) e = e.stateNode, t ? n.insertBefore(e, t) : n.appendChild(e);
  else if (r !== 4 && (e = e.child, e !== null)) for (Yi(e, t, n), e = e.sibling; e !== null; ) Yi(e, t, n), e = e.sibling;
}
var ue = null, Qe = !1;
function yt(e, t, n) {
  for (n = n.child; n !== null; ) rd(e, t, n), n = n.sibling;
}
function rd(e, t, n) {
  if (rt && typeof rt.onCommitFiberUnmount == "function") try {
    rt.onCommitFiberUnmount(fl, n);
  } catch {
  }
  switch (n.tag) {
    case 5:
      me || dn(n, t);
    case 6:
      var r = ue, o = Qe;
      ue = null, yt(e, t, n), ue = r, Qe = o, ue !== null && (Qe ? (e = ue, n = n.stateNode, e.nodeType === 8 ? e.parentNode.removeChild(n) : e.removeChild(n)) : ue.removeChild(n.stateNode));
      break;
    case 18:
      ue !== null && (Qe ? (e = ue, n = n.stateNode, e.nodeType === 8 ? Ql(e.parentNode, n) : e.nodeType === 1 && Ql(e, n), mr(e)) : Ql(ue, n.stateNode));
      break;
    case 4:
      r = ue, o = Qe, ue = n.stateNode.containerInfo, Qe = !0, yt(e, t, n), ue = r, Qe = o;
      break;
    case 0:
    case 11:
    case 14:
    case 15:
      if (!me && (r = n.updateQueue, r !== null && (r = r.lastEffect, r !== null))) {
        o = r = r.next;
        do {
          var l = o, i = l.destroy;
          l = l.tag, i !== void 0 && (l & 2 || l & 4) && Vi(n, t, i), o = o.next;
        } while (o !== r);
      }
      yt(e, t, n);
      break;
    case 1:
      if (!me && (dn(n, t), r = n.stateNode, typeof r.componentWillUnmount == "function")) try {
        r.props = n.memoizedProps, r.state = n.memoizedState, r.componentWillUnmount();
      } catch (s) {
        K(n, t, s);
      }
      yt(e, t, n);
      break;
    case 21:
      yt(e, t, n);
      break;
    case 22:
      n.mode & 1 ? (me = (r = me) || n.memoizedState !== null, yt(e, t, n), me = r) : yt(e, t, n);
      break;
    default:
      yt(e, t, n);
  }
}
function ma(e) {
  var t = e.updateQueue;
  if (t !== null) {
    e.updateQueue = null;
    var n = e.stateNode;
    n === null && (n = e.stateNode = new c0()), t.forEach(function(r) {
      var o = k0.bind(null, e, r);
      n.has(r) || (n.add(r), r.then(o, o));
    });
  }
}
function We(e, t) {
  var n = t.deletions;
  if (n !== null) for (var r = 0; r < n.length; r++) {
    var o = n[r];
    try {
      var l = e, i = t, s = i;
      e: for (; s !== null; ) {
        switch (s.tag) {
          case 5:
            ue = s.stateNode, Qe = !1;
            break e;
          case 3:
            ue = s.stateNode.containerInfo, Qe = !0;
            break e;
          case 4:
            ue = s.stateNode.containerInfo, Qe = !0;
            break e;
        }
        s = s.return;
      }
      if (ue === null) throw Error(C(160));
      rd(l, i, o), ue = null, Qe = !1;
      var u = o.alternate;
      u !== null && (u.return = null), o.return = null;
    } catch (a) {
      K(o, t, a);
    }
  }
  if (t.subtreeFlags & 12854) for (t = t.child; t !== null; ) od(t, e), t = t.sibling;
}
function od(e, t) {
  var n = e.alternate, r = e.flags;
  switch (e.tag) {
    case 0:
    case 11:
    case 14:
    case 15:
      if (We(t, e), Ze(e), r & 4) {
        try {
          rr(3, e, e.return), wl(3, e);
        } catch (w) {
          K(e, e.return, w);
        }
        try {
          rr(5, e, e.return);
        } catch (w) {
          K(e, e.return, w);
        }
      }
      break;
    case 1:
      We(t, e), Ze(e), r & 512 && n !== null && dn(n, n.return);
      break;
    case 5:
      if (We(t, e), Ze(e), r & 512 && n !== null && dn(n, n.return), e.flags & 32) {
        var o = e.stateNode;
        try {
          fr(o, "");
        } catch (w) {
          K(e, e.return, w);
        }
      }
      if (r & 4 && (o = e.stateNode, o != null)) {
        var l = e.memoizedProps, i = n !== null ? n.memoizedProps : l, s = e.type, u = e.updateQueue;
        if (e.updateQueue = null, u !== null) try {
          s === "input" && l.type === "radio" && l.name != null && Pc(o, l), vi(s, i);
          var a = vi(s, l);
          for (i = 0; i < u.length; i += 2) {
            var d = u[i], p = u[i + 1];
            d === "style" ? zc(o, p) : d === "dangerouslySetInnerHTML" ? Tc(o, p) : d === "children" ? fr(o, p) : ys(o, d, p, a);
          }
          switch (s) {
            case "input":
              pi(o, l);
              break;
            case "textarea":
              _c(o, l);
              break;
            case "select":
              var h = o._wrapperState.wasMultiple;
              o._wrapperState.wasMultiple = !!l.multiple;
              var g = l.value;
              g != null ? mn(o, !!l.multiple, g, !1) : h !== !!l.multiple && (l.defaultValue != null ? mn(
                o,
                !!l.multiple,
                l.defaultValue,
                !0
              ) : mn(o, !!l.multiple, l.multiple ? [] : "", !1));
          }
          o[kr] = l;
        } catch (w) {
          K(e, e.return, w);
        }
      }
      break;
    case 6:
      if (We(t, e), Ze(e), r & 4) {
        if (e.stateNode === null) throw Error(C(162));
        o = e.stateNode, l = e.memoizedProps;
        try {
          o.nodeValue = l;
        } catch (w) {
          K(e, e.return, w);
        }
      }
      break;
    case 3:
      if (We(t, e), Ze(e), r & 4 && n !== null && n.memoizedState.isDehydrated) try {
        mr(t.containerInfo);
      } catch (w) {
        K(e, e.return, w);
      }
      break;
    case 4:
      We(t, e), Ze(e);
      break;
    case 13:
      We(t, e), Ze(e), o = e.child, o.flags & 8192 && (l = o.memoizedState !== null, o.stateNode.isHidden = l, !l || o.alternate !== null && o.alternate.memoizedState !== null || (Xs = J())), r & 4 && ma(e);
      break;
    case 22:
      if (d = n !== null && n.memoizedState !== null, e.mode & 1 ? (me = (a = me) || d, We(t, e), me = a) : We(t, e), Ze(e), r & 8192) {
        if (a = e.memoizedState !== null, (e.stateNode.isHidden = a) && !d && e.mode & 1) for (_ = e, d = e.child; d !== null; ) {
          for (p = _ = d; _ !== null; ) {
            switch (h = _, g = h.child, h.tag) {
              case 0:
              case 11:
              case 14:
              case 15:
                rr(4, h, h.return);
                break;
              case 1:
                dn(h, h.return);
                var v = h.stateNode;
                if (typeof v.componentWillUnmount == "function") {
                  r = h, n = h.return;
                  try {
                    t = r, v.props = t.memoizedProps, v.state = t.memoizedState, v.componentWillUnmount();
                  } catch (w) {
                    K(r, n, w);
                  }
                }
                break;
              case 5:
                dn(h, h.return);
                break;
              case 22:
                if (h.memoizedState !== null) {
                  ya(p);
                  continue;
                }
            }
            g !== null ? (g.return = h, _ = g) : ya(p);
          }
          d = d.sibling;
        }
        e: for (d = null, p = e; ; ) {
          if (p.tag === 5) {
            if (d === null) {
              d = p;
              try {
                o = p.stateNode, a ? (l = o.style, typeof l.setProperty == "function" ? l.setProperty("display", "none", "important") : l.display = "none") : (s = p.stateNode, u = p.memoizedProps.style, i = u != null && u.hasOwnProperty("display") ? u.display : null, s.style.display = Rc("display", i));
              } catch (w) {
                K(e, e.return, w);
              }
            }
          } else if (p.tag === 6) {
            if (d === null) try {
              p.stateNode.nodeValue = a ? "" : p.memoizedProps;
            } catch (w) {
              K(e, e.return, w);
            }
          } else if ((p.tag !== 22 && p.tag !== 23 || p.memoizedState === null || p === e) && p.child !== null) {
            p.child.return = p, p = p.child;
            continue;
          }
          if (p === e) break e;
          for (; p.sibling === null; ) {
            if (p.return === null || p.return === e) break e;
            d === p && (d = null), p = p.return;
          }
          d === p && (d = null), p.sibling.return = p.return, p = p.sibling;
        }
      }
      break;
    case 19:
      We(t, e), Ze(e), r & 4 && ma(e);
      break;
    case 21:
      break;
    default:
      We(
        t,
        e
      ), Ze(e);
  }
}
function Ze(e) {
  var t = e.flags;
  if (t & 2) {
    try {
      e: {
        for (var n = e.return; n !== null; ) {
          if (nd(n)) {
            var r = n;
            break e;
          }
          n = n.return;
        }
        throw Error(C(160));
      }
      switch (r.tag) {
        case 5:
          var o = r.stateNode;
          r.flags & 32 && (fr(o, ""), r.flags &= -33);
          var l = ha(e);
          Yi(e, l, o);
          break;
        case 3:
        case 4:
          var i = r.stateNode.containerInfo, s = ha(e);
          Gi(e, s, i);
          break;
        default:
          throw Error(C(161));
      }
    } catch (u) {
      K(e, e.return, u);
    }
    e.flags &= -3;
  }
  t & 4096 && (e.flags &= -4097);
}
function d0(e, t, n) {
  _ = e, ld(e);
}
function ld(e, t, n) {
  for (var r = (e.mode & 1) !== 0; _ !== null; ) {
    var o = _, l = o.child;
    if (o.tag === 22 && r) {
      var i = o.memoizedState !== null || eo;
      if (!i) {
        var s = o.alternate, u = s !== null && s.memoizedState !== null || me;
        s = eo;
        var a = me;
        if (eo = i, (me = u) && !a) for (_ = o; _ !== null; ) i = _, u = i.child, i.tag === 22 && i.memoizedState !== null ? va(o) : u !== null ? (u.return = i, _ = u) : va(o);
        for (; l !== null; ) _ = l, ld(l), l = l.sibling;
        _ = o, eo = s, me = a;
      }
      ga(e);
    } else o.subtreeFlags & 8772 && l !== null ? (l.return = o, _ = l) : ga(e);
  }
}
function ga(e) {
  for (; _ !== null; ) {
    var t = _;
    if (t.flags & 8772) {
      var n = t.alternate;
      try {
        if (t.flags & 8772) switch (t.tag) {
          case 0:
          case 11:
          case 15:
            me || wl(5, t);
            break;
          case 1:
            var r = t.stateNode;
            if (t.flags & 4 && !me) if (n === null) r.componentDidMount();
            else {
              var o = t.elementType === t.type ? n.memoizedProps : Ve(t.type, n.memoizedProps);
              r.componentDidUpdate(o, n.memoizedState, r.__reactInternalSnapshotBeforeUpdate);
            }
            var l = t.updateQueue;
            l !== null && ea(t, l, r);
            break;
          case 3:
            var i = t.updateQueue;
            if (i !== null) {
              if (n = null, t.child !== null) switch (t.child.tag) {
                case 5:
                  n = t.child.stateNode;
                  break;
                case 1:
                  n = t.child.stateNode;
              }
              ea(t, i, n);
            }
            break;
          case 5:
            var s = t.stateNode;
            if (n === null && t.flags & 4) {
              n = s;
              var u = t.memoizedProps;
              switch (t.type) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                  u.autoFocus && n.focus();
                  break;
                case "img":
                  u.src && (n.src = u.src);
              }
            }
            break;
          case 6:
            break;
          case 4:
            break;
          case 12:
            break;
          case 13:
            if (t.memoizedState === null) {
              var a = t.alternate;
              if (a !== null) {
                var d = a.memoizedState;
                if (d !== null) {
                  var p = d.dehydrated;
                  p !== null && mr(p);
                }
              }
            }
            break;
          case 19:
          case 17:
          case 21:
          case 22:
          case 23:
          case 25:
            break;
          default:
            throw Error(C(163));
        }
        me || t.flags & 512 && Qi(t);
      } catch (h) {
        K(t, t.return, h);
      }
    }
    if (t === e) {
      _ = null;
      break;
    }
    if (n = t.sibling, n !== null) {
      n.return = t.return, _ = n;
      break;
    }
    _ = t.return;
  }
}
function ya(e) {
  for (; _ !== null; ) {
    var t = _;
    if (t === e) {
      _ = null;
      break;
    }
    var n = t.sibling;
    if (n !== null) {
      n.return = t.return, _ = n;
      break;
    }
    _ = t.return;
  }
}
function va(e) {
  for (; _ !== null; ) {
    var t = _;
    try {
      switch (t.tag) {
        case 0:
        case 11:
        case 15:
          var n = t.return;
          try {
            wl(4, t);
          } catch (u) {
            K(t, n, u);
          }
          break;
        case 1:
          var r = t.stateNode;
          if (typeof r.componentDidMount == "function") {
            var o = t.return;
            try {
              r.componentDidMount();
            } catch (u) {
              K(t, o, u);
            }
          }
          var l = t.return;
          try {
            Qi(t);
          } catch (u) {
            K(t, l, u);
          }
          break;
        case 5:
          var i = t.return;
          try {
            Qi(t);
          } catch (u) {
            K(t, i, u);
          }
      }
    } catch (u) {
      K(t, t.return, u);
    }
    if (t === e) {
      _ = null;
      break;
    }
    var s = t.sibling;
    if (s !== null) {
      s.return = t.return, _ = s;
      break;
    }
    _ = t.return;
  }
}
var p0 = Math.ceil, Wo = gt.ReactCurrentDispatcher, Ys = gt.ReactCurrentOwner, je = gt.ReactCurrentBatchConfig, I = 0, ie = null, ee = null, ce = 0, Te = 0, pn = Dt(0), ne = 0, _r = null, Xt = 0, kl = 0, Ks = 0, or = null, Ce = null, Xs = 0, Tn = 1 / 0, lt = null, Ho = !1, Ki = null, Rt = null, to = !1, xt = null, Vo = 0, lr = 0, Xi = null, wo = -1, ko = 0;
function we() {
  return I & 6 ? J() : wo !== -1 ? wo : wo = J();
}
function zt(e) {
  return e.mode & 1 ? I & 2 && ce !== 0 ? ce & -ce : Xm.transition !== null ? (ko === 0 && (ko = Uc()), ko) : (e = j, e !== 0 || (e = window.event, e = e === void 0 ? 16 : Kc(e.type)), e) : 1;
}
function Ke(e, t, n, r) {
  if (50 < lr) throw lr = 0, Xi = null, Error(C(185));
  zr(e, n, r), (!(I & 2) || e !== ie) && (e === ie && (!(I & 2) && (kl |= n), ne === 4 && St(e, ce)), _e(e, r), n === 1 && I === 0 && !(t.mode & 1) && (Tn = J() + 500, gl && It()));
}
function _e(e, t) {
  var n = e.callbackNode;
  Xh(e, t);
  var r = To(e, e === ie ? ce : 0);
  if (r === 0) n !== null && Nu(n), e.callbackNode = null, e.callbackPriority = 0;
  else if (t = r & -r, e.callbackPriority !== t) {
    if (n != null && Nu(n), t === 1) e.tag === 0 ? Km(wa.bind(null, e)) : mf(wa.bind(null, e)), Vm(function() {
      !(I & 6) && It();
    }), n = null;
    else {
      switch (Wc(r)) {
        case 1:
          n = Cs;
          break;
        case 4:
          n = Bc;
          break;
        case 16:
          n = No;
          break;
        case 536870912:
          n = bc;
          break;
        default:
          n = No;
      }
      n = pd(n, id.bind(null, e));
    }
    e.callbackPriority = t, e.callbackNode = n;
  }
}
function id(e, t) {
  if (wo = -1, ko = 0, I & 6) throw Error(C(327));
  var n = e.callbackNode;
  if (kn() && e.callbackNode !== n) return null;
  var r = To(e, e === ie ? ce : 0);
  if (r === 0) return null;
  if (r & 30 || r & e.expiredLanes || t) t = Qo(e, r);
  else {
    t = r;
    var o = I;
    I |= 2;
    var l = ud();
    (ie !== e || ce !== t) && (lt = null, Tn = J() + 500, Vt(e, t));
    do
      try {
        g0();
        break;
      } catch (s) {
        sd(e, s);
      }
    while (!0);
    Ds(), Wo.current = l, I = o, ee !== null ? t = 0 : (ie = null, ce = 0, t = ne);
  }
  if (t !== 0) {
    if (t === 2 && (o = xi(e), o !== 0 && (r = o, t = Zi(e, o))), t === 1) throw n = _r, Vt(e, 0), St(e, r), _e(e, J()), n;
    if (t === 6) St(e, r);
    else {
      if (o = e.current.alternate, !(r & 30) && !h0(o) && (t = Qo(e, r), t === 2 && (l = xi(e), l !== 0 && (r = l, t = Zi(e, l))), t === 1)) throw n = _r, Vt(e, 0), St(e, r), _e(e, J()), n;
      switch (e.finishedWork = o, e.finishedLanes = r, t) {
        case 0:
        case 1:
          throw Error(C(345));
        case 2:
          bt(e, Ce, lt);
          break;
        case 3:
          if (St(e, r), (r & 130023424) === r && (t = Xs + 500 - J(), 10 < t)) {
            if (To(e, 0) !== 0) break;
            if (o = e.suspendedLanes, (o & r) !== r) {
              we(), e.pingedLanes |= e.suspendedLanes & o;
              break;
            }
            e.timeoutHandle = Li(bt.bind(null, e, Ce, lt), t);
            break;
          }
          bt(e, Ce, lt);
          break;
        case 4:
          if (St(e, r), (r & 4194240) === r) break;
          for (t = e.eventTimes, o = -1; 0 < r; ) {
            var i = 31 - Ye(r);
            l = 1 << i, i = t[i], i > o && (o = i), r &= ~l;
          }
          if (r = o, r = J() - r, r = (120 > r ? 120 : 480 > r ? 480 : 1080 > r ? 1080 : 1920 > r ? 1920 : 3e3 > r ? 3e3 : 4320 > r ? 4320 : 1960 * p0(r / 1960)) - r, 10 < r) {
            e.timeoutHandle = Li(bt.bind(null, e, Ce, lt), r);
            break;
          }
          bt(e, Ce, lt);
          break;
        case 5:
          bt(e, Ce, lt);
          break;
        default:
          throw Error(C(329));
      }
    }
  }
  return _e(e, J()), e.callbackNode === n ? id.bind(null, e) : null;
}
function Zi(e, t) {
  var n = or;
  return e.current.memoizedState.isDehydrated && (Vt(e, t).flags |= 256), e = Qo(e, t), e !== 2 && (t = Ce, Ce = n, t !== null && Ji(t)), e;
}
function Ji(e) {
  Ce === null ? Ce = e : Ce.push.apply(Ce, e);
}
function h0(e) {
  for (var t = e; ; ) {
    if (t.flags & 16384) {
      var n = t.updateQueue;
      if (n !== null && (n = n.stores, n !== null)) for (var r = 0; r < n.length; r++) {
        var o = n[r], l = o.getSnapshot;
        o = o.value;
        try {
          if (!Xe(l(), o)) return !1;
        } catch {
          return !1;
        }
      }
    }
    if (n = t.child, t.subtreeFlags & 16384 && n !== null) n.return = t, t = n;
    else {
      if (t === e) break;
      for (; t.sibling === null; ) {
        if (t.return === null || t.return === e) return !0;
        t = t.return;
      }
      t.sibling.return = t.return, t = t.sibling;
    }
  }
  return !0;
}
function St(e, t) {
  for (t &= ~Ks, t &= ~kl, e.suspendedLanes |= t, e.pingedLanes &= ~t, e = e.expirationTimes; 0 < t; ) {
    var n = 31 - Ye(t), r = 1 << n;
    e[n] = -1, t &= ~r;
  }
}
function wa(e) {
  if (I & 6) throw Error(C(327));
  kn();
  var t = To(e, 0);
  if (!(t & 1)) return _e(e, J()), null;
  var n = Qo(e, t);
  if (e.tag !== 0 && n === 2) {
    var r = xi(e);
    r !== 0 && (t = r, n = Zi(e, r));
  }
  if (n === 1) throw n = _r, Vt(e, 0), St(e, t), _e(e, J()), n;
  if (n === 6) throw Error(C(345));
  return e.finishedWork = e.current.alternate, e.finishedLanes = t, bt(e, Ce, lt), _e(e, J()), null;
}
function Zs(e, t) {
  var n = I;
  I |= 1;
  try {
    return e(t);
  } finally {
    I = n, I === 0 && (Tn = J() + 500, gl && It());
  }
}
function Zt(e) {
  xt !== null && xt.tag === 0 && !(I & 6) && kn();
  var t = I;
  I |= 1;
  var n = je.transition, r = j;
  try {
    if (je.transition = null, j = 1, e) return e();
  } finally {
    j = r, je.transition = n, I = t, !(I & 6) && It();
  }
}
function Js() {
  Te = pn.current, H(pn);
}
function Vt(e, t) {
  e.finishedWork = null, e.finishedLanes = 0;
  var n = e.timeoutHandle;
  if (n !== -1 && (e.timeoutHandle = -1, Hm(n)), ee !== null) for (n = ee.return; n !== null; ) {
    var r = n;
    switch (Ms(r), r.tag) {
      case 1:
        r = r.type.childContextTypes, r != null && Oo();
        break;
      case 3:
        _n(), H(Ee), H(ye), bs();
        break;
      case 5:
        Bs(r);
        break;
      case 4:
        _n();
        break;
      case 13:
        H(Q);
        break;
      case 19:
        H(Q);
        break;
      case 10:
        Is(r.type._context);
        break;
      case 22:
      case 23:
        Js();
    }
    n = n.return;
  }
  if (ie = e, ee = e = Lt(e.current, null), ce = Te = t, ne = 0, _r = null, Ks = kl = Xt = 0, Ce = or = null, Wt !== null) {
    for (t = 0; t < Wt.length; t++) if (n = Wt[t], r = n.interleaved, r !== null) {
      n.interleaved = null;
      var o = r.next, l = n.pending;
      if (l !== null) {
        var i = l.next;
        l.next = o, r.next = i;
      }
      n.pending = r;
    }
    Wt = null;
  }
  return e;
}
function sd(e, t) {
  do {
    var n = ee;
    try {
      if (Ds(), go.current = Uo, bo) {
        for (var r = G.memoizedState; r !== null; ) {
          var o = r.queue;
          o !== null && (o.pending = null), r = r.next;
        }
        bo = !1;
      }
      if (Kt = 0, le = te = G = null, nr = !1, xr = 0, Ys.current = null, n === null || n.return === null) {
        ne = 1, _r = t, ee = null;
        break;
      }
      e: {
        var l = e, i = n.return, s = n, u = t;
        if (t = ce, s.flags |= 32768, u !== null && typeof u == "object" && typeof u.then == "function") {
          var a = u, d = s, p = d.tag;
          if (!(d.mode & 1) && (p === 0 || p === 11 || p === 15)) {
            var h = d.alternate;
            h ? (d.updateQueue = h.updateQueue, d.memoizedState = h.memoizedState, d.lanes = h.lanes) : (d.updateQueue = null, d.memoizedState = null);
          }
          var g = ia(i);
          if (g !== null) {
            g.flags &= -257, sa(g, i, s, l, t), g.mode & 1 && la(l, a, t), t = g, u = a;
            var v = t.updateQueue;
            if (v === null) {
              var w = /* @__PURE__ */ new Set();
              w.add(u), t.updateQueue = w;
            } else v.add(u);
            break e;
          } else {
            if (!(t & 1)) {
              la(l, a, t), qs();
              break e;
            }
            u = Error(C(426));
          }
        } else if (V && s.mode & 1) {
          var R = ia(i);
          if (R !== null) {
            !(R.flags & 65536) && (R.flags |= 256), sa(R, i, s, l, t), Os(Nn(u, s));
            break e;
          }
        }
        l = u = Nn(u, s), ne !== 4 && (ne = 2), or === null ? or = [l] : or.push(l), l = i;
        do {
          switch (l.tag) {
            case 3:
              l.flags |= 65536, t &= -t, l.lanes |= t;
              var f = Hf(l, u, t);
              qu(l, f);
              break e;
            case 1:
              s = u;
              var c = l.type, m = l.stateNode;
              if (!(l.flags & 128) && (typeof c.getDerivedStateFromError == "function" || m !== null && typeof m.componentDidCatch == "function" && (Rt === null || !Rt.has(m)))) {
                l.flags |= 65536, t &= -t, l.lanes |= t;
                var S = Vf(l, s, t);
                qu(l, S);
                break e;
              }
          }
          l = l.return;
        } while (l !== null);
      }
      cd(n);
    } catch (E) {
      t = E, ee === n && n !== null && (ee = n = n.return);
      continue;
    }
    break;
  } while (!0);
}
function ud() {
  var e = Wo.current;
  return Wo.current = Uo, e === null ? Uo : e;
}
function qs() {
  (ne === 0 || ne === 3 || ne === 2) && (ne = 4), ie === null || !(Xt & 268435455) && !(kl & 268435455) || St(ie, ce);
}
function Qo(e, t) {
  var n = I;
  I |= 2;
  var r = ud();
  (ie !== e || ce !== t) && (lt = null, Vt(e, t));
  do
    try {
      m0();
      break;
    } catch (o) {
      sd(e, o);
    }
  while (!0);
  if (Ds(), I = n, Wo.current = r, ee !== null) throw Error(C(261));
  return ie = null, ce = 0, ne;
}
function m0() {
  for (; ee !== null; ) ad(ee);
}
function g0() {
  for (; ee !== null && !bh(); ) ad(ee);
}
function ad(e) {
  var t = dd(e.alternate, e, Te);
  e.memoizedProps = e.pendingProps, t === null ? cd(e) : ee = t, Ys.current = null;
}
function cd(e) {
  var t = e;
  do {
    var n = t.alternate;
    if (e = t.return, t.flags & 32768) {
      if (n = a0(n, t), n !== null) {
        n.flags &= 32767, ee = n;
        return;
      }
      if (e !== null) e.flags |= 32768, e.subtreeFlags = 0, e.deletions = null;
      else {
        ne = 6, ee = null;
        return;
      }
    } else if (n = u0(n, t, Te), n !== null) {
      ee = n;
      return;
    }
    if (t = t.sibling, t !== null) {
      ee = t;
      return;
    }
    ee = t = e;
  } while (t !== null);
  ne === 0 && (ne = 5);
}
function bt(e, t, n) {
  var r = j, o = je.transition;
  try {
    je.transition = null, j = 1, y0(e, t, n, r);
  } finally {
    je.transition = o, j = r;
  }
  return null;
}
function y0(e, t, n, r) {
  do
    kn();
  while (xt !== null);
  if (I & 6) throw Error(C(327));
  n = e.finishedWork;
  var o = e.finishedLanes;
  if (n === null) return null;
  if (e.finishedWork = null, e.finishedLanes = 0, n === e.current) throw Error(C(177));
  e.callbackNode = null, e.callbackPriority = 0;
  var l = n.lanes | n.childLanes;
  if (Zh(e, l), e === ie && (ee = ie = null, ce = 0), !(n.subtreeFlags & 2064) && !(n.flags & 2064) || to || (to = !0, pd(No, function() {
    return kn(), null;
  })), l = (n.flags & 15990) !== 0, n.subtreeFlags & 15990 || l) {
    l = je.transition, je.transition = null;
    var i = j;
    j = 1;
    var s = I;
    I |= 4, Ys.current = null, f0(e, n), od(n, e), Fm(Ri), Ro = !!Ti, Ri = Ti = null, e.current = n, d0(n), Uh(), I = s, j = i, je.transition = l;
  } else e.current = n;
  if (to && (to = !1, xt = e, Vo = o), l = e.pendingLanes, l === 0 && (Rt = null), Vh(n.stateNode), _e(e, J()), t !== null) for (r = e.onRecoverableError, n = 0; n < t.length; n++) o = t[n], r(o.value, { componentStack: o.stack, digest: o.digest });
  if (Ho) throw Ho = !1, e = Ki, Ki = null, e;
  return Vo & 1 && e.tag !== 0 && kn(), l = e.pendingLanes, l & 1 ? e === Xi ? lr++ : (lr = 0, Xi = e) : lr = 0, It(), null;
}
function kn() {
  if (xt !== null) {
    var e = Wc(Vo), t = je.transition, n = j;
    try {
      if (je.transition = null, j = 16 > e ? 16 : e, xt === null) var r = !1;
      else {
        if (e = xt, xt = null, Vo = 0, I & 6) throw Error(C(331));
        var o = I;
        for (I |= 4, _ = e.current; _ !== null; ) {
          var l = _, i = l.child;
          if (_.flags & 16) {
            var s = l.deletions;
            if (s !== null) {
              for (var u = 0; u < s.length; u++) {
                var a = s[u];
                for (_ = a; _ !== null; ) {
                  var d = _;
                  switch (d.tag) {
                    case 0:
                    case 11:
                    case 15:
                      rr(8, d, l);
                  }
                  var p = d.child;
                  if (p !== null) p.return = d, _ = p;
                  else for (; _ !== null; ) {
                    d = _;
                    var h = d.sibling, g = d.return;
                    if (td(d), d === a) {
                      _ = null;
                      break;
                    }
                    if (h !== null) {
                      h.return = g, _ = h;
                      break;
                    }
                    _ = g;
                  }
                }
              }
              var v = l.alternate;
              if (v !== null) {
                var w = v.child;
                if (w !== null) {
                  v.child = null;
                  do {
                    var R = w.sibling;
                    w.sibling = null, w = R;
                  } while (w !== null);
                }
              }
              _ = l;
            }
          }
          if (l.subtreeFlags & 2064 && i !== null) i.return = l, _ = i;
          else e: for (; _ !== null; ) {
            if (l = _, l.flags & 2048) switch (l.tag) {
              case 0:
              case 11:
              case 15:
                rr(9, l, l.return);
            }
            var f = l.sibling;
            if (f !== null) {
              f.return = l.return, _ = f;
              break e;
            }
            _ = l.return;
          }
        }
        var c = e.current;
        for (_ = c; _ !== null; ) {
          i = _;
          var m = i.child;
          if (i.subtreeFlags & 2064 && m !== null) m.return = i, _ = m;
          else e: for (i = c; _ !== null; ) {
            if (s = _, s.flags & 2048) try {
              switch (s.tag) {
                case 0:
                case 11:
                case 15:
                  wl(9, s);
              }
            } catch (E) {
              K(s, s.return, E);
            }
            if (s === i) {
              _ = null;
              break e;
            }
            var S = s.sibling;
            if (S !== null) {
              S.return = s.return, _ = S;
              break e;
            }
            _ = s.return;
          }
        }
        if (I = o, It(), rt && typeof rt.onPostCommitFiberRoot == "function") try {
          rt.onPostCommitFiberRoot(fl, e);
        } catch {
        }
        r = !0;
      }
      return r;
    } finally {
      j = n, je.transition = t;
    }
  }
  return !1;
}
function ka(e, t, n) {
  t = Nn(n, t), t = Hf(e, t, 1), e = Tt(e, t, 1), t = we(), e !== null && (zr(e, 1, t), _e(e, t));
}
function K(e, t, n) {
  if (e.tag === 3) ka(e, e, n);
  else for (; t !== null; ) {
    if (t.tag === 3) {
      ka(t, e, n);
      break;
    } else if (t.tag === 1) {
      var r = t.stateNode;
      if (typeof t.type.getDerivedStateFromError == "function" || typeof r.componentDidCatch == "function" && (Rt === null || !Rt.has(r))) {
        e = Nn(n, e), e = Vf(t, e, 1), t = Tt(t, e, 1), e = we(), t !== null && (zr(t, 1, e), _e(t, e));
        break;
      }
    }
    t = t.return;
  }
}
function v0(e, t, n) {
  var r = e.pingCache;
  r !== null && r.delete(t), t = we(), e.pingedLanes |= e.suspendedLanes & n, ie === e && (ce & n) === n && (ne === 4 || ne === 3 && (ce & 130023424) === ce && 500 > J() - Xs ? Vt(e, 0) : Ks |= n), _e(e, t);
}
function fd(e, t) {
  t === 0 && (e.mode & 1 ? (t = Vr, Vr <<= 1, !(Vr & 130023424) && (Vr = 4194304)) : t = 1);
  var n = we();
  e = ht(e, t), e !== null && (zr(e, t, n), _e(e, n));
}
function w0(e) {
  var t = e.memoizedState, n = 0;
  t !== null && (n = t.retryLane), fd(e, n);
}
function k0(e, t) {
  var n = 0;
  switch (e.tag) {
    case 13:
      var r = e.stateNode, o = e.memoizedState;
      o !== null && (n = o.retryLane);
      break;
    case 19:
      r = e.stateNode;
      break;
    default:
      throw Error(C(314));
  }
  r !== null && r.delete(t), fd(e, n);
}
var dd;
dd = function(e, t, n) {
  if (e !== null) if (e.memoizedProps !== t.pendingProps || Ee.current) xe = !0;
  else {
    if (!(e.lanes & n) && !(t.flags & 128)) return xe = !1, s0(e, t, n);
    xe = !!(e.flags & 131072);
  }
  else xe = !1, V && t.flags & 1048576 && gf(t, Io, t.index);
  switch (t.lanes = 0, t.tag) {
    case 2:
      var r = t.type;
      vo(e, t), e = t.pendingProps;
      var o = xn(t, ye.current);
      wn(t, n), o = Ws(null, t, r, e, o, n);
      var l = Hs();
      return t.flags |= 1, typeof o == "object" && o !== null && typeof o.render == "function" && o.$$typeof === void 0 ? (t.tag = 1, t.memoizedState = null, t.updateQueue = null, Pe(r) ? (l = !0, $o(t)) : l = !1, t.memoizedState = o.state !== null && o.state !== void 0 ? o.state : null, As(t), o.updater = vl, t.stateNode = o, o._reactInternals = t, Ai(t, r, e, n), t = bi(null, t, r, !0, l, n)) : (t.tag = 0, V && l && Ls(t), ve(null, t, o, n), t = t.child), t;
    case 16:
      r = t.elementType;
      e: {
        switch (vo(e, t), e = t.pendingProps, o = r._init, r = o(r._payload), t.type = r, o = t.tag = C0(r), e = Ve(r, e), o) {
          case 0:
            t = Bi(null, t, r, e, n);
            break e;
          case 1:
            t = ca(null, t, r, e, n);
            break e;
          case 11:
            t = ua(null, t, r, e, n);
            break e;
          case 14:
            t = aa(null, t, r, Ve(r.type, e), n);
            break e;
        }
        throw Error(C(
          306,
          r,
          ""
        ));
      }
      return t;
    case 0:
      return r = t.type, o = t.pendingProps, o = t.elementType === r ? o : Ve(r, o), Bi(e, t, r, o, n);
    case 1:
      return r = t.type, o = t.pendingProps, o = t.elementType === r ? o : Ve(r, o), ca(e, t, r, o, n);
    case 3:
      e: {
        if (Kf(t), e === null) throw Error(C(387));
        r = t.pendingProps, l = t.memoizedState, o = l.element, Cf(e, t), jo(t, r, null, n);
        var i = t.memoizedState;
        if (r = i.element, l.isDehydrated) if (l = { element: r, isDehydrated: !1, cache: i.cache, pendingSuspenseBoundaries: i.pendingSuspenseBoundaries, transitions: i.transitions }, t.updateQueue.baseState = l, t.memoizedState = l, t.flags & 256) {
          o = Nn(Error(C(423)), t), t = fa(e, t, r, n, o);
          break e;
        } else if (r !== o) {
          o = Nn(Error(C(424)), t), t = fa(e, t, r, n, o);
          break e;
        } else for (Re = Nt(t.stateNode.containerInfo.firstChild), Le = t, V = !0, Ge = null, n = kf(t, null, r, n), t.child = n; n; ) n.flags = n.flags & -3 | 4096, n = n.sibling;
        else {
          if (En(), r === o) {
            t = mt(e, t, n);
            break e;
          }
          ve(e, t, r, n);
        }
        t = t.child;
      }
      return t;
    case 5:
      return xf(t), e === null && Di(t), r = t.type, o = t.pendingProps, l = e !== null ? e.memoizedProps : null, i = o.children, zi(r, o) ? i = null : l !== null && zi(r, l) && (t.flags |= 32), Yf(e, t), ve(e, t, i, n), t.child;
    case 6:
      return e === null && Di(t), null;
    case 13:
      return Xf(e, t, n);
    case 4:
      return js(t, t.stateNode.containerInfo), r = t.pendingProps, e === null ? t.child = Pn(t, null, r, n) : ve(e, t, r, n), t.child;
    case 11:
      return r = t.type, o = t.pendingProps, o = t.elementType === r ? o : Ve(r, o), ua(e, t, r, o, n);
    case 7:
      return ve(e, t, t.pendingProps, n), t.child;
    case 8:
      return ve(e, t, t.pendingProps.children, n), t.child;
    case 12:
      return ve(e, t, t.pendingProps.children, n), t.child;
    case 10:
      e: {
        if (r = t.type._context, o = t.pendingProps, l = t.memoizedProps, i = o.value, b(Fo, r._currentValue), r._currentValue = i, l !== null) if (Xe(l.value, i)) {
          if (l.children === o.children && !Ee.current) {
            t = mt(e, t, n);
            break e;
          }
        } else for (l = t.child, l !== null && (l.return = t); l !== null; ) {
          var s = l.dependencies;
          if (s !== null) {
            i = l.child;
            for (var u = s.firstContext; u !== null; ) {
              if (u.context === r) {
                if (l.tag === 1) {
                  u = ft(-1, n & -n), u.tag = 2;
                  var a = l.updateQueue;
                  if (a !== null) {
                    a = a.shared;
                    var d = a.pending;
                    d === null ? u.next = u : (u.next = d.next, d.next = u), a.pending = u;
                  }
                }
                l.lanes |= n, u = l.alternate, u !== null && (u.lanes |= n), Ii(
                  l.return,
                  n,
                  t
                ), s.lanes |= n;
                break;
              }
              u = u.next;
            }
          } else if (l.tag === 10) i = l.type === t.type ? null : l.child;
          else if (l.tag === 18) {
            if (i = l.return, i === null) throw Error(C(341));
            i.lanes |= n, s = i.alternate, s !== null && (s.lanes |= n), Ii(i, n, t), i = l.sibling;
          } else i = l.child;
          if (i !== null) i.return = l;
          else for (i = l; i !== null; ) {
            if (i === t) {
              i = null;
              break;
            }
            if (l = i.sibling, l !== null) {
              l.return = i.return, i = l;
              break;
            }
            i = i.return;
          }
          l = i;
        }
        ve(e, t, o.children, n), t = t.child;
      }
      return t;
    case 9:
      return o = t.type, r = t.pendingProps.children, wn(t, n), o = Be(o), r = r(o), t.flags |= 1, ve(e, t, r, n), t.child;
    case 14:
      return r = t.type, o = Ve(r, t.pendingProps), o = Ve(r.type, o), aa(e, t, r, o, n);
    case 15:
      return Qf(e, t, t.type, t.pendingProps, n);
    case 17:
      return r = t.type, o = t.pendingProps, o = t.elementType === r ? o : Ve(r, o), vo(e, t), t.tag = 1, Pe(r) ? (e = !0, $o(t)) : e = !1, wn(t, n), Wf(t, r, o), Ai(t, r, o, n), bi(null, t, r, !0, e, n);
    case 19:
      return Zf(e, t, n);
    case 22:
      return Gf(e, t, n);
  }
  throw Error(C(156, t.tag));
};
function pd(e, t) {
  return jc(e, t);
}
function S0(e, t, n, r) {
  this.tag = e, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = r, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null;
}
function Ae(e, t, n, r) {
  return new S0(e, t, n, r);
}
function eu(e) {
  return e = e.prototype, !(!e || !e.isReactComponent);
}
function C0(e) {
  if (typeof e == "function") return eu(e) ? 1 : 0;
  if (e != null) {
    if (e = e.$$typeof, e === ws) return 11;
    if (e === ks) return 14;
  }
  return 2;
}
function Lt(e, t) {
  var n = e.alternate;
  return n === null ? (n = Ae(e.tag, t, e.key, e.mode), n.elementType = e.elementType, n.type = e.type, n.stateNode = e.stateNode, n.alternate = e, e.alternate = n) : (n.pendingProps = t, n.type = e.type, n.flags = 0, n.subtreeFlags = 0, n.deletions = null), n.flags = e.flags & 14680064, n.childLanes = e.childLanes, n.lanes = e.lanes, n.child = e.child, n.memoizedProps = e.memoizedProps, n.memoizedState = e.memoizedState, n.updateQueue = e.updateQueue, t = e.dependencies, n.dependencies = t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }, n.sibling = e.sibling, n.index = e.index, n.ref = e.ref, n;
}
function So(e, t, n, r, o, l) {
  var i = 2;
  if (r = e, typeof e == "function") eu(e) && (i = 1);
  else if (typeof e == "string") i = 5;
  else e: switch (e) {
    case nn:
      return Qt(n.children, o, l, t);
    case vs:
      i = 8, o |= 8;
      break;
    case ui:
      return e = Ae(12, n, t, o | 2), e.elementType = ui, e.lanes = l, e;
    case ai:
      return e = Ae(13, n, t, o), e.elementType = ai, e.lanes = l, e;
    case ci:
      return e = Ae(19, n, t, o), e.elementType = ci, e.lanes = l, e;
    case Cc:
      return Sl(n, o, l, t);
    default:
      if (typeof e == "object" && e !== null) switch (e.$$typeof) {
        case kc:
          i = 10;
          break e;
        case Sc:
          i = 9;
          break e;
        case ws:
          i = 11;
          break e;
        case ks:
          i = 14;
          break e;
        case vt:
          i = 16, r = null;
          break e;
      }
      throw Error(C(130, e == null ? e : typeof e, ""));
  }
  return t = Ae(i, n, t, o), t.elementType = e, t.type = r, t.lanes = l, t;
}
function Qt(e, t, n, r) {
  return e = Ae(7, e, r, t), e.lanes = n, e;
}
function Sl(e, t, n, r) {
  return e = Ae(22, e, r, t), e.elementType = Cc, e.lanes = n, e.stateNode = { isHidden: !1 }, e;
}
function ei(e, t, n) {
  return e = Ae(6, e, null, t), e.lanes = n, e;
}
function ti(e, t, n) {
  return t = Ae(4, e.children !== null ? e.children : [], e.key, t), t.lanes = n, t.stateNode = { containerInfo: e.containerInfo, pendingChildren: null, implementation: e.implementation }, t;
}
function x0(e, t, n, r, o) {
  this.tag = t, this.containerInfo = e, this.finishedWork = this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.pendingContext = this.context = null, this.callbackPriority = 0, this.eventTimes = Dl(0), this.expirationTimes = Dl(-1), this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = Dl(0), this.identifierPrefix = r, this.onRecoverableError = o, this.mutableSourceEagerHydrationData = null;
}
function tu(e, t, n, r, o, l, i, s, u) {
  return e = new x0(e, t, n, s, u), t === 1 ? (t = 1, l === !0 && (t |= 8)) : t = 0, l = Ae(3, null, null, t), e.current = l, l.stateNode = e, l.memoizedState = { element: r, isDehydrated: n, cache: null, transitions: null, pendingSuspenseBoundaries: null }, As(l), e;
}
function E0(e, t, n) {
  var r = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
  return { $$typeof: tn, key: r == null ? null : "" + r, children: e, containerInfo: t, implementation: n };
}
function hd(e) {
  if (!e) return Ot;
  e = e._reactInternals;
  e: {
    if (qt(e) !== e || e.tag !== 1) throw Error(C(170));
    var t = e;
    do {
      switch (t.tag) {
        case 3:
          t = t.stateNode.context;
          break e;
        case 1:
          if (Pe(t.type)) {
            t = t.stateNode.__reactInternalMemoizedMergedChildContext;
            break e;
          }
      }
      t = t.return;
    } while (t !== null);
    throw Error(C(171));
  }
  if (e.tag === 1) {
    var n = e.type;
    if (Pe(n)) return hf(e, n, t);
  }
  return t;
}
function md(e, t, n, r, o, l, i, s, u) {
  return e = tu(n, r, !0, e, o, l, i, s, u), e.context = hd(null), n = e.current, r = we(), o = zt(n), l = ft(r, o), l.callback = t ?? null, Tt(n, l, o), e.current.lanes = o, zr(e, o, r), _e(e, r), e;
}
function Cl(e, t, n, r) {
  var o = t.current, l = we(), i = zt(o);
  return n = hd(n), t.context === null ? t.context = n : t.pendingContext = n, t = ft(l, i), t.payload = { element: e }, r = r === void 0 ? null : r, r !== null && (t.callback = r), e = Tt(o, t, i), e !== null && (Ke(e, o, i, l), mo(e, o, i)), i;
}
function Go(e) {
  if (e = e.current, !e.child) return null;
  switch (e.child.tag) {
    case 5:
      return e.child.stateNode;
    default:
      return e.child.stateNode;
  }
}
function Sa(e, t) {
  if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
    var n = e.retryLane;
    e.retryLane = n !== 0 && n < t ? n : t;
  }
}
function nu(e, t) {
  Sa(e, t), (e = e.alternate) && Sa(e, t);
}
function P0() {
  return null;
}
var gd = typeof reportError == "function" ? reportError : function(e) {
  console.error(e);
};
function ru(e) {
  this._internalRoot = e;
}
xl.prototype.render = ru.prototype.render = function(e) {
  var t = this._internalRoot;
  if (t === null) throw Error(C(409));
  Cl(e, t, null, null);
};
xl.prototype.unmount = ru.prototype.unmount = function() {
  var e = this._internalRoot;
  if (e !== null) {
    this._internalRoot = null;
    var t = e.containerInfo;
    Zt(function() {
      Cl(null, e, null, null);
    }), t[pt] = null;
  }
};
function xl(e) {
  this._internalRoot = e;
}
xl.prototype.unstable_scheduleHydration = function(e) {
  if (e) {
    var t = Qc();
    e = { blockedOn: null, target: e, priority: t };
    for (var n = 0; n < kt.length && t !== 0 && t < kt[n].priority; n++) ;
    kt.splice(n, 0, e), n === 0 && Yc(e);
  }
};
function ou(e) {
  return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11);
}
function El(e) {
  return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11 && (e.nodeType !== 8 || e.nodeValue !== " react-mount-point-unstable "));
}
function Ca() {
}
function _0(e, t, n, r, o) {
  if (o) {
    if (typeof r == "function") {
      var l = r;
      r = function() {
        var a = Go(i);
        l.call(a);
      };
    }
    var i = md(t, r, e, 0, null, !1, !1, "", Ca);
    return e._reactRootContainer = i, e[pt] = i.current, vr(e.nodeType === 8 ? e.parentNode : e), Zt(), i;
  }
  for (; o = e.lastChild; ) e.removeChild(o);
  if (typeof r == "function") {
    var s = r;
    r = function() {
      var a = Go(u);
      s.call(a);
    };
  }
  var u = tu(e, 0, !1, null, null, !1, !1, "", Ca);
  return e._reactRootContainer = u, e[pt] = u.current, vr(e.nodeType === 8 ? e.parentNode : e), Zt(function() {
    Cl(t, u, n, r);
  }), u;
}
function Pl(e, t, n, r, o) {
  var l = n._reactRootContainer;
  if (l) {
    var i = l;
    if (typeof o == "function") {
      var s = o;
      o = function() {
        var u = Go(i);
        s.call(u);
      };
    }
    Cl(t, i, e, o);
  } else i = _0(n, t, e, o, r);
  return Go(i);
}
Hc = function(e) {
  switch (e.tag) {
    case 3:
      var t = e.stateNode;
      if (t.current.memoizedState.isDehydrated) {
        var n = Yn(t.pendingLanes);
        n !== 0 && (xs(t, n | 1), _e(t, J()), !(I & 6) && (Tn = J() + 500, It()));
      }
      break;
    case 13:
      Zt(function() {
        var r = ht(e, 1);
        if (r !== null) {
          var o = we();
          Ke(r, e, 1, o);
        }
      }), nu(e, 1);
  }
};
Es = function(e) {
  if (e.tag === 13) {
    var t = ht(e, 134217728);
    if (t !== null) {
      var n = we();
      Ke(t, e, 134217728, n);
    }
    nu(e, 134217728);
  }
};
Vc = function(e) {
  if (e.tag === 13) {
    var t = zt(e), n = ht(e, t);
    if (n !== null) {
      var r = we();
      Ke(n, e, t, r);
    }
    nu(e, t);
  }
};
Qc = function() {
  return j;
};
Gc = function(e, t) {
  var n = j;
  try {
    return j = e, t();
  } finally {
    j = n;
  }
};
ki = function(e, t, n) {
  switch (t) {
    case "input":
      if (pi(e, n), t = n.name, n.type === "radio" && t != null) {
        for (n = e; n.parentNode; ) n = n.parentNode;
        for (n = n.querySelectorAll("input[name=" + JSON.stringify("" + t) + '][type="radio"]'), t = 0; t < n.length; t++) {
          var r = n[t];
          if (r !== e && r.form === e.form) {
            var o = ml(r);
            if (!o) throw Error(C(90));
            Ec(r), pi(r, o);
          }
        }
      }
      break;
    case "textarea":
      _c(e, n);
      break;
    case "select":
      t = n.value, t != null && mn(e, !!n.multiple, t, !1);
  }
};
Oc = Zs;
$c = Zt;
var N0 = { usingClientEntryPoint: !1, Events: [Mr, sn, ml, Lc, Mc, Zs] }, Vn = { findFiberByHostInstance: Ut, bundleType: 0, version: "18.3.1", rendererPackageName: "react-dom" }, T0 = { bundleType: Vn.bundleType, version: Vn.version, rendererPackageName: Vn.rendererPackageName, rendererConfig: Vn.rendererConfig, overrideHookState: null, overrideHookStateDeletePath: null, overrideHookStateRenamePath: null, overrideProps: null, overridePropsDeletePath: null, overridePropsRenamePath: null, setErrorHandler: null, setSuspenseHandler: null, scheduleUpdate: null, currentDispatcherRef: gt.ReactCurrentDispatcher, findHostInstanceByFiber: function(e) {
  return e = Fc(e), e === null ? null : e.stateNode;
}, findFiberByHostInstance: Vn.findFiberByHostInstance || P0, findHostInstancesForRefresh: null, scheduleRefresh: null, scheduleRoot: null, setRefreshHandler: null, getCurrentFiber: null, reconcilerVersion: "18.3.1-next-f1338f8080-20240426" };
if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
  var no = __REACT_DEVTOOLS_GLOBAL_HOOK__;
  if (!no.isDisabled && no.supportsFiber) try {
    fl = no.inject(T0), rt = no;
  } catch {
  }
}
$e.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = N0;
$e.createPortal = function(e, t) {
  var n = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
  if (!ou(t)) throw Error(C(200));
  return E0(e, t, null, n);
};
$e.createRoot = function(e, t) {
  if (!ou(e)) throw Error(C(299));
  var n = !1, r = "", o = gd;
  return t != null && (t.unstable_strictMode === !0 && (n = !0), t.identifierPrefix !== void 0 && (r = t.identifierPrefix), t.onRecoverableError !== void 0 && (o = t.onRecoverableError)), t = tu(e, 1, !1, null, null, n, !1, r, o), e[pt] = t.current, vr(e.nodeType === 8 ? e.parentNode : e), new ru(t);
};
$e.findDOMNode = function(e) {
  if (e == null) return null;
  if (e.nodeType === 1) return e;
  var t = e._reactInternals;
  if (t === void 0)
    throw typeof e.render == "function" ? Error(C(188)) : (e = Object.keys(e).join(","), Error(C(268, e)));
  return e = Fc(t), e = e === null ? null : e.stateNode, e;
};
$e.flushSync = function(e) {
  return Zt(e);
};
$e.hydrate = function(e, t, n) {
  if (!El(t)) throw Error(C(200));
  return Pl(null, e, t, !0, n);
};
$e.hydrateRoot = function(e, t, n) {
  if (!ou(e)) throw Error(C(405));
  var r = n != null && n.hydratedSources || null, o = !1, l = "", i = gd;
  if (n != null && (n.unstable_strictMode === !0 && (o = !0), n.identifierPrefix !== void 0 && (l = n.identifierPrefix), n.onRecoverableError !== void 0 && (i = n.onRecoverableError)), t = md(t, null, e, 1, n ?? null, o, !1, l, i), e[pt] = t.current, vr(e), r) for (e = 0; e < r.length; e++) n = r[e], o = n._getVersion, o = o(n._source), t.mutableSourceEagerHydrationData == null ? t.mutableSourceEagerHydrationData = [n, o] : t.mutableSourceEagerHydrationData.push(
    n,
    o
  );
  return new xl(t);
};
$e.render = function(e, t, n) {
  if (!El(t)) throw Error(C(200));
  return Pl(null, e, t, !1, n);
};
$e.unmountComponentAtNode = function(e) {
  if (!El(e)) throw Error(C(40));
  return e._reactRootContainer ? (Zt(function() {
    Pl(null, null, e, !1, function() {
      e._reactRootContainer = null, e[pt] = null;
    });
  }), !0) : !1;
};
$e.unstable_batchedUpdates = Zs;
$e.unstable_renderSubtreeIntoContainer = function(e, t, n, r) {
  if (!El(n)) throw Error(C(200));
  if (e == null || e._reactInternals === void 0) throw Error(C(38));
  return Pl(e, t, n, !1, r);
};
$e.version = "18.3.1-next-f1338f8080-20240426";
function yd() {
  if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"))
    try {
      __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(yd);
    } catch (e) {
      console.error(e);
    }
}
yd(), gc.exports = $e;
var R0 = gc.exports, vd, xa = R0;
vd = xa.createRoot, xa.hydrateRoot;
const wd = ut.createContext(null);
function z0(e, t, n) {
  class r extends t {
    constructor() {
      super(...arguments), this.isDOMInitialized = !1, this.serial = 0;
    }
    /**
    * Override _replaceHTML to stop FVTT's standard template lifecycle coming in
    * and knackering React on every update.
    * @see {@link Application._replaceHTML}
    * @override
    */
    _replaceHTML(l, i) {
      i.wrap("<div/>"), this.isDOMInitialized || (super._replaceHTML(l, i), this.isDOMInitialized = !0), l.find(".window-title").text(this.title);
    }
    /**
    * Override _injectHTML to set our domInitialized flag.
    */
    _injectHTML(l) {
      this.isDOMInitialized = !0, super._injectHTML(l);
    }
    /**
    * We need to pick somewhere to activate and render React. It would have
    * been nice to do this from `render` & friends but they happen before
    * there's a DOM element. `activateListeners` at least happens *after* the
    * DOM has been created.
    * @override
    */
    activateListeners(l) {
      const i = $(this.element).find(".react-target"), s = i.closest(".window-content");
      this.options.resizable ? s.addClass("resizable") : s.addClass("non-resizable");
      const u = i.get(0);
      if (u) {
        const a = /* @__PURE__ */ k(y.StrictMode, {
          children: /* @__PURE__ */ k(wd.Provider, {
            value: this,
            children: n(this, this.serial)
          }, "FoundryAppContextProvider")
        });
        this.reactRoot || (this.reactRoot = vd(u)), this.reactRoot.render(a), this.serial += 1;
      }
    }
    async close(l) {
      try {
        await super.close(l), this.reactRoot && (this.reactRoot.unmount(), this.reactRoot = void 0);
      } catch {
      }
    }
  }
  return Object.defineProperty(r, "name", {
    value: e
  }), r;
}
const On = {
  position: "absolute",
  inset: 0
};
function Ea(e, t) {
  if (e.inserted[t.name] === void 0)
    return e.insert("", t, e.sheet, !0);
}
function Pa(e, t, n) {
  var r = [], o = ps(e, r, n);
  return r.length < 2 ? n : o + t(r);
}
var L0 = function(t) {
  var n = as(t);
  n.sheet.speedy = function(s) {
    this.isSpeedy = s;
  }, n.compat = !0;
  var r = function() {
    for (var u = arguments.length, a = new Array(u), d = 0; d < u; d++)
      a[d] = arguments[d];
    var p = Xn(a, n.registered, void 0);
    return hs(n, p, !1), n.key + "-" + p.name;
  }, o = function() {
    for (var u = arguments.length, a = new Array(u), d = 0; d < u; d++)
      a[d] = arguments[d];
    var p = Xn(a, n.registered), h = "animation-" + p.name;
    return Ea(n, {
      name: p.name,
      styles: "@keyframes " + h + "{" + p.styles + "}"
    }), h;
  }, l = function() {
    for (var u = arguments.length, a = new Array(u), d = 0; d < u; d++)
      a[d] = arguments[d];
    var p = Xn(a, n.registered);
    Ea(n, p);
  }, i = function() {
    for (var u = arguments.length, a = new Array(u), d = 0; d < u; d++)
      a[d] = arguments[d];
    return Pa(n.registered, r, M0(a));
  };
  return {
    css: r,
    cx: i,
    injectGlobal: l,
    keyframes: o,
    hydrate: function(u) {
      u.forEach(function(a) {
        n.inserted[a] = !0;
      });
    },
    flush: function() {
      n.registered = {}, n.inserted = {}, n.sheet.flush();
    },
    sheet: n.sheet,
    cache: n,
    getRegisteredStyles: ps.bind(null, n.registered),
    merge: Pa.bind(null, n.registered, r)
  };
}, M0 = function e(t) {
  for (var n = "", r = 0; r < t.length; r++) {
    var o = t[r];
    if (o != null) {
      var l = void 0;
      switch (typeof o) {
        case "boolean":
          break;
        case "object": {
          if (Array.isArray(o))
            l = e(o);
          else {
            l = "";
            for (var i in o)
              o[i] && i && (l && (l += " "), l += i);
          }
          break;
        }
        default:
          l = o;
      }
      l && (n && (n += " "), n += l);
    }
  }
  return n;
}, kd = L0({
  key: "css"
}), O0 = kd.cx, $0 = kd.css, D0 = /* @__PURE__ */ dc(function(e, t) {
  var n = e.styles, r = Xn([n], void 0, y.useContext(pc)), o = y.useRef();
  return yu(function() {
    var l = t.key + "-global", i = new t.sheet.constructor({
      key: l,
      nonce: t.sheet.nonce,
      container: t.sheet.container,
      speedy: t.sheet.isSpeedy
    }), s = !1, u = document.querySelector('style[data-emotion="' + l + " " + r.name + '"]');
    return t.sheet.tags.length && (i.before = t.sheet.tags[0]), u !== null && (s = !0, u.setAttribute("data-emotion", l), i.hydrate([u])), o.current = [i, s], function() {
      i.flush();
    };
  }, [t]), yu(function() {
    var l = o.current, i = l[0], s = l[1];
    if (s) {
      l[1] = !1;
      return;
    }
    if (r.next !== void 0 && hs(t, r.next, !0), i.tags.length) {
      var u = i.tags[i.tags.length - 1].nextElementSibling;
      i.before = u, i.flush();
    }
    t.insert("", r, i, !1);
  }, [t, r.name]), null;
});
const _a = {
  importStatement: "@import url('https://fonts.googleapis.com/css2?family=Averia+Libre:ital,wght@0,300;0,400;0,700;1,300;1,400;1,700&family=Averia+Serif+Libre:ital,wght@0,300;0,400;0,700;1,300;1,400;1,700&display=swap');",
  fontFamily: "16px 'Averia Libre', sans-serif"
}, Sd = {
  importStatement: "@import url('https://fonts.googleapis.com/css2?family=Love+Ya+Like+A+Sister&display=swap');",
  fontFamily: "16px 'Love Ya Like A Sister', sans-serif"
};
function I0(e) {
  const t = e.s, n = e.l, r = n <= 0.5 ? n * (1 + t) : n + t - n * t;
  let o = e.h % 1, l, i, s, u, a, d, p, h, g, v;
  if (o < 0 && (o += 1), l = i = s = n, r > 0)
    switch (u = n + n - r, a = (r - u) / r, o *= 6, d = Math.floor(o), p = o - d, h = r * a * p, g = u + h, v = r - h, d) {
      case 0:
        l = r, i = g, s = u;
        break;
      case 1:
        l = v, i = r, s = u;
        break;
      case 2:
        l = u, i = r, s = g;
        break;
      case 3:
        l = u, i = v, s = r;
        break;
      case 4:
        l = g, i = u, s = r;
        break;
      case 5:
        l = r, i = u, s = v;
        break;
    }
  return {
    type: "rgba",
    r: Math.floor(l * 255),
    g: Math.floor(i * 255),
    b: Math.floor(s * 255),
    a: e.a
  };
}
function F0(e) {
  const t = e.r / 255, n = e.g / 255, r = e.b / 255, o = Math.max(t, n, r), l = Math.min(t, n, r);
  let i, s, u, a, d = 0, p = 0, h = 0;
  return h = (l + o) / 2, h > 0 && (i = o - l, p = i, p > 0 && (p = p / (h <= 0.5 ? o + l : 2 - o - l), s = (o - t) / i, u = (o - n) / i, a = (o - r) / i, t === o ? d = n === l ? 5 + a : 1 - u : n === o ? d = r === l ? 1 + s : 3 - a : d = t === l ? 3 + u : 5 - s, d = d / 6)), {
    type: "hsla",
    h: d % 1,
    s: p,
    l: h,
    a: e.a
  };
}
function A0(e) {
  return "hsl" + (e.a ? "a" : "") + "(" + Math.round(e.h * 360) + ", " + Math.round(e.s * 100) + "%, " + Math.round(e.l * 100) + "%" + (e.a ? ", " + e.a.toFixed(2) : "") + ")";
}
function j0(e) {
  return "rgb" + (e.a ? "a" : "") + "(" + Math.round(e.r) + ", " + Math.round(e.g) + ", " + Math.round(e.b) + (e.a ? ", " + e.a.toFixed(2) : "") + ")";
}
function B0(e) {
  let t = "#" + (e.r < 16 ? "0" : "") + e.r.toString(16) + (e.g < 16 ? "0" : "") + e.g.toString(16) + (e.b < 16 ? "0" : "") + e.b.toString(16);
  if (e.a !== void 0) {
    const n = Math.floor(e.a * 255);
    t += (n < 16 ? "0" : "") + n.toString(16);
  }
  return t;
}
function ro(e) {
  return e.length === 1 && (e += e), Math.max(0, Math.min(255, parseInt(e, 16)));
}
function Cd(e) {
  return e ? Math.max(0, Math.min(1, parseFloat(e))) : void 0;
}
function b0(e) {
  let t = parseInt(e, 10) % 360;
  return t < 0 && (t += 360), t / 360;
}
function ni(e) {
  const t = e.charAt(e.length - 1) === "%";
  return t && (e = e.slice(0, e.length - 1)), Math.max(0, Math.min(255, Math.round(parseInt(e, 10) * (t ? 2.55 : 1))));
}
function Na(e) {
  return Math.max(0, Math.min(100, parseInt(e, 10))) / 100;
}
function U0(e) {
  const t = /^hsla?\(\s*(-?\d+)\s*,\s*(-?\d+%)\s*,\s*(-?\d+%)\s*(?:,\s*(-?\d*(?:\.\d+)?)?)?\s*\)$/.exec(e);
  return t ? {
    type: "hsla",
    h: b0(t[1]),
    s: Na(t[2]),
    l: Na(t[3]),
    a: Cd(t[4])
  } : void 0;
}
function W0(e) {
  const t = /^rgba?\(\s*(-?\d+%?)\s*,\s*(-?\d+%?)\s*,\s*(-?\d+%?)\s*(?:,\s*(-?\d*(?:\.\d+)?)?)?\s*\)$/.exec(e);
  return t ? {
    type: "rgba",
    r: ni(t[1]),
    g: ni(t[2]),
    b: ni(t[3]),
    a: Cd(t[4])
  } : void 0;
}
function Ta(e) {
  const t = /^#([\da-f])([\da-f])([\da-f])([\da-f])?$/i.exec(e) || /^#([\da-f]{2})([\da-f]{2})([\da-f]{2})([\da-f]{2})?$/i.exec(e);
  return t ? {
    type: "rgba",
    r: ro(t[1]),
    g: ro(t[2]),
    b: ro(t[3]),
    a: typeof t[4] > "u" || t[4] === "" ? void 0 : ro(t[4]) / 255
  } : void 0;
}
const Ra = {
  aliceblue: "#f0f8ff",
  antiquewhite: "#faebd7",
  aqua: "#00ffff",
  aquamarine: "#7fffd4",
  azure: "#f0ffff",
  beige: "#f5f5dc",
  bisque: "#ffe4c4",
  black: "#000000",
  blanchedalmond: "#ffebcd",
  blue: "#0000ff",
  blueviolet: "#8a2be2",
  brown: "#a52a2a",
  burlywood: "#deb887",
  cadetblue: "#5f9ea0",
  chartreuse: "#7fff00",
  chocolate: "#d2691e",
  coral: "#ff7f50",
  cornflowerblue: "#6495ed",
  cornsilk: "#fff8dc",
  crimson: "#dc143c",
  cyan: "#00ffff",
  darkblue: "#00008b",
  darkcyan: "#008b8b",
  darkgoldenrod: "#b8860b",
  darkgray: "#a9a9a9",
  darkgreen: "#006400",
  darkgrey: "#a9a9a9",
  darkkhaki: "#bdb76b",
  darkmagenta: "#8b008b",
  darkolivegreen: "#556b2f",
  darkorange: "#ff8c00",
  darkorchid: "#9932cc",
  darkred: "#8b0000",
  darksalmon: "#e9967a",
  darkseagreen: "#8fbc8f",
  darkslateblue: "#483d8b",
  darkslategray: "#2f4f4f",
  darkslategrey: "#2f4f4f",
  darkturquoise: "#00ced1",
  darkviolet: "#9400d3",
  deeppink: "#ff1493",
  deepskyblue: "#00bfff",
  dimgray: "#696969",
  dimgrey: "#696969",
  dodgerblue: "#1e90ff",
  firebrick: "#b22222",
  floralwhite: "#fffaf0",
  forestgreen: "#228b22",
  fuchsia: "#ff00ff",
  gainsboro: "#dcdcdc",
  ghostwhite: "#f8f8ff",
  gold: "#ffd700",
  goldenrod: "#daa520",
  gray: "#808080",
  green: "#008000",
  greenyellow: "#adff2f",
  grey: "#808080",
  honeydew: "#f0fff0",
  hotpink: "#ff69b4",
  indianred: "#cd5c5c",
  indigo: "#4b0082",
  ivory: "#fffff0",
  khaki: "#f0e68c",
  lavender: "#e6e6fa",
  lavenderblush: "#fff0f5",
  lawngreen: "#7cfc00",
  lemonchiffon: "#fffacd",
  lightblue: "#add8e6",
  lightcoral: "#f08080",
  lightcyan: "#e0ffff",
  lightgoldenrodyellow: "#fafad2",
  lightgray: "#d3d3d3",
  lightgreen: "#90ee90",
  lightgrey: "#d3d3d3",
  lightpink: "#ffb6c1",
  lightsalmon: "#ffa07a",
  lightseagreen: "#20b2aa",
  lightskyblue: "#87cefa",
  lightslategray: "#778899",
  lightslategrey: "#778899",
  lightsteelblue: "#b0c4de",
  lightyellow: "#ffffe0",
  lime: "#00ff00",
  limegreen: "#32cd32",
  linen: "#faf0e6",
  magenta: "#ff00ff",
  maroon: "#800000",
  mediumaquamarine: "#66cdaa",
  mediumblue: "#0000cd",
  mediumorchid: "#ba55d3",
  mediumpurple: "#9370db",
  mediumseagreen: "#3cb371",
  mediumslateblue: "#7b68ee",
  mediumspringgreen: "#00fa9a",
  mediumturquoise: "#48d1cc",
  mediumvioletred: "#c71585",
  midnightblue: "#191970",
  mintcream: "#f5fffa",
  mistyrose: "#ffe4e1",
  moccasin: "#ffe4b5",
  navajowhite: "#ffdead",
  navy: "#000080",
  oldlace: "#fdf5e6",
  olive: "#808000",
  olivedrab: "#6b8e23",
  orange: "#ffa500",
  orangered: "#ff4500",
  orchid: "#da70d6",
  palegoldenrod: "#eee8aa",
  palegreen: "#98fb98",
  paleturquoise: "#afeeee",
  palevioletred: "#db7093",
  papayawhip: "#ffefd5",
  peachpuff: "#ffdab9",
  peru: "#cd853f",
  pink: "#ffc0cb",
  plum: "#dda0dd",
  powderblue: "#b0e0e6",
  purple: "#800080",
  // http://codepen.io/trezy/blog/honoring-a-great-man
  rebeccapurple: "#663399",
  red: "#ff0000",
  rosybrown: "#bc8f8f",
  royalblue: "#4169e1",
  saddlebrown: "#8b4513",
  salmon: "#fa8072",
  sandybrown: "#f4a460",
  seagreen: "#2e8b57",
  seashell: "#fff5ee",
  sienna: "#a0522d",
  silver: "#c0c0c0",
  skyblue: "#87ceeb",
  slateblue: "#6a5acd",
  slategray: "#708090",
  slategrey: "#708090",
  snow: "#fffafa",
  springgreen: "#00ff7f",
  steelblue: "#4682b4",
  tan: "#d2b48c",
  teal: "#008080",
  thistle: "#d8bfd8",
  tomato: "#ff6347",
  transparent: "rgb(0,0,0,0)",
  turquoise: "#40e0d0",
  violet: "#ee82ee",
  wheat: "#f5deb3",
  white: "#ffffff",
  whitesmoke: "#f5f5f5",
  yellow: "#ffff00",
  yellowgreen: "#9acd32"
};
function za(e) {
  return e.type === "rgba";
}
function H0(e) {
  return e.type === "hsla";
}
const La = "Invalid color specification", Ma = "Invalid internal state", W = class W {
  constructor(t) {
    this._rgb = void 0, this._hsl = void 0, za(t) ? this._rgb = t : this._hsl = t;
  }
  /**
  * utility constructor for creating an Irid instance from a CSS color string
  */
  static create(t) {
    if (t instanceof W)
      return t;
    if (typeof t == "string") {
      const n = Ta(t) || W0(t) || Ta(Ra[t.toLowerCase()]);
      if (n)
        return new W(n);
      const r = U0(t);
      if (!r)
        throw new Error(La);
      return new W(r);
    }
    if (za(t) || H0(t))
      return new W(t);
    throw new Error(La);
  }
  get rgb() {
    if (!this._rgb) {
      if (!this._hsl)
        throw new Error(Ma);
      this._rgb = I0(this._hsl);
    }
    return this._rgb;
  }
  get hsl() {
    if (!this._hsl) {
      if (!this._rgb)
        throw new Error(Ma);
      this._hsl = F0(this._rgb);
    }
    return this._hsl;
  }
  // See http://en.wikipedia.org/wiki/HSL_and_HSV#Lightness
  luma() {
    const t = this.rgb;
    return (0.3 * t.r + 0.59 * t.g + 0.11 * t.b) / 255;
  }
  // see http://www.w3.org/TR/WCAG/#relativeluminancedef
  relativeLuminance() {
    function t(n) {
      const r = n / 255;
      return r <= 0.03928 ? r / 12.92 : Math.pow((r + 0.055) / 1.055, 2.4);
    }
    return 0.2126 * t(this.rgb.r) + 0.7152 * t(this.rgb.g) + 0.0722 * t(this.rgb.b);
  }
  // see http://www.w3.org/TR/WCAG20/#visual-audio-contrast
  // http://www.w3.org/TR/WCAG20/#contrast-ratiodefs
  contrastRatio(t) {
    t = W.create(t);
    const n = t.relativeLuminance(), r = this.relativeLuminance(), o = Math.max(n, r), l = Math.min(n, r);
    return (o + 0.05) / (l + 0.05);
  }
  red(t) {
    return typeof t > "u" ? this.rgb.r : new W({
      type: "rgba",
      r: t,
      g: this.rgb.g,
      b: this.rgb.b,
      a: this.rgb.a
    });
  }
  green(t) {
    return typeof t > "u" ? this.rgb.g : new W({
      type: "rgba",
      r: this.rgb.r,
      g: t,
      b: this.rgb.b,
      a: this.rgb.a
    });
  }
  blue(t) {
    return typeof t > "u" ? this.rgb.b : new W({
      type: "rgba",
      r: this.rgb.r,
      g: this.rgb.g,
      b: t,
      a: this.rgb.a
    });
  }
  hue(t) {
    return typeof t > "u" ? this.hsl.h : new W({
      type: "hsla",
      h: t,
      s: this.hsl.s,
      l: this.hsl.l,
      a: this.hsl.a
    });
  }
  saturation(t) {
    return typeof t > "u" ? this.hsl.s : new W({
      type: "hsla",
      h: this.hsl.h,
      s: t,
      l: this.hsl.l,
      a: this.hsl.a
    });
  }
  lightness(t) {
    return typeof t > "u" ? this.hsl.l : new W({
      type: "hsla",
      h: this.hsl.h,
      s: this.hsl.s,
      l: t,
      a: this.hsl.a
    });
  }
  alpha(t) {
    var n;
    return arguments.length === 0 ? (n = this._hsl || this._rgb) == null ? void 0 : n.a : this._hsl ? new W({
      type: "hsla",
      h: this.hsl.h,
      s: this.hsl.s,
      l: this.hsl.l,
      a: t ?? void 0
    }) : new W({
      type: "rgba",
      r: this.rgb.r,
      g: this.rgb.g,
      b: this.rgb.b,
      a: t ?? void 0
    });
  }
  opacity(t) {
    return arguments.length === 0 ? this.alpha() : this.alpha(t);
  }
  lighten(t) {
    return new W({
      type: "hsla",
      h: this.hsl.h,
      s: this.hsl.s,
      l: this.hsl.l + (1 - this.hsl.l) * t,
      a: this.hsl.a
    });
  }
  darken(t) {
    return new W({
      type: "hsla",
      h: this.hsl.h,
      s: this.hsl.s,
      l: this.hsl.l - this.hsl.l * t,
      a: this.hsl.a
    });
  }
  invert() {
    return new W({
      type: "rgba",
      r: 255 - this.rgb.r,
      g: 255 - this.rgb.g,
      b: 255 - this.rgb.b,
      a: this.rgb.a
    });
  }
  complement() {
    return new W({
      type: "hsla",
      h: (this.hsl.h + 0.5) % 1,
      s: this.hsl.s,
      l: this.hsl.l,
      a: this.hsl.a
    });
  }
  desaturate() {
    return new W({
      type: "hsla",
      h: this.hsl.h,
      s: 0,
      l: this.hsl.l,
      a: this.hsl.a
    });
  }
  contrast(t, n) {
    t = W.create(t || "#000"), n = W.create(n || "#fff");
    const r = Math.abs(t.luma() - this.luma()), o = Math.abs(n.luma() - this.luma());
    return r > o ? t : n;
  }
  analagous() {
    return [
      this,
      this.hue(this.hue() - 1 / 12),
      this.hue(this.hue() + 1 / 12)
    ];
  }
  tetrad() {
    const t = this.hue();
    return [
      this,
      this.hue(t + 1 / 4),
      this.hue(t + 2 / 4),
      this.hue(t + 3 / 4)
    ];
  }
  rectTetrad() {
    return [
      this,
      this.hue(this.hue() + 1 / 6),
      this.hue(this.hue() + 3 / 6),
      this.hue(this.hue() + 4 / 6)
    ];
  }
  triad() {
    return [
      this,
      this.hue(this.hue() - 1 / 3),
      this.hue(this.hue() + 1 / 3)
    ];
  }
  splitComplementary() {
    return [
      this,
      this.hue(this.hue() - 5 / 12),
      this.hue(this.hue() + 5 / 12)
    ];
  }
  blend(t, n) {
    typeof n > "u" && (n = 0.5);
    const r = 1 - n;
    return t = W.create(t), new W({
      type: "rgba",
      r: Math.floor(this.red() * r + t.red() * n),
      g: Math.floor(this.green() * r + t.green() * n),
      b: Math.floor(this.blue() * r + t.blue() * n)
    });
  }
  toString() {
    return this.toHexString();
  }
  toHexString() {
    return B0(this.rgb);
  }
  toRGBString() {
    return j0(this.rgb);
  }
  toHSLString() {
    return A0(this.hsl);
  }
};
W.swatches = Ra;
let qi = W;
const ir = qi.create, V0 = 14, oo = (e, t) => {
  const n = ir(t), r = n.opacity(), o = n.opacity(1);
  return ir(e).blend(o, r).toRGBString();
};
function Q0(e) {
  return {
    flex: 1,
    padding: "0.3em",
    display: "inline-block",
    textAlign: "center",
    fontSize: "1.4em",
    background: e.backgroundSecondary,
    borderRadius: "0.2em 0.2em 0 0",
    color: e.accent,
    ":hover": {
      textShadow: `0 0 0.3em ${e.glow}`
    }
  };
}
const G0 = (e) => {
  const t = oo(e.colors.wallpaper, e.colors.backgroundPrimary), n = oo(e.colors.wallpaper, e.colors.backgroundSecondary), r = ir(e.colors.backgroundPrimary), o = ir(e.colors.backgroundSecondary), l = ir(e.colors.danger ?? "red"), i = r.blend(l, 0.5).opacity(r.opacity()).toRGBString(), s = o.blend(l, 0.5).opacity(o.opacity()).toRGBString(), u = oo(e.colors.wallpaper, i), a = oo(e.colors.wallpaper, s), d = e.colors.controlBorder ?? e.colors.text;
  return {
    ...e,
    largeSheetRootStyle: {
      backgroundSize: "cover",
      backgroundPosition: "center",
      ...e.largeSheetRootStyle
    },
    smallSheetRootStyle: e.smallSheetRootStyle ?? e.largeSheetRootStyle,
    tabActiveStyle: e.tabActiveStyle || {
      background: e.colors.backgroundPrimary,
      ":hover": {
        textShadow: "none"
      }
    },
    tabStyle: e.tabStyle || Q0(e.colors),
    tabSpacerStyle: e.tabSpacerStyle ?? {
      width: "0.5em"
    },
    panelStylePrimary: e.panelStylePrimary || {
      backgroundColor: e.colors.backgroundPrimary
    },
    tabContentStyle: e.tabContentStyle || {
      backgroundColor: e.colors.backgroundPrimary
    },
    panelStyleSecondary: e.panelStyleSecondary || e.panelStylePrimary || {
      backgroundColor: e.colors.backgroundSecondary
    },
    colors: {
      ...e.colors,
      bgOpaquePrimary: t,
      bgOpaqueSecondary: n,
      bgTransDangerPrimary: i,
      bgTransDangerSecondary: s,
      bgOpaqueDangerPrimary: u,
      bgOpaqueDangerSecondary: a,
      controlBorder: d,
      danger: l.toString()
    },
    logo: {
      ...e.logo,
      fontScaleFactor: e.logo.fontScaleFactor ?? V0
    }
  };
}, jt = {
  accent: "#8f4927",
  accentContrast: "white",
  glow: "#db9c7e",
  wallpaper: "#ddd",
  backgroundSecondary: "rgba(255,255,255,0.2)",
  backgroundPrimary: "rgba(255,255,255,0.5)",
  backgroundButton: "rgba(0,0,0,0.1)",
  text: "#433"
}, xd = "#000000", Y0 = `${xd}17`, K0 = `${xd}00`, Ed = G0({
  schemaVersion: "v1",
  displayName: "Teal of Cthulhu",
  global: `
    @import url('https://fonts.googleapis.com/css2?family=Love+Ya+Like+A+Sister&display=swap');
    ${_a.importStatement}
  `,
  largeSheetRootStyle: {
    backgroundImage: `url(systems/${Nr}/assets/wallpaper/marjanblan-5Ft4NWTmeJE-unsplash.webp)`
  },
  bodyFont: _a.fontFamily,
  displayFont: "normal normal normal 1em 'Averia Libre', serif",
  logo: {
    frontTextElementStyle: {
      background: "linear-gradient(135deg, #efb183 0%,#222 30%,#efb183 90%)",
      backgroundClip: "text"
    },
    rearTextElementStyle: {
      textShadow: "2px 0px 1px black, 6px 0px 4px rgba(0,0,0,0.5), -1px 0px 0px rgba(255,255,255,0.5)"
    },
    textElementsStyle: {
      transform: "rotateY(-30deg) rotateZ(-1deg) translateX(-5%)"
    },
    backdropStyle: {
      perspective: "500px",
      perspectiveOrigin: "50% 50%",
      backgroundImage: "radial-gradient(closest-side, rgba(255,255,255,0.7) 0%, rgba(255,255,255,0) 100%)"
    }
  },
  tabActiveStyle: {
    background: jt.backgroundPrimary,
    ":hover": {
      textShadow: "none"
    },
    borderStyle: "solid solid none solid"
  },
  tabStyle: {
    flex: 1,
    padding: "0.3em",
    display: "inline-block",
    textAlign: "center",
    fontSize: "1.4em",
    background: jt.backgroundSecondary,
    borderRadius: "0.5em 0.5em 0 0",
    color: jt.accent,
    ":hover": {
      textShadow: `0 0 0.3em ${jt.glow}`
    },
    borderWidth: "1px",
    borderStyle: "solid solid solid solid",
    borderColor: "#0007",
    backgroundImage: `linear-gradient(to top, ${Y0} 0%, ${K0} 15%)`
  },
  tabSpacerStyle: {
    width: "0.5em",
    borderWidth: "1px",
    borderStyle: "none none solid none",
    borderColor: "#0007"
  },
  panelStylePrimary: {
    backgroundColor: jt.backgroundPrimary,
    borderWidth: "1px",
    borderStyle: "none solid solid solid",
    borderColor: "#0007"
  },
  tabContentStyle: {
    backgroundColor: jt.backgroundPrimary,
    borderWidth: "1px",
    borderStyle: "none solid solid solid",
    borderColor: "#0007"
  },
  colors: jt
}), $n = ut.createContext(Ed);
class X0 extends ut.Component {
  constructor(t) {
    super(t), this.state = {
      error: void 0
    };
  }
  static getDerivedStateFromError(t) {
    return {
      error: t
    };
  }
  componentDidCatch(t, n) {
    Ko.error(t, n.componentStack);
  }
  render() {
    return this.state.error ? /* @__PURE__ */ D("div", {
      css: {
        ...On,
        padding: "1em",
        backgroundColor: "#222",
        color: "#eee",
        overflow: "auto"
      },
      children: [
        /* @__PURE__ */ k("h1", {
          children: "Alas! Something went wrong 😔"
        }),
        /* @__PURE__ */ D("p", {
          children: [
            "If this continues to happen, please drop into the",
            " ",
            /* @__PURE__ */ k("a", {
              href: "https://discord.com/channels/692113540210753568/720741108937916518",
              children: "virtual_tabletops channel on the Pelgrane Press Discord server"
            }),
            " ",
            "and let us know."
          ]
        }),
        /* @__PURE__ */ D("p", {
          children: [
            "Alternatively, you can",
            " ",
            /* @__PURE__ */ k("a", {
              href: "https://github.com/n3dst4/investigator-fvtt/issues",
              children: "log an issue on GitHub"
            }),
            " ",
            "."
          ]
        }),
        /* @__PURE__ */ k("h2", {
          children: "Details"
        }),
        /* @__PURE__ */ k("pre", {
          children: /* @__PURE__ */ k("code", {
            children: this.state.error.message
          })
        })
      ]
    }) : this.props.children;
  }
}
const Z0 = ({ className: e, children: t, theme: n, mode: r, noStyleAppWindow: o = !1 }) => {
  var p;
  const l = y.useRef(null);
  y.useEffect(() => {
    const h = /* @__PURE__ */ $0(n.appWindowStyle, "label:className");
    if (l.current !== null && !o) {
      const g = jQuery(l.current).closest(".window-app");
      return g.addClass(h), function() {
        g.removeClass(h);
      };
    }
  }, [
    o,
    n.appWindowStyle
  ]);
  const i = y.useContext(wd), [s, u] = y.useState((p = i == null ? void 0 : i.element.get(0)) == null ? void 0 : p.closest("head"));
  y.useEffect(() => {
    const h = (v, w) => {
      v.appId === (i == null ? void 0 : i.appId) && u(w.document.head);
    }, g = (v, w) => {
      v.appId === (i == null ? void 0 : i.appId) && u(w.window.document.head);
    };
    return Hooks.on("PopOut:popout", h), Hooks.on("PopOut:dialog", g), () => {
      Hooks.off("PopOut:popout", h), Hooks.off("PopOut:dialog", g);
    };
  }, [
    i == null ? void 0 : i.appId
  ]);
  const a = y.useMemo(() => as({
    key: "investigator",
    container: s ?? void 0
  }), [
    s
  ]), d = r === "large" ? n.largeSheetRootStyle : r === "small" ? n.smallSheetRootStyle : {};
  return /* @__PURE__ */ k(X0, {
    children: /* @__PURE__ */ k(Sh, {
      value: a,
      children: /* @__PURE__ */ D($n.Provider, {
        value: n,
        children: [
          /* @__PURE__ */ k(D0, {
            styles: [
              n.global
            ]
          }),
          /* @__PURE__ */ k("div", {
            ref: l,
            className: e,
            css: {
              font: n.bodyFont,
              padding: r === "none" ? "0" : "0.5em",
              color: n.colors.text,
              backgroundColor: r === "none" ? "transparent" : n.colors.wallpaper,
              height: "100%",
              accentColor: n.colors.accent,
              "*": {
                // all: "initial",
                scrollbarWidth: "thin",
                userSelect: "auto",
                boxSizing: "border-box",
                scrollbarColor: `${n.colors.accent} ${n.colors.backgroundButton}`,
                "&:focus": {
                  textDecoration: "underline"
                }
              },
              "h1, h2, h3, h4": {
                border: "none",
                margin: "0.3em 0 0 0",
                marginBottom: "0.3em",
                padding: 0,
                fontWeight: "inherit",
                font: n.displayFont
              },
              h1: {
                fontSize: "1.5em"
              },
              h2: {
                fontSize: "1.3em"
              },
              h3: {
                fontSize: "1.1em"
              },
              h4: {
                fontSize: "1em"
              },
              // fix specificity. The comma causes this to be intgerpreted as a
              // new selector, i.e. it comes out as
              // .abc123, :where(.abc123) button { ... }
              // the :where makes this the same specificity as a regular style
              ",:where(&) button": {
                font: n.displayFont,
                color: n.colors.accent,
                "&[disabled]": {
                  opacity: 0.5,
                  color: n.colors.text,
                  "&:hover": {
                    boxShadow: "none",
                    textShadow: "none"
                  }
                },
                "&:hover": {
                  boxShadow: `0 0 0.5em ${n.colors.glow}`,
                  textShadow: `0 0 0.5em ${n.colors.glow}`
                },
                "&:focus": {
                  boxShadow: "none"
                }
              },
              label: {
                fontWeight: "bold"
              },
              "a, label.parp": {
                color: n.colors.accent
              },
              "a:hover, a.hover, .hover a, label.parp:hover, label.parp.hover, .hover label.parp": {
                textDecoration: "underline",
                textShadow: `0 0 0.5em ${n.colors.glow}`
              },
              "input, input[type=text], textarea, select, option": {
                font: n.bodyFont,
                fontVariantLigatures: "none",
                color: n.colors.accent,
                padding: "0.1em 0.3em",
                borderStyle: "solid",
                borderWidth: "1px",
                borderColor: n.colors.controlBorder,
                background: n.colors.backgroundPrimary,
                resize: "vertical",
                ":focus": {
                  borderColor: n.colors.accent,
                  outline: "none",
                  boxShadow: `0 0 0.5em ${n.colors.glow} inset`
                },
                "&:hover": {
                  borderStyle: "solid",
                  borderWidth: "1px",
                  borderColor: n.colors.controlBorder
                }
              },
              select: {
                color: n.colors.text,
                background: n.colors.bgOpaqueSecondary,
                option: {
                  background: n.colors.bgOpaquePrimary,
                  color: n.colors.text
                },
                ":focus": {
                  borderColor: n.colors.accent,
                  outline: "none",
                  boxShadow: `0 0 0.5em ${n.colors.glow}`
                }
              },
              textarea: {
                lineHeight: 1
              },
              "button, input[type=button]": {
                border: `2px groove ${n.colors.controlBorder}`,
                background: n.colors.backgroundButton
              },
              hr: {
                borderColor: n.colors.controlBorder
              },
              "i.fa:last-child": {
                margin: 0
              },
              ...d
            },
            children: t
          })
        ]
      })
    })
  });
};
function J0() {
  Co(game);
  const e = game.modules.get("vtta-tokenizer"), t = (e == null ? void 0 : e.active) ?? !1, n = e == null ? void 0 : e.api;
  return {
    tokenizerIsActive: t,
    tokenizerApi: n
  };
}
const Oa = ({ onClick: e, children: t }) => {
  const n = y.useContext($n), r = y.useCallback((o) => {
    o.stopPropagation(), e();
  }, [
    e
  ]);
  return /* @__PURE__ */ k("a", {
    onClick: r,
    css: {
      backgroundColor: n.colors.bgOpaquePrimary,
      padding: "0 0.5em",
      borderRadius: "0.5em",
      font: n.displayFont,
      transition: "background-color 0.2s",
      ":hover": {
        backgroundColor: n.colors.backgroundPrimary
      }
    },
    children: t
  });
}, ri = {
  position: "absolute",
  top: 0,
  bottom: 0,
  left: 0,
  right: 0
}, $a = "0.3s", q0 = ({ subject: e, application: t, className: n }) => {
  const [r, o] = y.useState(!1), l = y.useContext($n);
  Co(game);
  const i = game.user, u = (i ? e.getUserLevel(i) ?? 0 : 0) >= CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER, a = y.useCallback(() => {
    o(!1), Co(game);
    const { tokenizerIsActive: g, tokenizerApi: v } = J0(), w = e instanceof Actor;
    if (g && v !== void 0 && w)
      v.tokenizeActor(e);
    else
      return new FilePicker({
        type: "image",
        current: e.img ?? void 0,
        callback: (f) => {
          e.update({
            img: f
          });
        },
        top: (t.position.top ?? 0) + 40,
        left: (t.position.left ?? 0) + 10
      }).browse(e.img ?? "");
  }, [
    t.position.left,
    t.position.top,
    e
  ]), d = y.useCallback(() => {
    new ImagePopout(e.img ?? "", {
      title: e.img,
      shareable: !0
    }).render(!0);
  }, [
    e.img
  ]), p = y.useCallback(() => {
    o(!1), d();
  }, [
    d
  ]), h = y.useCallback((g) => {
    if (g.stopPropagation(), u) {
      o(!0);
      const v = () => {
        o(!1);
      };
      return document.addEventListener("click", v), () => {
        document.removeEventListener("click", v);
      };
    } else
      d();
  }, [
    u,
    d
  ]);
  return /* @__PURE__ */ D("div", {
    className: n,
    css: {
      borderRadius: "0.2em",
      boxShadow: "0em 0em 0.5em 0.1em rgba(0,0,0,0.5)",
      position: "relative"
    },
    onClick: (g) => h(g),
    children: [
      /* @__PURE__ */ k("div", {
        css: {
          ...ri,
          overflow: "hidden"
        },
        children: /* @__PURE__ */ k("div", {
          css: {
            ...ri,
            backgroundImage: `url("${e.img}")`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            filter: r ? "blur(0.7em)" : void 0,
            transition: `filter ${$a} ease-in`
          }
        })
      }),
      /* @__PURE__ */ k("div", {
        css: {
          ...ri,
          opacity: r ? 1 : 0,
          transition: `opacity ${$a} ease-in`,
          background: l.colors.backgroundSecondary,
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-around",
          alignItems: "center"
        },
        children: r && /* @__PURE__ */ D(y.Fragment, {
          children: [
            /* @__PURE__ */ k(Oa, {
              onClick: p,
              children: "Show"
            }),
            /* @__PURE__ */ k(Oa, {
              onClick: a,
              children: "Edit"
            })
          ]
        })
      })
    ]
  });
}, $r = ({ children: e, className: t }) => /* @__PURE__ */ k("div", {
  className: t,
  css: {
    position: "relative",
    border: "1px solid #0007",
    padding: "0.5em",
    backgroundColor: "#fff6"
  },
  children: e
});
$r.displayName = "Panel";
const Pd = ({ actor: e, className: t }) => /* @__PURE__ */ D($r, {
  className: t,
  css: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    padding: "0",
    font: Sd.fontFamily
  },
  children: [
    /* @__PURE__ */ k("div", {
      css: {
        fontSize: "7em",
        lineHeight: "1"
      },
      children: e.system.drinks.length
    }),
    /* @__PURE__ */ k("div", {
      css: {
        transform: "translateY(-0.5em)",
        fontSize: "2em"
      },
      children: e.system.drinks.length === 1 ? "Drink" : "Drinks"
    })
  ]
});
Pd.displayName = "DrinksCounter";
const _d = (e, t) => {
  const [n, r] = y.useState(e || ""), o = y.useRef(!1), l = y.useCallback(() => {
    o.current = !0;
  }, []), i = y.useCallback(() => {
    o.current = !1;
  }, []), s = y.useMemo(() => tp(t, ep), [
    t
  ]), u = y.useCallback((p) => {
    r(p), s(p);
  }, [
    s
  ]), a = y.useRef(null), d = y.useCallback((p) => {
    const h = p.currentTarget.innerText;
    u(h);
  }, [
    u
  ]);
  return y.useEffect(() => {
    o.current || (r(e), a.current && (a.current.innerText = e));
  }, [
    e
  ]), {
    onChange: u,
    onFocus: l,
    onBlur: i,
    display: n,
    contentEditableRef: a,
    onInput: d
  };
}, Nd = ut.createContext(void 0), Td = ({ className: e, value: t, defaultValue: n, onChange: r, onFocus: o, onBlur: l, disabled: i, placeholder: s, validation: u }) => {
  const a = y.useContext(Nd), d = y.useCallback((g) => {
    r == null || r(g.currentTarget.value);
  }, [
    r
  ]), h = y.useContext($n).colors.bgTransDangerPrimary;
  return /* @__PURE__ */ k("input", {
    role: "text-input",
    size: 3,
    id: a,
    css: {
      flex: 1,
      width: "100%",
      "::placeholder": {
        opacity: 0.5,
        fontStyle: "italic"
      }
    },
    style: {
      backgroundColor: (u == null ? void 0 : u.state) === "failed" ? h : void 0
    },
    className: O0(e, (u == null ? void 0 : u.state) === "failed" && "error"),
    "data-lpignore": "true",
    value: t,
    defaultValue: n,
    onChange: d,
    onFocus: o,
    onBlur: l,
    disabled: i,
    placeholder: s
  });
}, Da = (e, t, n, r) => {
  let o = Number(e) + t;
  return Number.isNaN(o) && (o = 0), r !== void 0 && (o = Math.min(r, o)), n !== void 0 && (o = Math.max(n, o)), o.toString();
}, eg = ({ value: e, onChange: t, className: n, min: r, max: o, disabled: l, noPlusMinus: i = !1, smallButtons: s = !1 }) => {
  const u = y.useCallback((f) => {
    const c = Number(f);
    return Number.isNaN(c) ? {
      state: "failed",
      reasons: [
        "Not a number"
      ]
    } : r !== void 0 && c < r ? {
      state: "failed",
      reasons: [
        "Too low"
      ]
    } : o !== void 0 && c > o ? {
      state: "failed",
      reasons: [
        "Too high"
      ]
    } : {
      state: "succeeded",
      value: c
    };
  }, [
    o,
    r
  ]), a = y.useCallback((f) => {
    const c = u(f);
    c.state === "succeeded" && t(c.value);
  }, [
    t,
    u
  ]), { display: d, onBlur: p, onChange: h, onFocus: g } = _d((e || 0).toString(), a), v = y.useCallback((f) => {
    f.preventDefault(), h(Da(d, 1, r, o));
  }, [
    d,
    o,
    r,
    h
  ]), w = y.useCallback((f) => {
    f.preventDefault(), h(Da(d, -1, r, o));
  }, [
    d,
    o,
    r,
    h
  ]), R = u(d);
  return /* @__PURE__ */ D("div", {
    css: {
      display: "flex",
      flexDirection: "row",
      button: {
        lineHeight: "inherit",
        flexBasis: "min-content",
        flex: 0,
        padding: "0 0.25em",
        fontSize: s ? "0.6em" : void 0
      }
    },
    className: n,
    children: [
      (i === void 0 || !i) && /* @__PURE__ */ k("button", {
        onClick: w,
        disabled: l,
        children: /* @__PURE__ */ k("i", {
          className: "fa fa-minus"
        })
      }),
      (i === void 0 || !i) && /* @__PURE__ */ k("button", {
        onClick: v,
        disabled: l,
        children: /* @__PURE__ */ k("i", {
          className: "fa fa-plus"
        })
      }),
      /* @__PURE__ */ k(Td, {
        validation: R,
        css: {
          flex: 1,
          flexBasis: "min-content",
          userSelect: "text"
        },
        value: d,
        onChange: h,
        onFocus: g,
        onBlur: p,
        disabled: l
      })
    ]
  });
}, Dr = ({ children: e, onClick: t, className: n, ...r }) => /* @__PURE__ */ k("button", {
  ...r,
  className: n,
  css: {
    width: "max-content"
  },
  onClick: (l) => {
    l.preventDefault(), t();
  },
  children: e
}), es = ({ title: e, description: t, actor: n, lowOrHigh: r, className: o }) => {
  const [l, i] = ut.useState(0), [s, u] = ut.useState(!1), a = ut.useCallback((p) => {
    u(p.target.value === "true");
  }, [
    u
  ]), d = ut.useCallback(() => {
    console.log("roll"), n.roll(l, s, r), i(0), u(!1);
  }, [
    n,
    r,
    l,
    s
  ]);
  return /* @__PURE__ */ D($r, {
    className: o,
    css: {
      textAlign: "center"
    },
    children: [
      /* @__PURE__ */ k("h2", {
        css: {
          "&&": {
            marginBottom: "0em"
          }
        },
        children: e
      }),
      /* @__PURE__ */ k("div", {
        css: {
          fontSize: "0.8em",
          marginBottom: "0.5em"
        },
        children: t
      }),
      /* @__PURE__ */ D("div", {
        css: {
          display: "flex",
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "center",
          marginBottom: "0.5em"
        },
        children: [
          /* @__PURE__ */ k("span", {
            css: {
              marginRight: "0.5em"
            },
            children: "Modifier"
          }),
          " ",
          /* @__PURE__ */ k(eg, {
            value: l,
            onChange: i
          })
        ]
      }),
      /* @__PURE__ */ D("div", {
        css: {
          marginBottom: "0.5em"
        },
        children: [
          /* @__PURE__ */ D("select", {
            value: s ? "true" : "false",
            onChange: a,
            children: [
              /* @__PURE__ */ k("option", {
                value: "false",
                children: "Standard: d8"
              }),
              /* @__PURE__ */ D("option", {
                value: "true",
                children: [
                  "Title die: ",
                  n.system.titleDie
                ]
              })
            ]
          }),
          " "
        ]
      }),
      /* @__PURE__ */ k("div", {
        children: /* @__PURE__ */ k(Dr, {
          onClick: d,
          children: "Roll"
        })
      })
    ]
  });
};
es.displayName = "Roll";
const tg = "useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict";
let Yo = (e = 21) => {
  let t = "", n = crypto.getRandomValues(new Uint8Array(e));
  for (; e--; )
    t += tg[n[e] & 63];
  return t;
};
const ng = ({ tabs: e, defaultTab: t }) => {
  const [n, r] = y.useState(t), [o, l] = y.useState(t), [i, s] = y.useTransition(), u = y.useMemo(() => e.filter((g) => !!g), [
    e
  ]), a = y.useMemo(() => u.find((g) => g.id === n), [
    n,
    u
  ]), d = y.useCallback((g) => {
    l(g.currentTarget.value), s(() => {
      r(g.currentTarget.value);
    });
  }, []), p = y.useContext($n), h = y.useMemo(Yo, []);
  return /* @__PURE__ */ D("div", {
    className: "tab-container-outer",
    css: {
      position: "absolute",
      top: 0,
      right: 0,
      bottom: 0,
      left: 0,
      display: "flex",
      flexDirection: "column",
      ".tab-strip": {
        display: "flex",
        flexDirection: "row"
      },
      "input[type=radio]": {
        display: "none",
        "+label": p.tabStyle,
        "&:checked+label": p.tabActiveStyle,
        "&[disabled]+label": {
          opacity: 0.3,
          ":hover": {
            textShadow: "none"
          }
        }
      }
    },
    children: [
      /* @__PURE__ */ k("div", {
        className: "tab-strip",
        children: u.map(({ id: g, label: v, translate: w = !0 }, R) => {
          const f = Yo();
          return /* @__PURE__ */ D(y.Fragment, {
            children: [
              /* @__PURE__ */ k("input", {
                name: h,
                id: f,
                type: "radio",
                value: g,
                checked: g === n,
                onChange: d
              }),
              /* @__PURE__ */ k("label", {
                htmlFor: f,
                tabIndex: 0,
                className: p.tabClass,
                css: {
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "center",
                  opacity: i && g === o ? 0.5 : 1,
                  "&&": {
                    font: p.displayFont
                  }
                },
                children: v
              }),
              R < u.length - 1 && /* @__PURE__ */ k("div", {
                css: p.tabSpacerStyle
              })
            ]
          }, g);
        })
      }),
      /* @__PURE__ */ k("div", {
        className: `tab-content ${p.panelClass ?? ""}`,
        css: {
          flex: 1,
          position: "relative",
          overflow: "auto",
          padding: "0.5em",
          ...p.tabContentStyle
        },
        children: a == null ? void 0 : a.content
      })
    ]
  }, n);
}, st = ({ value: e = "", onChange: t, className: n, disabled: r, placeholder: o, index: l }) => {
  const { onChange: i, onFocus: s, onBlur: u, display: a } = _d(e, t);
  return /* @__PURE__ */ k(Td, {
    className: n,
    value: a,
    onChange: i,
    onFocus: s,
    onBlur: u,
    disabled: r,
    placeholder: o
  });
}, Rd = ({ message: e, confirmText: t, cancelText: n, confirmIconClass: r }) => (Co(game), new Promise((l) => {
  const i = () => {
    l(!0);
  }, s = () => {
    l(!1);
  };
  new Dialog({
    title: "Confirm",
    content: `<p>${e}</p>`,
    buttons: {
      cancel: {
        icon: '<i class="fas fa-ban"></i>',
        label: n,
        callback: s
      },
      confirm: {
        icon: `<i class="fas ${r}"></i>`,
        label: t,
        callback: i
      }
    },
    default: "cancel"
  }).render(!0);
})), zd = ({ actor: e, id: t }) => {
  const n = e.system.conditions.find(({ id: l }) => l === t);
  if (n === void 0)
    throw new Error("invalid condition id");
  const r = y.useCallback((l) => {
    e.setCondition(t, l);
  }, [
    e,
    t
  ]), o = y.useCallback(async () => {
    await Rd({
      message: `Are you sure you want to delete "${n.name || "(blank)"}"?`,
      confirmText: "Yes",
      cancelText: "No",
      confirmIconClass: "fa-trash"
    }) && e.deleteCondition(t);
  }, [
    e,
    n.name,
    t
  ]);
  return /* @__PURE__ */ k(y.Fragment, {
    children: /* @__PURE__ */ D("div", {
      css: {
        gridColumn: "span 3",
        display: "flex",
        flexDirection: "row",
        gap: "0.3em"
      },
      children: [
        /* @__PURE__ */ k(st, {
          value: n.name,
          onChange: r
        }),
        /* @__PURE__ */ k(Dr, {
          onClick: o,
          children: "Delete"
        })
      ]
    })
  });
};
zd.displayName = "ConditionsRow";
const Ld = ({ selector: e = "input[role=text-input]" } = {}) => {
  const t = y.useRef(null), [n, r] = y.useState(!1), o = y.useCallback(() => {
    r(!0);
  }, []);
  return y.useEffect(() => {
    var l;
    if (n) {
      r(!1);
      const i = (l = t.current) == null ? void 0 : l.querySelectorAll(e), s = i == null ? void 0 : i[i.length - 1];
      s == null || s.scrollIntoView({
        behavior: "smooth"
      }), setTimeout(() => {
        s == null || s.focus();
      }, 200);
    }
  }, [
    e,
    n
  ]), {
    scrollerRef: t,
    triggerScroll: o
  };
}, Md = ({ actor: e, className: t }) => {
  const { scrollerRef: n, triggerScroll: r } = Ld(), o = y.useCallback(async () => {
    await e.addCondition(), r();
  }, [
    e,
    r
  ]);
  return /* @__PURE__ */ D("div", {
    className: t,
    css: {
      ...On,
      display: "grid",
      gridTemplateColumns: "1fr",
      gridTemplateRows: "[rows] auto [button] min-content",
      alignContent: "start",
      rowGap: "0.5em",
      columnGap: "0.2em",
      padding: "0.5em"
    },
    children: [
      e.system.conditions.length === 0 && /* @__PURE__ */ k("div", {
        css: {
          gridColumn: "1 / -1",
          gridRow: "rows",
          justifySelf: "center"
        },
        children: "No conditions yet. Give it some time."
      }),
      e.system.conditions.length > 0 && /* @__PURE__ */ k("div", {
        ref: n,
        css: {
          gridColumn: "1 / -1",
          gridRow: "rows",
          display: "grid",
          gridTemplateColumns: "subgrid",
          overflowY: "scroll",
          alignContent: "start",
          rowGap: "0.3em"
        },
        children: e.system.conditions.map(({ id: l }) => /* @__PURE__ */ k(zd, {
          actor: e,
          id: l
        }, l))
      }),
      /* @__PURE__ */ k("div", {
        css: {
          gridColumn: "1 / -1",
          gridRow: "button",
          justifySelf: "center"
        },
        children: /* @__PURE__ */ k(Dr, {
          onClick: o,
          children: "Add condition"
        })
      })
    ]
  });
};
Md.displayName = "ConditionsList";
const Od = ({ actor: e, id: t }) => {
  const n = e.system.drinks.find(({ id: i }) => i === t);
  if (n === void 0)
    throw new Error("invalid drink id");
  const r = y.useCallback((i) => {
    e.setDrinkWhat(t, i);
  }, [
    e,
    t
  ]), o = y.useCallback((i) => {
    e.setDrinkWhere(t, i);
  }, [
    e,
    t
  ]), l = y.useCallback(async () => {
    await Rd({
      message: `Delete the ${n.what || "(blank)"} that you drank at ${n.where || "(blank)"}?`,
      confirmText: "Yes",
      cancelText: "No",
      confirmIconClass: "fa-trash"
    }) && e.deleteDrink(t);
  }, [
    e,
    n.what,
    n.where,
    t
  ]);
  return /* @__PURE__ */ D(y.Fragment, {
    children: [
      /* @__PURE__ */ k("div", {
        css: {
          gridColumn: "1"
        },
        children: /* @__PURE__ */ k(st, {
          className: "drink-what",
          value: n.what,
          onChange: r
        })
      }),
      /* @__PURE__ */ D("div", {
        css: {
          gridColumn: "2",
          display: "flex",
          flexDirection: "row",
          gap: "0.3em"
        },
        children: [
          /* @__PURE__ */ k(st, {
            value: n.where,
            onChange: o
          }),
          /* @__PURE__ */ k(Dr, {
            onClick: l,
            children: "Delete"
          })
        ]
      })
    ]
  });
};
Od.displayName = "DrinksRow";
const $d = ({ actor: e, className: t }) => {
  const { scrollerRef: n, triggerScroll: r } = Ld({
    selector: ".drink-what"
  }), o = y.useCallback(async () => {
    await e.addDrink(), r();
  }, [
    e,
    r
  ]);
  return /* @__PURE__ */ D("div", {
    className: t,
    css: {
      ...On,
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gridTemplateRows: "[headers] min-content [rows] auto [button] min-content",
      alignContent: "start",
      rowGap: "0.5em",
      columnGap: "0.3em",
      overflow: "hidden",
      padding: "0.5em"
    },
    children: [
      /* @__PURE__ */ k("h2", {
        css: {
          gridColumn: "1",
          gridRow: "headers",
          "&&": {
            margin: 0
          }
        },
        children: "What"
      }),
      /* @__PURE__ */ k("h2", {
        css: {
          gridColumn: "2",
          gridRow: "headers",
          "&&": {
            margin: 0
          }
        },
        children: "Where"
      }),
      e.system.drinks.length === 0 && /* @__PURE__ */ k("div", {
        css: {
          gridColumn: "1 / -1",
          gridRow: "rows",
          justifySelf: "center"
        },
        children: "No drinks yet... you're alarmingly sober."
      }),
      e.system.drinks.length > 0 && /* @__PURE__ */ k("div", {
        ref: n,
        css: {
          gridColumn: "1 / -1",
          gridRow: "rows",
          display: "grid",
          gridTemplateColumns: "subgrid",
          overflowY: "scroll",
          alignContent: "start",
          rowGap: "0.5em"
        },
        children: e.system.drinks.map(({ id: l }) => /* @__PURE__ */ k(Od, {
          actor: e,
          id: l
        }, l))
      }),
      /* @__PURE__ */ k("div", {
        css: {
          gridColumn: "1 / -1",
          gridRow: "button",
          justifySelf: "center"
        },
        children: /* @__PURE__ */ k(Dr, {
          disabled: e.system.drinks.length >= 900,
          onClick: o,
          children: "Drink a drink"
        })
      })
    ]
  });
};
$d.displayName = "DrinksList";
const rg = ({ value: e, className: t, onSave: n, onChange: r }) => {
  const o = y.useCallback(async () => {
    await rp(500), n();
  }, [
    n
  ]), l = y.useRef(null), [i] = y.useState(e);
  return y.useEffect(() => {
    let s = null;
    if (l.current)
      return TextEditor.create({
        target: l.current,
        save_onsavecallback: o,
        height: "100%"
      }, i).then((u) => (u.on("change", () => {
        const a = u.getContent();
        r(a);
      }), u)).then((u) => {
        s = u;
      }), () => {
        s && s.destroy();
      };
  }, [
    i,
    o,
    r
  ]), /* @__PURE__ */ k("form", {
    css: {
      ...On,
      backgroundColor: "white"
    },
    className: t,
    children: /* @__PURE__ */ k("textarea", {
      ref: l,
      css: {
        height: "100%"
      }
    })
  });
}, Dd = ({ actor: e, className: t }) => {
  const [n, r] = y.useState(!1), o = y.useRef(e.system.notes), l = async () => {
    await e.setNotes(o.current), r(!1);
  }, i = () => {
    o.current = e.system.notes, r(!0);
  }, s = (u) => {
    o.current = u;
  };
  return /* @__PURE__ */ D("div", {
    className: t,
    css: {
      ...On,
      display: "flex",
      flexDirection: "column",
      padding: "0.5em"
    },
    children: [
      !n && /* @__PURE__ */ D(Eh, {
        children: [
          /* @__PURE__ */ D("h2", {
            css: {
              position: "sticky",
              top: 0
            },
            children: [
              "Notes ",
              /* @__PURE__ */ k("a", {
                onClick: i,
                children: "Edit"
              })
            ]
          }),
          /* @__PURE__ */ k("div", {
            css: {
              flex: 1,
              overflowY: "scroll"
            },
            dangerouslySetInnerHTML: {
              __html: e.system.notes
            }
          })
        ]
      }),
      n && /* @__PURE__ */ k(rg, {
        value: e.system.notes,
        onChange: s,
        onSave: l
      })
    ]
  });
};
Dd.displayName = "Notes";
const Id = ({ actor: e, className: t }) => {
  const n = e.system.conditions.length;
  return /* @__PURE__ */ k(ng, {
    tabs: [
      {
        id: "drinks",
        label: "Drinks",
        content: /* @__PURE__ */ k($d, {
          actor: e
        })
      },
      {
        id: "conditions",
        label: `Conditions (${n})`,
        content: /* @__PURE__ */ k(Md, {
          actor: e
        })
      },
      {
        id: "notes",
        label: "Notes",
        content: /* @__PURE__ */ k(Dd, {
          actor: e
        })
      }
    ],
    defaultTab: "drinks"
  });
};
Id.displayName = "Tabs";
function og(e, t, { checkForDefaultPrevented: n = !0 } = {}) {
  return function(o) {
    if (e == null || e(o), n === !1 || !o.defaultPrevented)
      return t == null ? void 0 : t(o);
  };
}
function lg(e, t) {
  typeof e == "function" ? e(t) : e != null && (e.current = t);
}
function Fd(...e) {
  return (t) => e.forEach((n) => lg(n, t));
}
function ig(...e) {
  return y.useCallback(Fd(...e), e);
}
function sg(e, t = []) {
  let n = [];
  function r(l, i) {
    const s = y.createContext(i), u = n.length;
    n = [...n, i];
    function a(p) {
      const { scope: h, children: g, ...v } = p, w = (h == null ? void 0 : h[e][u]) || s, R = y.useMemo(() => v, Object.values(v));
      return /* @__PURE__ */ ge.jsx(w.Provider, { value: R, children: g });
    }
    function d(p, h) {
      const g = (h == null ? void 0 : h[e][u]) || s, v = y.useContext(g);
      if (v) return v;
      if (i !== void 0) return i;
      throw new Error(`\`${p}\` must be used within \`${l}\``);
    }
    return a.displayName = l + "Provider", [a, d];
  }
  const o = () => {
    const l = n.map((i) => y.createContext(i));
    return function(s) {
      const u = (s == null ? void 0 : s[e]) || l;
      return y.useMemo(
        () => ({ [`__scope${e}`]: { ...s, [e]: u } }),
        [s, u]
      );
    };
  };
  return o.scopeName = e, [r, ug(o, ...t)];
}
function ug(...e) {
  const t = e[0];
  if (e.length === 1) return t;
  const n = () => {
    const r = e.map((o) => ({
      useScope: o(),
      scopeName: o.scopeName
    }));
    return function(l) {
      const i = r.reduce((s, { useScope: u, scopeName: a }) => {
        const p = u(l)[`__scope${a}`];
        return { ...s, ...p };
      }, {});
      return y.useMemo(() => ({ [`__scope${t.scopeName}`]: i }), [i]);
    };
  };
  return n.scopeName = t.scopeName, n;
}
function Ad(e) {
  const t = y.useRef(e);
  return y.useEffect(() => {
    t.current = e;
  }), y.useMemo(() => (...n) => {
    var r;
    return (r = t.current) == null ? void 0 : r.call(t, ...n);
  }, []);
}
function ag({
  prop: e,
  defaultProp: t,
  onChange: n = () => {
  }
}) {
  const [r, o] = cg({ defaultProp: t, onChange: n }), l = e !== void 0, i = l ? e : r, s = Ad(n), u = y.useCallback(
    (a) => {
      if (l) {
        const p = typeof a == "function" ? a(e) : a;
        p !== e && s(p);
      } else
        o(a);
    },
    [l, e, o, s]
  );
  return [i, u];
}
function cg({
  defaultProp: e,
  onChange: t
}) {
  const n = y.useState(e), [r] = n, o = y.useRef(r), l = Ad(t);
  return y.useEffect(() => {
    o.current !== r && (l(r), o.current = r);
  }, [r, o, l]), n;
}
function fg(e) {
  const t = y.useRef({ value: e, previous: e });
  return y.useMemo(() => (t.current.value !== e && (t.current.previous = t.current.value, t.current.value = e), t.current.previous), [e]);
}
var dg = globalThis != null && globalThis.document ? y.useLayoutEffect : () => {
};
function pg(e) {
  const [t, n] = y.useState(void 0);
  return dg(() => {
    if (e) {
      n({ width: e.offsetWidth, height: e.offsetHeight });
      const r = new ResizeObserver((o) => {
        if (!Array.isArray(o) || !o.length)
          return;
        const l = o[0];
        let i, s;
        if ("borderBoxSize" in l) {
          const u = l.borderBoxSize, a = Array.isArray(u) ? u[0] : u;
          i = a.inlineSize, s = a.blockSize;
        } else
          i = e.offsetWidth, s = e.offsetHeight;
        n({ width: i, height: s });
      });
      return r.observe(e, { box: "border-box" }), () => r.unobserve(e);
    } else
      n(void 0);
  }, [e]), t;
}
var jd = y.forwardRef((e, t) => {
  const { children: n, ...r } = e, o = y.Children.toArray(n), l = o.find(mg);
  if (l) {
    const i = l.props.children, s = o.map((u) => u === l ? y.Children.count(i) > 1 ? y.Children.only(null) : y.isValidElement(i) ? i.props.children : null : u);
    return /* @__PURE__ */ ge.jsx(ts, { ...r, ref: t, children: y.isValidElement(i) ? y.cloneElement(i, void 0, s) : null });
  }
  return /* @__PURE__ */ ge.jsx(ts, { ...r, ref: t, children: n });
});
jd.displayName = "Slot";
var ts = y.forwardRef((e, t) => {
  const { children: n, ...r } = e;
  if (y.isValidElement(n)) {
    const o = yg(n);
    return y.cloneElement(n, {
      ...gg(r, n.props),
      // @ts-ignore
      ref: t ? Fd(t, o) : o
    });
  }
  return y.Children.count(n) > 1 ? y.Children.only(null) : null;
});
ts.displayName = "SlotClone";
var hg = ({ children: e }) => /* @__PURE__ */ ge.jsx(ge.Fragment, { children: e });
function mg(e) {
  return y.isValidElement(e) && e.type === hg;
}
function gg(e, t) {
  const n = { ...t };
  for (const r in t) {
    const o = e[r], l = t[r];
    /^on[A-Z]/.test(r) ? o && l ? n[r] = (...s) => {
      l(...s), o(...s);
    } : o && (n[r] = o) : r === "style" ? n[r] = { ...o, ...l } : r === "className" && (n[r] = [o, l].filter(Boolean).join(" "));
  }
  return { ...e, ...n };
}
function yg(e) {
  var r, o;
  let t = (r = Object.getOwnPropertyDescriptor(e.props, "ref")) == null ? void 0 : r.get, n = t && "isReactWarning" in t && t.isReactWarning;
  return n ? e.ref : (t = (o = Object.getOwnPropertyDescriptor(e, "ref")) == null ? void 0 : o.get, n = t && "isReactWarning" in t && t.isReactWarning, n ? e.props.ref : e.props.ref || e.ref);
}
var vg = [
  "a",
  "button",
  "div",
  "form",
  "h2",
  "h3",
  "img",
  "input",
  "label",
  "li",
  "nav",
  "ol",
  "p",
  "span",
  "svg",
  "ul"
], Bd = vg.reduce((e, t) => {
  const n = y.forwardRef((r, o) => {
    const { asChild: l, ...i } = r, s = l ? jd : t;
    return typeof window < "u" && (window[Symbol.for("radix-ui")] = !0), /* @__PURE__ */ ge.jsx(s, { ...i, ref: o });
  });
  return n.displayName = `Primitive.${t}`, { ...e, [t]: n };
}, {}), lu = "Switch", [wg, Og] = sg(lu), [kg, Sg] = wg(lu), bd = y.forwardRef(
  (e, t) => {
    const {
      __scopeSwitch: n,
      name: r,
      checked: o,
      defaultChecked: l,
      required: i,
      disabled: s,
      value: u = "on",
      onCheckedChange: a,
      ...d
    } = e, [p, h] = y.useState(null), g = ig(t, (c) => h(c)), v = y.useRef(!1), w = p ? !!p.closest("form") : !0, [R = !1, f] = ag({
      prop: o,
      defaultProp: l,
      onChange: a
    });
    return /* @__PURE__ */ ge.jsxs(kg, { scope: n, checked: R, disabled: s, children: [
      /* @__PURE__ */ ge.jsx(
        Bd.button,
        {
          type: "button",
          role: "switch",
          "aria-checked": R,
          "aria-required": i,
          "data-state": Hd(R),
          "data-disabled": s ? "" : void 0,
          disabled: s,
          value: u,
          ...d,
          ref: g,
          onClick: og(e.onClick, (c) => {
            f((m) => !m), w && (v.current = c.isPropagationStopped(), v.current || c.stopPropagation());
          })
        }
      ),
      w && /* @__PURE__ */ ge.jsx(
        Cg,
        {
          control: p,
          bubbles: !v.current,
          name: r,
          value: u,
          checked: R,
          required: i,
          disabled: s,
          style: { transform: "translateX(-100%)" }
        }
      )
    ] });
  }
);
bd.displayName = lu;
var Ud = "SwitchThumb", Wd = y.forwardRef(
  (e, t) => {
    const { __scopeSwitch: n, ...r } = e, o = Sg(Ud, n);
    return /* @__PURE__ */ ge.jsx(
      Bd.span,
      {
        "data-state": Hd(o.checked),
        "data-disabled": o.disabled ? "" : void 0,
        ...r,
        ref: t
      }
    );
  }
);
Wd.displayName = Ud;
var Cg = (e) => {
  const { control: t, checked: n, bubbles: r = !0, ...o } = e, l = y.useRef(null), i = fg(n), s = pg(t);
  return y.useEffect(() => {
    const u = l.current, a = window.HTMLInputElement.prototype, p = Object.getOwnPropertyDescriptor(a, "checked").set;
    if (i !== n && p) {
      const h = new Event("click", { bubbles: r });
      p.call(u, n), u.dispatchEvent(h);
    }
  }, [i, n, r]), /* @__PURE__ */ ge.jsx(
    "input",
    {
      type: "checkbox",
      "aria-hidden": !0,
      defaultChecked: n,
      ...o,
      tabIndex: -1,
      ref: l,
      style: {
        ...e.style,
        ...s,
        position: "absolute",
        pointerEvents: "none",
        opacity: 0,
        margin: 0
      }
    }
  );
};
function Hd(e) {
  return e ? "checked" : "unchecked";
}
var xg = bd, Eg = Wd;
const Ia = ({ checked: e, onChange: t, className: n }) => {
  const r = y.useContext(Nd), o = y.useContext($n);
  return /* @__PURE__ */ k(xg, {
    id: r,
    className: n,
    css: {
      fontSize: "0.9em",
      width: "3em",
      height: "1.5em",
      padding: 0,
      margin: 0,
      backgroundColor: o.colors.backgroundButton,
      borderRadius: "9999px",
      position: "relative",
      top: "0.1em",
      boxShadow: `0 0 2px 0 ${o.colors.text}`,
      "&:focus": {
        boxShadow: `0 0 4px 0 ${o.colors.text}`
      },
      "&[data-state='checked']": {
        backgroundColor: o.colors.accent
      },
      "&&": {
        border: "none"
      }
    },
    checked: e,
    onCheckedChange: (l) => {
      Ko.log("checked", l), t(l);
    },
    children: /* @__PURE__ */ k(Eg, {
      css: {
        display: "block",
        width: "1em",
        height: "1em",
        backgroundColor: o.colors.text,
        borderRadius: "9999px",
        boxShadow: `0 0 2px 0 ${o.colors.text} inset`,
        transition: "transform 100ms",
        transform: "translateX(2px)",
        willChange: "transform",
        "&[data-state='checked']": {
          transform: "translateX(calc(2em - 5px))",
          backgroundColor: o.colors.accentContrast
        }
      }
    })
  });
}, Vd = ({ actor: e, className: t }) => /* @__PURE__ */ D($r, {
  className: t,
  css: {
    display: "grid",
    gridTemplateColumns: "subgrid",
    rowGap: "0.5em"
  },
  children: [
    /* @__PURE__ */ k("div", {
      css: {
        gridColumn: "1/4"
      },
      children: /* @__PURE__ */ D("label", {
        children: [
          "Name",
          /* @__PURE__ */ k(st, {
            value: e.name ?? "",
            onChange: e.setName
          })
        ]
      })
    }),
    /* @__PURE__ */ k("div", {
      css: {
        gridColumn: "4/6"
      },
      children: /* @__PURE__ */ D("label", {
        children: [
          "Title",
          /* @__PURE__ */ k(st, {
            value: e.system.title,
            onChange: e.setTitle,
            index: 0
          })
        ]
      })
    }),
    /* @__PURE__ */ k("div", {
      css: {
        gridColumn: "6/7"
      },
      children: /* @__PURE__ */ D("label", {
        children: [
          "Title Die",
          /* @__PURE__ */ D("select", {
            css: {
              display: "block"
            },
            value: e.system.titleDie,
            onChange: (n) => e.setTitleDie(n.target.value),
            children: [
              /* @__PURE__ */ k("option", {
                value: "d4",
                children: "d4"
              }),
              /* @__PURE__ */ k("option", {
                value: "d6",
                children: "d6"
              }),
              /* @__PURE__ */ k("option", {
                value: "d10",
                children: "d10"
              }),
              /* @__PURE__ */ k("option", {
                value: "d12",
                children: "d12"
              })
            ]
          })
        ]
      })
    }),
    /* @__PURE__ */ k("div", {
      css: {
        gridColumn: "1/3"
      },
      children: /* @__PURE__ */ D("label", {
        children: [
          "Order",
          /* @__PURE__ */ k(st, {
            value: e.system.order,
            onChange: e.setOrder
          })
        ]
      })
    }),
    /* @__PURE__ */ k("div", {
      css: {
        gridColumn: "3/6"
      },
      children: /* @__PURE__ */ D("label", {
        children: [
          "Order Quest",
          /* @__PURE__ */ k(st, {
            value: e.system.orderQuest.name,
            onChange: e.setOrderQuestName
          })
        ]
      })
    }),
    /* @__PURE__ */ k("div", {
      css: {
        gridColumn: "6/7"
      },
      children: /* @__PURE__ */ D("label", {
        children: [
          "Completed?",
          /* @__PURE__ */ k(Ia, {
            checked: e.system.orderQuest.completed,
            onChange: e.setOrderQuestCompleted
          })
        ]
      })
    }),
    /* @__PURE__ */ k("div", {
      css: {
        gridColumn: "1/3"
      },
      children: /* @__PURE__ */ D("label", {
        children: [
          "Tenet",
          /* @__PURE__ */ k(st, {
            value: e.system.tenet,
            onChange: e.setTenet
          })
        ]
      })
    }),
    /* @__PURE__ */ k("div", {
      css: {
        gridColumn: "3/6"
      },
      children: /* @__PURE__ */ D("label", {
        children: [
          "Personal Quest",
          /* @__PURE__ */ k(st, {
            value: e.system.personalQuest.name,
            onChange: e.setPersonalQuestName
          })
        ]
      })
    }),
    /* @__PURE__ */ k("div", {
      css: {
        gridColumn: "6/7"
      },
      children: /* @__PURE__ */ D("label", {
        children: [
          "Completed?",
          /* @__PURE__ */ k(Ia, {
            checked: e.system.personalQuest.completed,
            onChange: e.setPersonalQuestCompleted
          })
        ]
      })
    })
  ]
});
Vd.displayName = "TopBits";
const Qd = ({ actor: e, foundryApplication: t }) => /* @__PURE__ */ k(Z0, {
  theme: Ed,
  mode: "large",
  children: /* @__PURE__ */ D("div", {
    className: "css-reset",
    css: {
      position: "absolute",
      top: 0,
      left: 0,
      width: "100%",
      height: "100%",
      // backgroundColor: "#ecb692",
      backgroundColor: "#dbb9a2",
      padding: "1em",
      display: "grid",
      gridTemplateColumns: "repeat(6, 1fr)",
      gridTemplateRows: "min-content [top] min-content [roll] min-content [tabs] 1fr [end]",
      rowGap: "0.5em",
      columnGap: "0.5em"
    },
    children: [
      /* @__PURE__ */ k("div", {
        css: {
          gridColumn: "1/2",
          display: "flex",
          flexDirection: "row",
          position: "relative"
        },
        children: /* @__PURE__ */ k(q0, {
          subject: e,
          application: t,
          css: {
            ...On,
            transform: "rotateZ(-4deg)"
          }
        })
      }),
      /* @__PURE__ */ k($r, {
        css: {
          padding: "0 0 0 0.5em",
          background: "#fffa",
          gridColumn: "2/-1",
          display: "flex",
          flexDirection: "row",
          font: Sd.fontFamily,
          fontSize: "4em",
          fontVariant: "small-caps",
          fontWeight: "bold"
        },
        children: /* @__PURE__ */ k("div", {
          children: "Pub Crusade"
        })
      }),
      /* @__PURE__ */ k(Vd, {
        actor: e,
        css: {
          gridColumn: "1/-1",
          gridRow: "top"
        }
      }),
      /* @__PURE__ */ k(es, {
        css: {
          gridColumn: "1/3",
          gridRow: "roll"
        },
        title: "Roll low",
        description: "(violence, escalation, tomfoolery)",
        actor: e,
        lowOrHigh: "low"
      }),
      /* @__PURE__ */ k(Pd, {
        actor: e,
        css: {
          gridColumn: "3/5",
          gridRow: "roll"
        }
      }),
      /* @__PURE__ */ k(es, {
        css: {
          gridColumn: "5/7",
          gridRow: "roll"
        },
        title: "Roll high",
        description: "(social, precision, be sensible)",
        actor: e,
        lowOrHigh: "high"
      }),
      /* @__PURE__ */ k("div", {
        css: {
          gridColumn: "1/-1",
          gridRow: "tabs",
          position: "relative"
        },
        children: /* @__PURE__ */ k(Id, {
          actor: e,
          css: {
            gridColumn: "1/-1",
            gridRow: "tabs"
          }
        })
      })
    ]
  })
});
Qd.displayName = "CharacterSheet";
function Pg(e) {
  return (e == null ? void 0 : e.type) === ja;
}
function oe(e) {
  if (!Pg(e))
    throw new Error("not a character actor");
}
class _g extends ActorSheet {
  /** @override */
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes: [
        Nr,
        "sheet",
        "actor"
      ],
      template: qd,
      width: 777,
      height: 900
    });
  }
}
const Ng = (e) => (oe(e.document), /* @__PURE__ */ k(Qd, {
  actor: e.document,
  foundryApplication: e
})), Tg = z0("CharacterSheetClass", _g, Ng);
class Rg extends Actor {
  constructor() {
    super(...arguments), this.setName = (t) => this.update({
      name: t
    }), this.setTitle = async (t) => {
      oe(this), await this.update({
        system: {
          title: t
        }
      });
    }, this.setTitleDie = async (t) => {
      oe(this), await this.update({
        system: {
          titleDie: t
        }
      });
    }, this.setOrder = async (t) => {
      oe(this), await this.update({
        system: {
          order: t
        }
      });
    }, this.setTenet = async (t) => {
      oe(this), await this.update({
        system: {
          tenet: t
        }
      });
    }, this.setOrderQuestName = async (t) => {
      oe(this), await this.update({
        system: {
          orderQuest: {
            ...this.system.orderQuest,
            name: t
          }
        }
      });
    }, this.addDrink = async () => {
      oe(this), await this.update({
        system: {
          drinks: [
            ...this.system.drinks,
            {
              id: Yo(),
              what: "",
              where: ""
            }
          ]
        }
      });
    }, this.setDrinkWhat = async (t, n) => {
      oe(this);
      const r = this.system.drinks.findIndex(({ id: o }) => o === t);
      if (r === -1)
        throw new Error("invalid drink id");
      await this.update({
        system: {
          drinks: [
            ...this.system.drinks.slice(0, r),
            {
              ...this.system.drinks[r],
              what: n
            },
            ...this.system.drinks.slice(r + 1)
          ]
        }
      });
    }, this.setDrinkWhere = async (t, n) => {
      oe(this);
      const r = this.system.drinks.findIndex(({ id: o }) => o === t);
      if (r === -1)
        throw new Error("invalid drink id");
      await this.update({
        system: {
          drinks: [
            ...this.system.drinks.slice(0, r),
            {
              ...this.system.drinks[r],
              where: n
            },
            ...this.system.drinks.slice(r + 1)
          ]
        }
      });
    }, this.deleteDrink = async (t) => {
      oe(this);
      const n = this.system.drinks.findIndex(({ id: r }) => r === t);
      if (n === -1)
        throw new Error("invalid drink id");
      await this.update({
        system: {
          drinks: [
            ...this.system.drinks.slice(0, n),
            ...this.system.drinks.slice(n + 1)
          ]
        }
      });
    }, this.setOrderQuestCompleted = async (t) => {
      oe(this), await this.update({
        system: {
          orderQuest: {
            ...this.system.orderQuest,
            completed: t
          }
        }
      });
    }, this.setPersonalQuestName = async (t) => {
      oe(this), await this.update({
        system: {
          personalQuest: {
            ...this.system.personalQuest,
            name: t
          }
        }
      });
    }, this.setPersonalQuestCompleted = async (t) => {
      oe(this), await this.update({
        system: {
          personalQuest: {
            ...this.system.personalQuest,
            completed: t
          }
        }
      });
    }, this.roll = async (t, n, r) => {
      oe(this);
      const l = `${n ? this.system.titleDie : "d8"} + @modifier`, i = new Roll(l, {
        modifier: t
      });
      await i.evaluate({
        async: !0
      }), Ko.log(i);
      const s = i.total;
      if (s === void 0)
        throw new Error("total is undefined");
      const u = r === "low" ? s < this.system.drinks.length || i.dice[0].results[0].result === 1 : s > this.system.drinks.length || i.dice[0].results[0].result === 8, d = s === this.system.drinks.length ? "<div class='brilliant-catastrophe'>Brilliant Catastrophe</div>" : u ? "<div class='success'>Success</div>" : "<div class='failure'>Failure</div>";
      await i.toMessage({
        speaker: ChatMessage.getSpeaker({
          actor: this
        }),
        content: `
        <div class="pub-crusade-roll">
          <div class="description">
            Tries to roll <span class="low-or-high">${r}</span>
            after <span class="drink-count">${this.system.drinks.length}</span> drinks.
          </div>
          <div class="formula">
            ${i.formula} = <span class="total">${i.total}</span>
          </div>
        ${d}
      `
      });
    }, this.addCondition = async () => {
      oe(this), await this.update({
        system: {
          conditions: [
            ...this.system.conditions,
            {
              id: Yo()
            }
          ]
        }
      });
    }, this.setCondition = async (t, n) => {
      oe(this);
      const r = this.system.conditions.findIndex(({ id: o }) => o === t);
      if (r === -1)
        throw new Error("invalid drink id");
      await this.update({
        system: {
          conditions: [
            ...this.system.conditions.slice(0, r),
            {
              ...this.system.conditions[r],
              name: n
            },
            ...this.system.conditions.slice(r + 1)
          ]
        }
      });
    }, this.deleteCondition = async (t) => {
      oe(this);
      const n = this.system.conditions.findIndex(({ id: r }) => r === t);
      if (n === -1)
        throw new Error("invalid drink id");
      await this.update({
        system: {
          conditions: [
            ...this.system.conditions.slice(0, n),
            ...this.system.conditions.slice(n + 1)
          ]
        }
      });
    }, this.setNotes = async (t) => {
      oe(this), await this.update({
        system: {
          notes: t
        }
      });
    };
  }
}
const zg = '@import"https://fonts.googleapis.com/css2?family=Love+Ya+Like+A+Sister&display=swap";.window-content.non-resizable{padding:0;position:relative}.window-content.resizable{position:relative;overflow:hidden;padding:0}.window-content.resizable .react-target{position:absolute;top:0;right:0;bottom:0;left:0}a.entity-link,a.content-link,a.inline-roll{background:unset;border-style:dashed;border-width:1px}.react-target{flex:1}.window-app,#sidebar,.main-controls li,.sub-controls li,#players,#hotbar>*,#navigation a,#navigation li{-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);background-image:linear-gradient(to bottom,#000b,#0006)}hr{width:calc(100% - 2em)}button.investigator-secret-hide-reveal-button{width:fit-content}.investigator-combatant-list .directory-item{position:absolute}.compendium-sidebar .directory-item.compendium[data-pack*=pub-crusade] h3{font-size:1em;max-width:100%}.pub-crusade-roll{font-size:1.2em;font-family:Love Ya Like A Sister,sans-serif}.pub-crusade-roll .description{font-size:1em}.pub-crusade-roll .low-or-high,.pub-crusade-roll .drink-count{font-weight:700;font-size:1.5em}.pub-crusade-roll .formula{font-size:1.2em;vertical-align:middle}.pub-crusade-roll .total{font-weight:700;font-size:1.5em}.pub-crusade-roll .brilliant-catastrophe,.pub-crusade-roll .success,.pub-crusade-roll .failure{font-weight:700;font-size:1.5em;padding:.2em;border-radius:.2em;text-align:center;margin:1em;text-shadow:.1em 0 0 var(--stroke),-.1em 0 0 var(--stroke),0 .1em 0 var(--stroke),0 -.1em 0 var(--stroke),.1em .1em 0 var(--stroke),-.1em .1em 0 var(--stroke),.1em -.1em 0 var(--stroke),-.1em -.1em 0 var(--stroke);color:#fff;box-shadow:0 0 .5em .1em var(--stroke)}.pub-crusade-roll .brilliant-catastrophe{--stroke: #606;font-size:1.5em;background-image:linear-gradient(90deg,#3f0,#eaff00,#ff5e00,#ff5e00,#eaff00,#3f0)}.pub-crusade-roll .success{--stroke: #060;font-size:1.5em;background-image:linear-gradient(90deg,#a0ff7a,#47ff63 21%,#1aff9c,#1aff98,#47ff54 81%,#b2ff7a)}.pub-crusade-roll .failure{--stroke: #600;background-image:linear-gradient(90deg,#ff0,#f90,#f30,#f30,#f90,#ff0)}', { HTMLField: Lg, StringField: He, SchemaField: lo, BooleanField: Fa, ArrayField: Aa } = foundry.data.fields;
class Mg extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      title: new He(),
      titleDie: new He({
        initial: "d6"
      }),
      notes: new Lg(),
      order: new He(),
      tenet: new He(),
      personalQuest: new lo({
        name: new He(),
        completed: new Fa()
      }),
      orderQuest: new lo({
        name: new He(),
        completed: new Fa()
      }),
      conditions: new Aa(new lo({
        id: new He(),
        name: new He()
      })),
      drinks: new Aa(new lo({
        id: new He(),
        what: new He(),
        where: new He()
      }))
    };
  }
}
const Gd = document.createElement("style");
Gd.innerHTML = zg;
document.head.appendChild(Gd);
console.log("Pub Crusade loading");
Hooks.once("init", () => {
  Ko.log("Initializing"), CONFIG.Actor.dataModels.character = Mg, CONFIG.Actor.documentClass = Rg, Actors.unregisterSheet("core", ActorSheet), Actors.registerSheet(Nr, Tg, {
    makeDefault: !0,
    types: [
      ja
    ]
  });
});
export {
  Mg as CharacterData
};
